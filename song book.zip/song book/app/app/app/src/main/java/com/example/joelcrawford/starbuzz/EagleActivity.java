package com.example.joelcrawford.starbuzz;

import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;
import android.text.Editable;
import android.text.TextWatcher;

public class EagleActivity extends Activity {
    public static final String EXTRA_EAGLENO ="eagleNO" ;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.activity_eagle );

        //get the song from the intent

        int eagleNO  = (Integer) getIntent().getExtras().get( EXTRA_EAGLENO );
        Eagle eagle= Eagle.eagles[eagleNO];

        //populate the title name
        TextView eagle_title = (TextView) findViewById( R.id.eagle_title );
        eagle_title.setText( eagle.getEagle_title() );

        //populate with lyrics

        TextView eagle_lyrics = (TextView) findViewById( R.id.eagle_lyrics );
        eagle_lyrics.setText( eagle.getEagle_lyrics() );

    }
}
