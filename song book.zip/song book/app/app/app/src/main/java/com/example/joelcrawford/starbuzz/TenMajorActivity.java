package com.example.joelcrawford.starbuzz;

import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.text.Editable;
import android.text.TextWatcher;


public class TenMajorActivity extends Activity {

    //public static final String EXTRA_TEN_NO = "ten_No";
    public static final String EXTRA_TEN_No ="ten_No" ;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.activity_ten_major );

        //get the lyrics fron the intent

        int ten_No = (Integer) getIntent().getExtras().get( EXTRA_TEN_No );
        TenMajor tenMajor= TenMajor.tenMajors[ten_No];

        //populate the title
//     TextView title= (TextView) findViewById( R.id.title );
//       title.setText( tenMajor.getTitle() );


        //populate the lyrics
        TextView lyrics = (TextView) findViewById( R.id.lyrics );
        lyrics.setText( tenMajor.getLyrics() );


    }

}
