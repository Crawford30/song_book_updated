package com.example.joelcrawford.starbuzz;

import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.text.Editable;
import android.text.TextWatcher;

public class DrinkActivity extends Activity {

    public static final String EXTRA_DRINKNO = "drinkNo";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.activity_drink );

        //Get the drink from the intent
        int drinkNo= (Integer) getIntent().getExtras().get(EXTRA_DRINKNO);
        Drink drink = Drink.drinks[drinkNo];

        //populate the drink image
        //ImageView photo = (ImageView) findViewById( R.id.photo );
        //photo.setImageResource( drink.getImageResourceId() );
       // photo.setContentDescription( drink.getName() );

        //populate drink with name

        TextView name = (TextView) findViewById( R.id.name );
        name.setText( drink.getName() );

        //populate the drink description
        TextView description = (TextView) findViewById( R.id.description );
        description.setText( drink.getDescription() );
    }

}
