package com.example.joelcrawford.starbuzz;

public class Drink {
    private String name;
    private String description;
   private int imageResourceId;
    //drinks is an array of Drinks

    public static final Drink[] drinks ={
            new Drink("1. FILL ME WITH THE HOLY SPIRIT","1. FILL ME WITH THY HOLY SPIRIT.\n\n" +
                    "I want to live each day as if the last one,\n" +
                    "I want the truest values in my life,\n" +
                    "For one day it will truly be my last one, \n" +
                    "And I will have to leave this world behind.\n" + "\n" +

                    "I want to make the most of every moment,\n" +
                    "Redeeming to the fullest passing time,\n" +
                    "By putting on His love and bowels of mercy,\n" +
                    "And by grace put on His humbleness of mind.\n" + "\n" +

                    "\tCHORUS: " + "\n" +

                            "\tFill me with Thy Holy Spirit, fill me with eternal life,\n " +
                            "\tTo live each day as if it be my last one,\n" +
                            "\tFar above this world with all its carnal strife.\n" + "\n" +

                    "The days I’ve wasted are not few but many,\n" +
                    "I’m praying for a difference in my life,\n" +
                    "Till all my friends and loved ones see me changing,\n" +
                    "Till they see no longer me, but only Christ.\n" + "\n" +

                    "Fill me with Thy Holy Spirit, my prayer is,\n" +
                    "“please do not pass me by” " + "\n" +
                    "Till grace o’er takes this weary pilgrim, \n" +
                    "And I set my wings and like an eagle fly.\n"),

            new Drink("2. HAVE YOU REALLY BEEN A FRIEND TO HIM?", "2. HAVE YOU REALLY BEEN A FRIEND TO HIM?\n\n" +
                    "Do you live a life that’s true for the one who died for you?\n" +
                    "Have you really been a friend to Him?\n" +
                    "Have the deeds that you have done been for Christ the blessed one? \n" +
                    "Have you really been a friend to Him?\n" +  "\n" +

                    "\tCHORUS: " + "\n" +
                    "\tHave you really been a friend to Jesus?\n " +
                    "\tDo you falter when the pathway is dim?\n" +
                    "\tHave you really stood the test?\n " +
                    "\tHave you really done your best?\n " +
                    "\tHave you really been a friend to Him?\n" + "\n" +

                    "When you set alone and pray, at the end of every day,\n" +
                    "Have you really been a friend to Him?\n" +
                    "Have you bravely faced the task? \n" +
                    "Done the things He kindly asked? \n" +
                    "Have you really been a friend to Him?\n" + "\n" +

                    "Are you walking with the Lord, according to His word?\n" +
                    "Have you really been a friend to Him?\n" +
                    "Have you tried and tried again, for some precious souls to win?\n" +
                    "Have you really been a friend to Him?"),

            new Drink("3. YOU CAN’T LOSE WITH GOD ON YOUR SIDE","3. YOU CAN’T LOSE WITH GOD ON YOUR SIDE.\n\n" +
                    "There’s a road that you travel, it comes filled with stones, \n" +
                    "And your heart’s so heavy that you can’t carry on,\n" +
                    "I wonder if lately in your sorrow you’ve tried,\n" +
                    "To walk down the pathway with God on your side.\n" + "\n" +

                    "\tCHORUS: " + "\n" +
                    "\tYou can’t lose, you’ll never lose, with God on your side,\n " +
                    "\tYou’ll win, you’ll win, if with Him you’ll abide,\n" +
                    "\tThe door is always open, if you will step inside,\n" +
                    "\tYou can’t lose, you’ll never lose, with God on your side,\n" + "\n" +

                    "Do you feel you’re forsaken, that life is a loss\n" +
                    "Just remember that Jesus, He felt the same way on the cross,\n " +
                    "He cried out, “Oh, Father, hast thou forsaken me?”\n" +
                    "His cries were our passport to life eternally.\n" + "\n" +

                    "So friend, why would you tarry, to enter in,\n" +
                    "This could be the last time that you would ever hear,\n" +
                    "That Heavenly call, that’s tugging at your heart,\n" +
                    "Why not come to Jesus and get a new start."),

            new Drink( "4. O COME ANGEL BAND","4. O COME ANGEL BAND\n" +
                    "My latest sun is sinking fast, my race is nearly run,\n" +
                    "My strongest trials now are past, my triumph is began!\n" + "\n" +

                    "\tCHORUS: " + "\n" +
                    "\tO come, angel band, come and around me stand,\n" +
                    "\tO bear me away on your snowy wings, to my immortal home, \n" +
                    "\tO bear me away on your snowy wings, to my immortal home,\n" + "\n" +

                    "I know I’m nearing holy ranks, of friends and kindred dear,\n" +
                    "I brush the dew of Jordan’s banks, the crossing must be near.\n" + "\n" +

                    "I’ve almost gained my Heavenly home, my spirit loudly sings, \n" +
                    "The holy ones, behold, they come! I hear the noise of wings.\n" + "\n" +

                    "O bear my longing heart to Him, who bled and died for me,\n" +
                    "Whose blood now cleanses from all sin, and gives me victory." ),

            new Drink( "5. LIFE’S RAILWAY TO HEAVEN","5. LIFE’S RAILWAY TO HEAVEN.\n\n" +
                    "Life is like a mountain rail road, with an engineer that’s brave,\n" +
                    "We must make the run successful, from the cradle to the grave,\n" +
                    "Watch the curves, the fills, the tunnels, never falter, never quail,\n" +
                    "Keep your hand upon the throttle, and your eyes upon the rail.\n" + "\n" +

                    "\tCHORUS: " + "\n" +
                    "\tBlessed savior, Thou wilt guide us, till we reach that blissful shore,\n" +
                    "\tWhere the angels wait to join us, in Thy praise forevermore.\n" + "\n" +

                    "You will roll up grades of trail, you will cross the bridge of strife,\n" +
                    "See that Christ is your conductor on this light’ning train of life,\n" +
                    "Always mindful of obstruction, do your duty, never fail,\n" +
                    "Keep your hand upon the throttle, and your eyes upon the rail.\n" + "\n" +

                    "You will often find obstruction, look for storms of wind and rain,\n" +
                    "On a fill, a curve, or trestle, they will almost ditch your train,\n" +
                    "Put your trust alone in Jesus, never falter, never fail\n" +
                    "Keep your hand upon the throttle, and your eyes upon the rail.\n" + "\n" +

                    "As you roll across the trestle, spanning Jordan’s swelling tide,\n" +
                    "There behold the union depot into which your train will glide,\n" +
                    "There you’ll meet the Superintendent, God the Father, God the Son,\n" +
                    "With a hearty joyous plaudit “ weary pilgrim, welcome home”"),

            new Drink( "6. JUST BEFORE THE BATTLE MOTHER.","6. JUST BEFORE THE BATTLE MOTHER.\n\n" +
                    "Just before the battle, Mother, I was thinking most of you,\n" +
                    "While upon the field we’re marching, with our enemies in view\n" +
                    "Comrades brave around me weeping, thinking of our home and God\n" +
                    "For we know that on the morrow, some will sleep beneath the sod\n" + "\n" +

                    "\tCHORUS: " + "\n" +
                    "\tFarewell, mother, you may never see me on this earth again,\n" +
                    "\tOh, do not forget me, mother, if I be numbered with the slain.\n" + "\n" +

                    "Hark! I hear the bugle playing, we are ready for the fight\n" +
                    "Oh, may God protect us, mother, as He ever does the right\n" +
                    "Savior come and stand beside me, by the old red, white and blue\n" +
                    "And we’ll all be reunited, in America brave and true."),

            new Drink("7. HE SIGNED THE PARDON.","7. HE SIGNED THE PARDON.\n\n" +
                    "Jesus, my Lord, paid the greatest price, there on the cross, He gave His own life,\n" +
                    "For a worthless, no good, a sinner such as I, He freely chose to suffer and die.\n" + "\n" +

                    "\tCHORUS: " + "\n" +
                    "\tHe signed the pardon, He signed the pardon\n" +
                    "\tHe paid the debt that truly set me free\n" +
                    "\tHe signed the pardon, He signed the pardon\n" +
                    "\tBut I must receive that pardon unto me.\n" + "\n" +

                    "The word has been spoken and I was condemned, All hope was gone and hell was my end\n " +
                    "The sentence was written and someone must die, But Jesus choose to give His own life.\n" + "\n" +

                    "The pardon is mine, if I can receive, it’s not enough to just understand or believe\n" +
                    "There are millions that claim that pardon for their own,\n" +
                    "But will never make Heaven their home\n" + "\n" +

                    "Receiving the pardon is not that hard to claim,\n" +
                    "But you must receive the one He sends in His name\n" +
                    "Rejecting His Servant brings an awful fate,\n" +
                    "So make sure where you stand, before it’s too late."),

            new Drink( "8. A HOME WITHOUT A DADDY." ,"8. A HOME WITHOUT A DADDY.\n\n" +
                    "So many homes in our great land today, won’t feel like home ‘cause daddy is away,\n" +
                    "The children need their daddy’s guiding hand, to lead them and help them understand.\n" + "\n" +

                    "\tCHORUS: " + "\n" +
                    "\tA home without a daddy is no home, Without a daddy every Joy is gone,\n" +
                    "\tA home without a daddy to love, Displeases our Saviour above.\n" + "\n" +

                    "Today so many daddies are in sin, so foolishly, they’ve let old satan in,\n" +
                    "If they’d repent, I know God would forgive, and someday up in Heaven hey would live.\n" + "\n" +

                    "Tomorrow may be too late to begin, for no one knows when He will come again,\n" +
                    "Our Saviour said that we must wait and pray, and He will come to take us home someday.\n"),

            new Drink( "9. FALLEN LEAVES","9. FALLEN LEAVES.\n\n" +
                    "Lord, let my eyes see the love in every man,\n" +
                    "Let me stop and always lend a helping hand,\n" +
                    "And when I’m laid beneath that little grassy mound,\n" +
                    "There’ll be more friends than leaves upon the ground.\n" + "\n" +

                    "\tCHORUS: " + "\n" +
                    "\tFallen leaves that lie scattered on the ground\n" +
                    "\tThe birds and flowers that were here cannot be found\n" +
                    "\tAll the friends he ever had are not around\n" +
                    "\tThey are scattered like the leaves upon the ground.\n" + "\n" +

                    "Some folks drift along through life and never thrill\n" +
                    "To the feeling that a good deed brings until\n" +
                    "It’s too late and they are ready to lie down\n" +
                    "There beneath the leaves scattered on the ground.\n" + "\n" +

                    "To your grave there’s no use taking any gold,\n" +
                    "You can’t use it when it’s time for hands to fold,\n" +
                    "When you leave this earth for a better home someday,\n" +
                    "The only thing you take is what you gave away."),

            new Drink( "10. SATISFIED MIND","10. SATISFIED MIND.\n\n" +
                    "How many times have you heard someone say,\n" +
                    "If I had this money, I could do things my way\n" +
                    "But little do they know that it’s so hard to find,\n" +
                    "One rich man in ten with a satisfied mind.\n" + "\n" +

                    "Once I was winning in fortune and fame,\n" +
                    "Everything that I longed for to get a start in lives game,\n" +
                    "But suddenly it happened, I lost every dime,\n" +
                    "But I’m richer by far with a satisfied mind.\n" + "\n" +

                    "Money can’t buy back your youth when you are old,\n" +
                    "A friend when you’re lonely or a love that’s grown old,\n" +
                    "The wealthiest person is a pauper at times,\n" +
                    "Compared to the man with a satisfied mind.\n" + "\n" +

                    "When life has ended my time has run out,\n" +
                    "My friends and my loved ones, I’ll leave them no doubt,\n" +
                    "But there’s one thing for certain when it come my time,\n" +
                    "I will leave this old world with a satisfied mind." ),

            new Drink( "11. AUTOMOBILE LIFE","11. AUTOMOBILE LIFE\n\n" +
                    "Some people are just like an automobile,\n" +
                    "They’ll run fine when everything’s right\n" +
                    "When the roads are all clear and the weather is fine,\n" +
                    "And there is plenty of sunshine and light\n" +
                    "But often they come to a wash-out and then, get stuck and have to detour\n" +
                    "May be a break in the testing will prove, they never were meant to endure.\n" + "\n" +

                    "\tCHORUS: " + "\n" +
                    "\tGet plenty of water and plenty of oil,\n" +
                    "\tAnd the best gasoline you can find\n" +
                    "\tHave your engine tuned up and look out for your breaks,\n" +
                    "\tYou’ll have some hard places to climb,\n" +
                    "\tLook out for the tires, for the blowouts will come\n" +
                    "\tOn a dangerous curve, keep an eye,\n" +
                    "\tBut, if you let Jesus take hold of the wheel," +
                    "\tYou’ll make it to heaven on high.\n" + "\n" +

                    "Now all our professions, of powder and paint,\n" +
                    "Get lovely upon the outside,\n" +
                    "Won’t answer for God look on the heart, It matter not how hard we try.\n" +
                    "So if you are stuck in the quicksand of sin,\n" +
                    "Of wandering and floundering about,\n" +
                    "Just let God’s great engine of glory and grace,\n" +
                    "With a cable of love pull you out." ),

            new Drink( "12. THE OLD COUNTRY CHURCH","12. THE OLD COUNTRY CHURCH\n\n" +
                    "There’s a place deer to me where I’m longing to be,\n" +
                    "With my friends in the old country church\n" +
                    "There with mother we went, and our Sundays were spent,\n" +
                    "With my friends in the old country church.\n" + "\n" +

                    "\tCHORUS: " + "\n" +
                    "\tPrecious years, of memory,\n" +
                    "\tO what Joy they bring to me,\n" +
                    "\tHow I long once more to be,\n" +
                    "\tWith my friends in the old country church.\n" + "\n" +

                    "As a small country boy how my heart beat with Joy,\n" +
                    "When I knelt in the old country church,\n" +
                    "And the Saviour above, by His wonderful love,\n" +
                    "Saved my Soul in the old country church.\n" + "\n" +

                    "How I wish that today, all the people would pray,\n" +
                    "As we prayed in the old country church,\n" +
                    "If they’d only confess Jesus surely would bless,\n" +
                    "As He did in the old country church.\n" + "\n" +

                    "Oft my thoughts make me weep, for so many now sleep,\n" +
                    "In their graves near the old country church,\n" +
                    "And sometimes, I may rest with the friends I love best,\n" +
                    "In a grave near the old country church."),

            new Drink( "13. SHAKE HANDS WITH MOTHER AGAIN","13. SHAKE HANDS WITH MOTHER AGAIN\n\n" +
                    "If I should be living when Jesus comes, and could know the day and the hour,\n" +
                    "I’d like to be standing at mother’s tomb, when Jesus comes in His power.\n" + "\n" +

                    "\tCHORUS: " + "\n" +
                    "\t‘Twill be a wonderful happy day, up there by the golden strand,\n" +
                    "\tWhen I can hear Jesus, my Saviour say, shake hands with mother again.\n" + "\n" +

                    "I’d like to say “mother this is your boy,you left when you went away” \n" +
                    "And I can see Jesus upon His throne, in that bright city, so fair.\n" + "\n" +

                    "There’s coming a time when I can go home, to meet my loved ones up there,\n" +
                    "There I can see Jesus upon His throne, in that bright city, so far.\n" + "\n" +

                    "There’ll be no more sorrow or pain to bear, in that home beyond the sky,\n" +
                    "O glorious thought when we all get there, we never will say “good-bye”."),

            new Drink( "14. THIS WORLD IS NOT MY HOME","14. THIS WORLD IS NOT MY HOME\n\n" +
                    "This world is not my home, I’m just a passing through,\n" +
                    "My treasures are laid up somewhere beyond the blue,\n " +
                    "The angels beckon me from Heaven’s open door,\n" +
                    "And I can’t feel at home in this world anymore.\n" + "\n" +

                    "\tCHORUS: " + "\n" +
                    "\tO Lord, you know I have no friend like you,\n" +
                    "\tIf Heaven’s not my home then Lord what will I do,\n" +
                    "\tThe angels beckon me from Heaven’s open door, \n" +
                    "\tAnd I can’t feel at home in this world anymore.\n" + "\n" +

                    "They’re all expecting me, and that’s one thing I know,\n" +
                    "My Saviour pardoned me and now I onward go,\n" +
                    "I know He’ll take me through though I am weak and poor,\n" +
                    "And I can’t feel at home in this world anymore.\n" + "\n" +

                    "I have a loving mother up in glory land,\n" +
                    "I don’t expect to stop, until I shake her hand,\n" +
                    "She’s waiting now for me, in Heaven’s open door,\n" +
                    "And I can’t feel at home in this world anymore.\n" + "\n" +

                    "Just up in glory land we’ll live eternally,\n" +
                    "The saints on ev’ry hand are shouting victory,\n" +
                    "Their song of sweetest praise drifts back from Heaven’s shore,\n" +
                    "And I can’t feel at home in this world anymore." ),

            new Drink( "15. THE PICTURE ON THE WALL","15. THE PICTURE ON THE WALL\n\n" +
                    "There’s an old and faded picture on the wall,\n" +
                    "It’s been hanging there for many, many years,\n" +
                    "It’s the picture of my mother, and I know there is no other,\n" +
                    "That can take the place of mother on the wall.\n" + "\n" +

                    "\tCHORUS: " + "\n" +
                    "\tOn the wall, on the wall, How I love that old picture on the wall,\n" +
                    "\tTime is swiftly passing by, and I bow my head and cry,\n" +
                    "\tBut I know I’ll meet my mother after all.\n" +  "\n" +

                    "Since I lost that dear old mother years ago,\n" +
                    "There is none to which with troubles I can go,\n" +
                    "As my guitar makes this chord I am praying to the Lord,\n" +
                    "Let me hold that old picture on the wall.\n" + "\n" +

                    "Now the children all have scattered, all have gone,\n" +
                    "And I have a little family of my own,\n" +
                    "And I know I love them well, more than any tongue can tell,\n" +
                    "But I’ll hold that dear old picture on the wall.\n" ),

            new Drink( "16. WHERE THE SOUL OF MAN NEVER DIES","16. WHERE THE SOUL OF MAN NEVER DIES\n\n" +
                    "To Canaan’s land, I’m on my way, where the soul (of man) never dies,\n" +
                    "My darkest night will turn to day, where the soul (of man) never dies.\n" + "\n" +

                    "\tCHORUS: " + "\n" +
                    "\tNo sad farewells (Dear friends, there’ll be no sad farewells)\n" +
                    "\tNo tear-dimmed eyes (There’ll be no tear-dimmed eyes) \n" +
                    "\tWhere all is love (Where all is peace and Joy and Love)\n" +
                    "\tAnd the soul (of man) never dies.\n" + "\n" +

                    "A rose is blooming there for me, where the soul (of man) never dies,\n" +
                    "It shines to light the shores of home, where the soul (of man) never dies.\n" + "\n" +

                    "A love light beams across the foam, where the soul (of man) never dies,\n" +
                    "It shines to light the shores of home, where the soul (of man) never dies.\n" + "\n" +

                    "My life will end in deathless sleep, where the soul (of man) never dies,\n" +
                    "And everlasting Joys I’ll reap, where the soul (of man) never dies.\n" + "\n" +

                    "I’m on my way to that fair land, where the soul (of man) never dies,\n" +
                    "Where there will be no parting hand, where the soul (of man) never dies."),


            new Drink( "17. NEITHER DO I CONDEMN THEE","17. NEITHER DO I CONDEMN THEE\n\n" +
                    "By a crowd of worshipers, sorry for their sins, \n" +
                    "Was a poor wanderer, rudely brought in,\n" +
                    "Scribes came and Pharisees, Anxious to see,\n" +
                    "What the meek Nazarene’s verdict would be.\n" + "\n" +

                    "\tCHORUS: " + "\n" +
                    "\t“Neither do I condemn thee”, precious word divine,\n" +
                    "\tFrom the lips of mercy, like the sweetest chimes,\n" +
                    "\tWonderful words of Jesus, sing them o’er and o’er\n, " +
                    "\t“Neither do I condemn thee, go and sin no more”\n" +  "\n" +

                    "They told of her wonderings, making each flaw,\n" +
                    "Spoke of her punishment, Quoting the law,\n" +
                    "Writing upon the ground, sadly and slow,\n" +
                    "But said He unheedingly, head bending low.\n" + "\n" +

                    "Still cried the Pharisees, “pray woman pray,\n" +
                    "What shall we do with her? What doth thou say?”\n" +
                    "Then said He rebukingly, “Let the first stone,\n" +
                    "Come from the sinless hands, hence and alone”\n" + "\n" +

                    "Cheeks flushing with the shame, turning about,\n " +
                    "And from His presence, walking slowly out,\n" +
                    "Then saw we standing there, head bending low,\n " +
                    "He who the world despised, bade her sin no more.\n" + "\n" +

                    "Spoke He most tenderly, “pray woman pray,\n" +
                    "Hast thou no accusers?” “Nay, Master, Nay”\n" +
                    "“Neither do I condemn thee, soul, sick and sore,\n" +
                    "Go forth, I pardon thee, go and sin no more”."),

            new Drink( "18. THANK GOD I’M FREE","\n" +
                    "18. THANK GOD I’M FREE\n\n" +
                    "For a long time I travelled down along lonely road,\n" +
                    "My heart was so heavy, in sin I sank low,\n" +
                    "Then I heard about Jesus, what a wonderful hour,\n" +
                    "I’m so glad that I found out He would bring me out thro His saving power.\n" + "\n" +

                    "\tCHORUS: " + "\n" +
                    "\tThank God, I am free, free, free from this world of sin,\n" +
                    "\tWashed in the blood of Jesus, been born again,\n" +
                    "\tHallelujah, I’m saved, saved, saved by His wonderful grace,\n" +
                    "\tI’m so glad that I found out He would bring me out and show me the way.\n" + "\n" +

                    "Like a bird out of prison, that’s taken its flight,\n" +
                    "Like the blind man that God gave back his sight,\n" +
                    "Like the poor wretched beggar, that’s found fortune and fame,\n" +
                    "I’m so glad that I found out He would bring me out thro’ His Holy name."),

            new Drink( "19. THAT IS THE MAN I’M LOOKING FOR","19. THAT IS THE MAN I’M LOOKING FOR\n\n" +
                    "If you see a man in sandals, please send Him down my way,\n" +
                    "It might be my Master, He’s coming back someday,\n" +
                    "If you see a man in white, that’s like no one you’ve seen before,\n" +
                    "Won’t you let me know, that’s the man I’m looking for.\n" + "\n" +

                    "\tCHORUS: " + "\n" +
                    "\tAnd if you can remember, ask Him what’s His name.\n" +
                    "\tAnd if He tells you Jesus, say, “we’re so glad you came” \n" +
                    "\tTell Him you know someone who still calls Him Lord, \n" +
                    "\tThen send Him on to me, that’s the man I’m looking for.\n" + "\n" +

                    "If you see a man that shines with, a love glow on His face,\n" +
                    "Turn Him down my street, so He can find my place,\n" +
                    "And if His hands are scarred, please don’t shut the door,\n" +
                    "Just send Him on to me, that’s the man I’m looking for." ),


            new Drink( "20. I NEED THE PRAYERS","   20. I NEED THE PRAYERS\n\n" +
                    "I need the prayers of those I love, while trav’lling o’er life’s rugged way,\n " +
                    "That I may true and faithful be, and live for Jesus every day.\n" + "\n" +

                    "\tCHORUS: " + "\n" +
                    "\tI want my friends to pray for me, to bear my tempted soul above,\n" +
                    "\tAnd intercede with God for me, I need the prayers of those I love.\n" + "\n" +

                    "I need the prayers of those I love, to help me in each trying hour,\n" +
                    "To bear my tempted soul to Him, that He may keep me by His pow’r.\n" + "\n" +

                    "I want my friends to pray for me, to hold me up on wings of faith,\n" +
                    "That I may walk the narrow way, kept by our Father’s glorious grace."),

            new Drink( "21 A. BEULAH LAND","    21 A. BEULAH LAND\n\n" +
                    "I’m kind of homesick for a country, to which I’ve never been before,\n" +
                    "No sad goodbyes will there be spoken, for time won’t matter anymore.\n" + "\n" +

                    "\tCHORUS: " + "\n" +
                    "\tBeulah land, I’m longing for you, and some day, on thee I’ll stand,\n" +
                    "\tThere my home shall be eternal. Beulah land, sweet Beulah land.\n" + "\n" +

                    "I’m looking now across the river, there my faith will end in sight,\n" +
                    "There’s just a few more days to labour, then I will take my heav’nly flight." ),


            new Drink( "21 B. WHAT SINS ARE YOU TALKING ABOUT","    21 B. WHAT SINS ARE YOU TALKING ABOUT\n\n" +
                    "I remember the days when I was bent low with the burden of sin and strife,\n" +
                    "Then Jesus came in and rescued me, and He gave me a brand new life,\n" +
                    "And now as I thank Him day after day for washing my sins away,\n" +
                    "It seems I can almost hear the voice of the Blessed Saviour say.\n" + "\n" +

                    "\tCHORUS: " + "\n" +
                    "\tWhat sins are you talking about, I don’t remember them anymore,\n" +
                    "\tFrom the book of life, they’ve all been torn out,\n" +
                    "\tI don’t remember them anymore.\n" + "\n" +

                    "When my flesh becomes weak, it’s then I can speak to the Saviour,\n" +
                    "Who’s with me each day Oh, Father, forgive me, hear my plea and wash my sins away,\n" +
                    "Each time that I bow to give Him thanks for removing my guilt and shame,\n" +
                    "He cannot recall what I’m talking about, for His answer is always the same."),

            new Drink( "22. COUNT YOUR BLESSINGS"," 22. COUNT YOUR BLESSINGS\n\n" +
                    "When upon life’s billows you are tempest tossed,\n" +
                    "When you are discouraged, thinking all is lost\n" +
                    "Count your many blessings, name them one by one,\n" +
                    "And it will surprise you what the Lord hath done.\n" + "\n" +

                    "\tCHORUS: " + "\n" +
                    "\tCount your blessings, name them one by one, \n" +
                    "\tCount your blessings, see what God hath done,\n" +
                    "\tCount your blessings, name them one by one,\n" +
                    "\tCount your many blessings, see what God hath done,\n" + "\n" +

                    "Are you ever burdened with a load of care?\n" +
                    "Does the cross seem heavy you are called to bear?\n " +
                    "Count your many blessings, ev’ry doubt will fly,\n" +
                    "And you will be singing as the days go by.\n" + "\n" +

                    "When you look at others with their lands and gold,\n " +
                    "Think that Christ has promised you His wealth,\n" +
                    "Untold, Count your many blessings, money cannot buy,\n" +
                    "Your reward in Heaven nor your Home on high.\n" + "\n" +

                    "So, amid the conflict, whether great or small,\n" +
                    "Do not be discouraged, God is over all,\n" +
                    "Count your many blessings, angels will attend,\n" +
                    "Help and comfort give you to your journey’s end."),


            new Drink( "23. TURN YOUR RADIO ON\n" ,"23. TURN YOUR RADIO ON\n\n" +
                    "Come and listen in to a radio station, where the mighty hosts of Heaven sing,\n" +
                    "Turn your Radio on (Turn your Radio on),Turn your Radio on (Turn your Radio on), \n" +
                    "If you want to hear the voice of Zion, coming from the land of endless spring,\n" +
                    "Get in touch with God (Get in touch with God), Turn your Radio on (Turn your Radio on).\n" +
                    "\n" +

                    "\tCHORUS: " + "\n" +
                    "\tTurn your Radio on (Turn your Radio on), \n" +
                    "\tAnd listen to the music in the air,\n" +
                    "\tTurn your Radio on (Turn your Radio on), \n" +
                    "\tHeaven’s glory share (Heaven’s glory share),\n" +
                    "Turn the lights down low (Turn the lights down low),\n" +
                    "\tAnd listen to the Master’s Radio,\n" +
                    "\tGet in touch with God (Get in touch with God), \n" +
                    "\tTurn your Radio on (Turn your Radio on).\n" +
                    "\n" +

                    "Brother listen in to the glory land chorus, listen to the glad Hosanna’s roll,\n" +
                    "Turn your Radio on (Turn your Radio on), Turn your Radio on (Turn your Radio on), \n" +
                    "Get a little taste of Joys awaiting, get a little Heaven in your soul,\n" +
                    "Get in touch with God (Get in touch with God), Turn your Radio on (Turn your Radio on).\n" +
                    "\n" +

                    "Listen to the songs of fathers and mothers and the many friends gone on before,\n" +
                    "Turn your Radio on (Turn your Radio on), Turn your Radio on (Turn your Radio on), \n" +
                    "Some eternal morning we shall meet them over on the Hallelujah’s shore,\n" +
                    "Get in touch with God (Get in touch with God), Turn your Radio on (Turn your Radio on).\n"),

            new Drink( "24. THE FAMILY WHO PRAYS\n","24. THE FAMILY WHO PRAYS\n\n" +
                    "Satan has parted daddies and mothers, filling their hearts with just envy and hate,\n" +
                    "Leading their pathway down to destruction, leaving their children like orphans to stray.\n" +
                    "\n" +

                    "\tCHORUS: " + "\n" +
                    "\tThe family who prays will never be parted,\n" +
                    "\tThe circle in heaven unbroken shall stand,\n" +
                    "\tGod will say enter my new faithful servant,\n" +
                    "\tThe family who prays never shall part.\n" +
                    "\n" +

                    "Wars and tornadoes are taking our loved ones, leaving the cheerful with sad aching hearts,\n" +
                    "But we shall join them over the river, but the family who prays never shall part.\n" ),

            new Drink( "25. JESUS IS RIGHT\n","25. JESUS IS RIGHT\n\n" +
                    "Before I met Jesus my life was empty and vain,\n" +
                    "And nothing ahead could I see but sorrow and pain,\n" +
                    "But then at an alter one night I knelt,\n" +
                    "And I found assurance that never has left,\n" +
                    "For Jesus was right for whatever was wrong in my life.\n" +
                    "\n" +

                    "\tCHORUS: " + "\n" +
                    "\tJesus is right for whatever’s wrong in your life,\n" +
                    "\tJesus is right for whatever’s wrong in your life,\n" +
                    "\tJust give Him a chance and Jesus will proof,\n" +
                    "\tThat every promise He made is true,\n" +
                    "\tFor Jesus is right for whatever’s wrong in your life.\n" +
                    "\n" +

                    "Faith cometh by hearing and hearing comes by the word,\n" +
                    "Just open your Bible and read till God’s voice you’ve heard,\n" +
                    "And then at an alter in repentance kneel,\n" +
                    "And you’ll find assurance that you know is real,\n" +
                    "For Jesus is right for whatever’s wrong in your life.\n" ),

            new Drink( "26. BATTLE CRY\n","26. BATTLE CRY\n\n" +
                    "It was a day in history, when my Saviour climbed mount Calvary,\n" +
                    "He was just another man they thought, they were going to hung upon a cross,\n" +
                    "But when His blood dropped to the earth below, the sacrifice paid by that crimson flood,\n" +
                    "It was redemption to our sin, it was a pardon to all men,\n" +
                    "Who would endure unto the end.\n" +
                    "\n" +

                    "\tCHORUS: " + "\n" +
                    "\tHear the words my Saviour cried, press the mark and stay in stride,\n" +
                    "\tI will never leave your side, I will always be your guide,\n" +
                    "\tFor you are my first class bride.\n" +
                    "\n" +

                    "Through the ages it has always been, that the Lord spoke through the mouth of man,\n" +
                    "To encourage His elect to stay, in the race until that final day,\n" +
                    "And to the ones He calls His chosen few, He clearly tells the things that they must do,\n" +
                    "Lay aside the thoughts man, hold to God’s unchanging hand,\n" +
                    "And stay true unto the end.\n" +
                    "\n" +

                    "Once again this day the same is true, He sent a man unto those chosen few,\n" +
                    "With a plan to keep His bride in line, ever marching to that Gospel time,\n" +
                    "So at the sounding of that midnight cry, the call to meet the Lord there in the sky,\n" +
                    "There will be a bride with oil, without wrinkle, spot or soil,\n" +
                    "Free from all her strain and toil.\n" +
                    "\n" +

                    "As the coming of our Lord draws near, we must carry on and never fear,\n" +
                    "Press the battle harder day by day, ever marching up that narrow way,\n" +
                    "And though the devil tries to turn the bride, the Lord is ever present at her side,\n" +
                    "Strengthening His little one, telling her the work is done,\n" +
                    "and the war’s already won.\n" ),

            new Drink( "27. BORN AGAIN\n","27. BORN AGAIN\n\n" +
                    "\n" +
                    "\tCHORUS: " + "\n" +
                    "\tBorn again, free from sin,\n" +
                    "\tI’m happy night and day,\n" +
                    "\tMakes me shout, there’s no doubt,\n" +
                    "\tI know I’m born again.\n" +
                    "\n" +

                    "Satan tells me I only thought I got saved,\n" +
                    "He tells me what a fool I have been,\n" +
                    "But when my mind goes to that old bench where I prayed,\n" +
                    "I know I’ve been born again.\n" +
                    "\n" +

                    "Many times along the way my faith has grown weak,\n" +
                    "When burdens seem to rise on every hand,\n" +
                    "But when I steal away in prayer, He answers my plea,\n" +
                    "My every need He understands.\n" ),

            new Drink( "28. WHY THIS STICK\n","28. WHY THIS STICK\n\n" +
                    "When Moses went to Egypt land and stood in Pharaoh’s house,\n" +
                    "He said, “I’ve come for the children of Israel, come to bring them out”\n" +
                    "To prove that he was from God, he threw his stick to the ground,\n" +
                    "And Pharaoh said, “What are you trying to prove by throwing that stick around?”\n" +
                    "Then all at once, that simple stick became a deadly snake,\n" +
                    "Pharaoh laughed, “I can do the same, Moses, you’re a fake”\n" +
                    "So Jannes and Jambres threw their sticks down, and Oh my, what a surprise?”\n" +
                    "When Moses’ snake ate the other two snakes, you should have seen their eyes.\n" +
                    "\n" +

                    "\tCHORUS: " + "\n" +
                    "\tWhy this stick,” they could have asked Moses, “Why this stick?”\n" +
                    "\t“Because it’s something not a man on earth would pick\n" +
                    "\tAnd it’s the things I like best\n" +
                    "\tThat’s one reason why it’s blest\n" +
                    "\tAnd It’s what God chose to use, that’s why this stick.\n" +
                    "\n" +

                    "So Moses led the children out across that desert land\n" +
                    "But when they stopped and looked around, here comes Pharaoh’s band\n" +
                    "Horses and chariot coming fast and each man had a sword\n" +
                    "And the children of Israel were so afraid, Moses cried out to the Lord,\n" +
                    "“Here we are at the Red Sea, Lord, with Pharaoh’s army behind,”\n" +
                    "The Lord said, “Why are you crying to me, I’m with you all the time,”\n" +
                    "“Stretch out your stick, “Moses did, and the waters parted fast,\n" +
                    "And the children of Israel went safely across, but for Pharaoh, it was his last.\n" +
                    "\n" +

                    "He led the children through the wilderness and problems came and went,\n" +
                    "But by that stick, God always proved that Moses had been sent,\n" +
                    "He used that stick in wondrous ways, time and time again,\n" +
                    "Like the time, when Israel was in a war, when the stick was up, they’d win,\n" +
                    "He took that stick, when the water was gone and Moses struck the rock,\n" +
                    "And water came forth for all to drink, for Israel and their flocks,\n" +
                    "But all the time in the wilderness, they could never understand,\n" +
                    "Why God would choose a stick to prove that Moses was His man.\n" ),

            new Drink( "29. IF WE FORGET GOD\n","29. IF WE FORGET GOD\n\n" +
                    "If we forget God, satan will rule, if we forget God, our nation is doomed,\n" +
                    "The stories and pictures in most magazines, now feature new styling unfit to be seen,\n" +
                    "They’re placed on the new stand where children can buy\n" +
                    "When they go wrong, do we wonder why?\n" +
                    "\n" +

                    "\tCHORUS: " + "\n" +
                    "\tIf we forget God, His mercy will flee,\n" +
                    "\tAnd sin will cover the land and the sea,\n" +
                    "\tIf we forget God, satan will rule,\n" +
                    "\tIf we forget God, our nation is doomed.\n" +
                    "\n" +

                    "So many are climbing fame’s golden hill, while singing of evil that gives this world a thrill,\n" +
                    "But I’ll sing of Jesus, and though they won’t hear, God will bless me for doing His will." ),

            new Drink( "30. OVER COMER\n","30. OVER COMER\n\n" +
                    "A man once walked on Galilee, stilled the winds and calmed the sea,\n" +
                    "Cast out demons, opened blinded eyes,\n" +
                    "Healed the sick and raised the dead, people marveled at the things He said,\n" +
                    "For His words were spoken with authority\n" +
                    "But the rulers of that day, turned their heads and walked away,\n" +
                    "Saying, He was no more than a man, but He broke the power of what they said,\n" +
                    "When He rose up from the dead, and proved He was the great overcomer.\n" +
                    "\n" +

                    "\tCHORUS: " + "\n" +
                    "\tNow I’m an overcomer, by the spirit of the Lord that lives within me,\n" +
                    "\tI’m an overcomer, with the promise of life eternally,\n" +
                    "\tBut I once was lost in sin, and I had no strength within,\n" +
                    "\tTo resist the way that I had gone or leave the road that I was on,\n" +
                    "\tBut Jesus took away my sin, and placed His holy spirit in,\n" +
                    "\tAnd gave me power to be an overcomer.\n" +
                    "\n" +

                    "He came to save the lost, that’s why He died upon the cross,\n" +
                    "And promised to believers power within,\n" +
                    "So when He’d risen from the tomb, they gathered in the upper room,\n" +
                    "Waiting for the promises He would send as they knelt in one accord,\n" +
                    "Praying to their risen Lord, there came a sound of a rushing mighty wind,\n" +
                    "The spirit fell with tongues of fire, and baptized them that very hour,\n" +
                    "And gave them power to be overcomers.\n" +
                    "\n" +


                    "Even though in these last days, we’d drifted from His holy ways,\n" +
                    "Yet by His grace, once more His voice was heard,\n" +
                    "Through a simple, humble man, God fulfilled His mighty plan,\n" +
                    "Showed great signs and wonders and restored His word,\n" +
                    "But again it is sad to say, they have turned their heads and walked away,\n" +
                    "Saying once again it is just a man, but to the bride it’s plain to see,\n" +
                    "God’s revealed His mysteries, and given us power to be overcomers.\n" +
                    "\n" +

                    "Though the bride was running well as time passed by she fell,\n" +
                    "But praise the Lord the story did not end, for the Lord will have a bride,\n" +
                    "Pure and spotless by His side, so He sent this great and final call my friend,\n" +
                    "And though most are sleeping on, while He plays His heavenly songs,\n" +
                    "A few arise to hear the midnight cry, then the Lord of glory shall descend,\n" +
                    "Take the first class bride to be with Him, it’s ordained for them to be the overcomers.\n" ),

            new Drink( "31. LONGING FOR JESUS\n","31. LONGING FOR JESUS\n\n" +
                    "I’m longing for the glorious day when Jesus Christ shall come,\n" +
                    "I long to see His blessed face,\n" +
                    "When all the saints throughout the ages shall be gathered home,\n" +
                    "The ones who’ve trusted in His grace.\n" +
                    "\n" +

                    "\tCHORUS: " + "\n" +
                    "\tI’m longing for Jesus to come back, I long for Jesus Christ my King,\n" +
                    "\tTo come and take me to my home beyond the sky,\n" +
                    "\tUp there where angels shout and sing.\n" +
                    "\n" +

                    "Sometimes the road seems rough and hard, the pathway seems so long,\n" +
                    "But He is always by my side,\n" +
                    "He whispers loving words to me and tells me to be strong,\n" +
                    "That He will always lead and guide.\n" +
                    "\n" +

                    "Oh, what a glorious time t’will be when through the air I go,\n" +
                    "To meet the one who died for me,\n" +
                    "My sorrows, cares, my trials, tears will all be left below,\n" +
                    "For them my way will be complete.\n" ),

            new Drink( "32. GIVE MOTHER MY CROWN","32. GIVE MOTHER MY CROWN\n\n" +
                    "She labored so hard in this world below,\n" +
                    "She didn’t have things most mothers know,\n" +
                    "Raising her children on a widows small pay,\n" +
                    "Washing and ironing since dad passed away.\n" +
                    "\n" +

                    "\tCHORUS: " + "\n" +
                    "\tI want to go to heaven when this life is over,\n" +
                    "\tI want to be with Jesus on eternity’s shore,\n" +
                    "\tBut if I’ve a crown a ‘coming when rewards go all round,\n" +
                    "\tPlease blesses Jesus, give mother my crown.\n" +
                    "\n" +

                    "I didn’t realize it when I was a lad,\n" +
                    "Just how great a burden my mother had,\n" +
                    "Adoption was offered but mother said “No”,\n" +
                    "She raised us and taught us the right way to go.\n" +
                    "\n" +

                    "Now that I am grown and now that she’s old,\n" +
                    "Those precious memories continually roll,\n" +
                    "No better mother for me could be found,                                               \n" +
                    "So Please blessed Jesus, give mother my crown.\n" ),

            new Drink( "33. FIFTY MILES OF ELBOW\n","33. FIFTY MILES OF ELBOW\n\n" +
                    "Twelve hundred miles it’s length and breadth, the four square city stands,\n" +
                    "Its gems and walls of Jasper are, not made with human hands,\n" +
                    "One hundred miles its gates are wide, upon its entrance there,\n" +
                    "With fifty miles of elbow room, on either side to spare.   \t                                                        \n" +
                    "\n" +

                    "Oh, the gates are wide on the other side, just beyond the sunset scene,\n" +
                    "There’ll be room to spare as we enter there, there’s room for you and room for me,\n" +
                    "Oh, the gates are wide on the other side, where the flowers ever bloom,\n" +
                    "On the right hand, on the left hand, fifty miles of elbow room.\n" +
                    "\n" +

                    "Sometimes I’m cramped and crowded here, and I long for elbow room,\n" +
                    "I long to reach for altitude, where fairer flowers bloom, it won’t be long till I shall pass,\n" +
                    "In to that city fair, with fifty miles of elbow room, on either side to spare.\n" +
                    "\n" +

                    "Oh, the gates are wide on the other side, where the flowers ever bloom\n" +
                    "On the right hand, on the left hand, fifty miles of elbow room.\n" ),

            new Drink( "34. NEVER ALONE\n","34. NEVER ALONE\n\n" +
                    "I’ve seen the lightning flashing, and heard the thunder roll,\n" +
                    "I’ve felt sin’s breakers dashing, trying to conquer my soul,\n" +
                    "I’ve heard the voice of my Saviour, telling me still to fight on,\n" +
                    "He promised never to leave me, never to leave me alone.\n" +
                    "\n" +

                    "\tCHORUS: " + "\n" +
                    "\tNo never alone! No never alone!\n" +
                    "\tHe promised never to leave me, never to leave me alone.\n" +
                    "\tNo never alone! No never alone!\n" +
                    "\tHe promised never to leave me, never to leave me alone.\n" +
                    "\n" +

                    "The world’s fierce winds are blowing temptations sharp and keen,\n" +
                    "I feel a peace in knowing my Saviour stands between,\n" +
                    "He stands to shield me from danger when earthly friends are gone,\n" +
                    "He promised never to leave me, never to leave me alone.\n" +
                    "\n" +

                    "When in afflictions valley, I’m treading the road of care,\n" +
                    "My Saviour helps me carry, my cross when heavy to bear,\n" +
                    "My feet entangled with briars, ready to cast me down,\n" +
                    "My Saviour whispers His promises, “I will never leave thee alone”\n" +
                    "\n" +

                    "He died for me on the mountain, for me they pierced His side,\n" +
                    "For me He opened the fountain, the crimson cleansing tide,\n" +
                    "For me He’s waiting in glory, seated upon His throne,\n" +
                    "He promised never to leave me, never to leave me alone.\n" ),

            new Drink( "35. WHY THIS GUITAR\n","35. WHY THIS GUITAR\n\n" +
                    "As God has done so many times before, He comes a way that man’s not looking for,\n" +
                    "And though He tells the way He’ll come, and warns that it is just for some,\n" +
                    "Yet people stand and wait for something mores.\n" +
                    "Elijah once again our Lord had sent, throughout the world so many times He went,\n" +
                    "So perfectly God worked His plan, revealed again the son of man,\n" +
                    "And promised that another would be sent.\n" +
                    "\n" +

                    "\tCHORUS: " + "\n" +
                    "\tWhy this guitar, why this guitar,\n" +
                    "\tWhy couldn’t it have come another way?\n" +
                    "\tWhy this guitar, why this guitar,\n" +
                    "\tCause that’s what God has promised for this day.\n" +
                    "\n" +

                    "God’s prophet said another one was made, to build on that foundation he had laid,\n" +
                    "To blast the wrong things very hard, and for the bride to be on guard,\n" +
                    "And promised that the guitar would be played,\n" +
                    "A twin unto the other he would be, whose music always set God’s people free,\n" +
                    "An instrument of strings he had, the music made God’s people glad,\n" +
                    "And when he played the demons had to flee.\n" +
                    "\n" +

                    "The music is the great sign that He gave, for sons of God who’d been the devil’s slave,\n" +
                    "And like the Jewish Jubilee, all who hear will be set free,\n" +
                    "If they receive the pardon that He gave,\n" +
                    "The coming of our Lord again draws nigh, and like before, God heard His people cry,\n" +
                    "He promised thirsty hearts to fill, and put us in His perfect will,\n" +
                    "And by this guitar take us up on high.\n" ),

            new Drink( "36A. THE PRISON OF LOVE\n","36A. THE PRISON OF LOVE\n\n" +
                    "When I came to Jesus I settled it all, I gave Him my life to control,\n" +
                    "Neither fear nor persuasion could draw me to Christ, but His love has captured my soul.\n" +
                    "\n" +

                    "\tCHORUS: " + "\n" +
                    "\tI’m a prisoner of love, a slave to the Master,\n" +
                    "\tI willingly toil thro’ the heat and the cold\n" +
                    "\tI seek no reward in this world below,\n" +
                    "\tBut payday will come, when the pearly gates unfold.\n" +
                    "\n" +

                    "He holds me secure with His love strong and true, I’m happy His servant to be,\n" +
                    "In bondage to Jesus forever I’ll stay, my soul doesn’t want to be free.\n" ),

            new Drink( "36B. HOUSE OF GOLD\n","36B. HOUSE OF GOLD\n\n" +
                    "People steal, they cheat and lie, for wealth and what it will buy,\n" +
                    "But don’t they know on the Judgment day, that gold and silver will melt away.\n" +
                    "\n" +

                    "\tCHORUS: " + "\n" +
                    "\tI’d rather be in a deep dark grave,\n" +
                    "\tAnd know that my poor soul was saved,\n" +
                    "\tThan to live in this world in a house of gold,\n" +
                    "\tAnd deny my God and doom my soul.\n" +
                    "\n" +

                    "What good is gold and silver, too, if your heart is not good and true?\n" +
                    "Sinner, hear me when I say, fall down on your knees and pray.\n" ),

            new Drink( "37. I WASN’T BORN TO BE A CHICKEN\n","37. I WASN’T BORN TO BE A CHICKEN\n\n" +
                    "I remember when I was scratching around in this old world of sin,\n" +
                    "Pecking at things trying to satisfy that thirst down deep within,\n" +
                    "I tried to make that clicking sound and eat the things they eat,\n" +
                    "But I found that I was never satisfied, I was looking for a spiritual meat.\n" +
                    "\n" +

                    "\tCHORUS: " + "\n" +
                    "\tI wasn’t born to be a chicken even though I landed in a chicken yard,\n" +
                    "\tI’m finally realizing why the ways of the chicken seemed so hard,\n" +
                    "\tThat’s not the kind of bird God predestined me to be,\n" +
                    "\tI was born to be an eagle and live with God eternally.\n" +
                    "\n" +

                    "In thing after thing that a chicken does, I would try to do my best,\n" +
                    "But it seemed that no matter how hard I tried I was never quite as good as the rest,\n" +
                    "They could be so happy, they could laugh and smile as they lived their life of sin,\n" +
                    "But whenever I would join them in their fun I could never get peace within.\n" +
                    "\n" +

                    "As day after day was passing by I would notice the same old thing,\n" +
                    "All of the chickens that were gathered around didn’t care about using their wings,\n" +
                    "They were happy to peck and scratch and cluck and didn’t want to fly,\n" +
                    "But something down deep inside of me was calling me to the sky.\n" +
                    "\n" +

                    "It seemed my life was almost gone, I just couldn’t take no more,\n" +
                    "So very tired of that, chicken yard, my heart and soul were sore,\n" +
                    "Then all at once I heard a scream that came from way above,\n" +
                    "Said “come on son, I got your food, it’s faith and Agape love”\n" +
                    "\n" +

                    " I took to the sky all at once it became so clear to me,\n" +
                    "The problem I heard through all my life was finally plain to see,\n" +
                    "The reason I just can’t do no good at the things that chickens do,\n" +
                    "I wasn’t built for a chicken life, I’m an eagle through and through.\n" ),

            new Drink( "38. WHEN GOD GATHERS HIS JEWELS\n" ,"38. WHEN GOD GATHERS HIS JEWELS\n\n" +
                    "The ceremony was over, a lad stood alone in tears,\n" +
                    "For he had just said good-bye to the one he had loved through the years.\n" +
                    "\n" +
                    "He stood all alone with his head bowed down as though his heart would break,\n" +
                    "Then the person came over and took his hand and to him these words he did say.\n" +
                    "\n" +

                    "\tCHORUS: " + "\n" +
                    "\tWhen God comes and gathers His Jewels,\n" +
                    "\tAll His treasures and diamonds and gold,\n" +
                    "\tYou’ll (I’ll) meet her (you) up there, in Heaven so fair,\n" +
                    "\tWhen God comes and gathers His Jewels.\n" +
                    "\n" +

                    "Each night when the pale moon is shining, you can see this lad all alone,\n" +
                    "With his eyes lifted toward Heaven, he’s repeating these words he was told.\n"),

            new Drink( "39. I’M A RICH MAN\n","39. I’M A RICH MAN\n" +
                    "Some folks just can’t understand about the things I say,\n" +
                    "When food is low and shoes have holes and bills are hard to pay,\n" +
                    "But even though they look and see I might not have a dime,\n" +
                    "They hear me keep on testifying claiming all the time.\n" +
                    "\n" +

                    "\tCHORUS: " + "\n" +
                    "\tThat (And) I’m a rich man, Oh (yes) I’m a rich man,\n" +
                    "\tI’ve got the things that money cannot buy,\n" +
                    "\tOh, I’m a rich man, yes, I’m a rich man,\n" +
                    "\tWith the greatest wealth of all, eternal life.\n" +
                    "\n" +

                    "I’ve got the things that wealthy men would give their money for,\n" +
                    "Health and strength and family with children I adore,\n" +
                    "The breathe I breath, the blood that flows are precious in my eyes,\n" +
                    "But most of all, the greatest gift, I’ve got eternal life.\n" +
                    "\n" +

                    "Riches are not measured by the money in your hand,\n" +
                    "The cars you drive, the clothes you wear, your houses or your land\n" +
                    "The greatest riches you can have won’t change from day to day,\n" +
                    "They can’t be bought, they can’t be sold and they will never pass away.\n" ),

            new Drink( "40. A BEAUTIFUL LIFE\n","40. A BEAUTIFUL LIFE\n\n" +
                    "Each day I’ll do……………………………………a golden deed\n" +
                    "By helping those…………………………………..who are in need\n" +
                    "My life on earth…………………………………....is but a span\n" +
                    "And so I’ll do………………………………………the best I can.\n" +
                    "\n" +

                    "\tCHORUS: " + "\n" +
                    "\tLife’s evening sun……………………………is sinking low\n" +
                    "\tA few more days……………………………...and I must go\n" +
                    "\tTo meet the deeds…………………………….that I have done\n" +
                    "\tWhere there will be…………………………...no setting sun\n" +
                    "\n" +

                    "To be a child………………………………………….of God each day\n" +
                    "My light must shine…………………………………....along the way\n" +
                    "I’ll sing His praise……………………………………..while ages roll\n" +
                    "And strive to help………………………………………some troubled souls\n" +
                    "\n" +

                    "The only life……………………………………………that will endure\n" +
                    "Is one that’s kind……………………………………..and good and pure\n" +
                    "And so for God…………………………………………I’ll take a stand\n" +
                    "Each day I’ll lend……………………………………….a helping hand.\n" +
                    "\n" +

                    "While going down………………………………………life’s weary road\n" +
                    "I’ll try to lift…………………………………………….some trav’lers load\n" +
                    "I’ll try to turn……………………………………………the night to day\n" +
                    "Make flowers bloom…………………………………….along the way.\n" ),

            new Drink( "41. A TRAMP ON THE STREET\n","41. A TRAMP ON THE STREET\n\n" +
                    "Only a tramp was Lazarus fate, He was laid down at the rich man’s gate,\n" +
                    "He begged for the crumbs from the rich man to eat,\n" +
                    "But they left Him to die like a tramp on the street.\n" +
                    "\n" +

                    "\tCHORUS: " + "\n" +
                    "\tHe was some mother’s darling, He was some mother’s child,\n" +
                    "\tOnce He was fair and lovely and mild,\n" +
                    "\tSome mother rocked him, her darling to sleep,\n" +
                    "\tBut they left Him to die like a tramp on the street.\n" +
                    "\n" +

                    "Jesus, who died on Calvary’s tree, shedding His life blood for you and for me,\n" +
                    "They wounded His side, His hand and His feet,\n" +
                    "And they left Him to die like a tramp on the street.\n" +
                    "\n" +

                    "If He should come and knock at your door, asking for drink or bread from your store,\n" +
                    "Oh, would you rejoice or turn Him away,\n" +
                    "For this He will Judge you on the great Judgment day.\n" ),

            new Drink( "42. JOB’S GOD IS TRUE\n","\n" +
                    "42. JOB’S GOD IS TRUE\n" +
                    "I can feel the hand of satan, as the tempter press me sore,\n" +
                    "He has been before the father, asking leave to tempt me more.\n" +
                    "\n" +

                    "\tCHORUS: " + "\n" +
                    "\tThough God slay me yet I’ll trust Him, I will then come forth as gold,\n" +
                    "\tAnd I know that He still liveth, for I feel Him in my soul.\n" +
                    "\n" +

                    "I can hear the father grant it, saying do not touch his life,\n" +
                    "Though you crush him he’ll not falter, he will rise above the strife.\n" +
                    "\n" +

                    "Though I struggle I will not falter, by His grace, I’ll make it through,\n" +
                    "For His grace is all sufficient, and I know that God is true.\n" +
                    "\n" +

                    "When I have looked all around me, and His face I cannot see,\n" +
                    "Then I know that through the lattice, He beholdeth even me." ),

            new Drink( "43. JESUS, HOLD MY HAND\n","43. JESUS, HOLD MY HAND\n\n" +
                    "As I travel through this pilgrim land, there’s a friend who walks with me,\n" +
                    "Leads me safely through the sinking sand, it is the Christ of Calvary,\n" +
                    "This would be my pray’r, dear Lord, each day, to help me do the best I can,\n" +
                    "For I need thy light to guide me day and night, Blessed Jesus, hold my hand.\n" +
                    "\n" +

                    "\tCHORUS: " + "\n" +
                    "\tJesus, hold my hand, I need thee every hour,\n" +
                    "\tThrough this land (this weary land)\n" +
                    "\tProtect me by thy (saving) power,\n" +
                    "\tHear my plea (my feeble plea)\n" +
                    "\tO Lord, look down on me,\n" +
                    "\tFor when I kneel in pray’r, I hope to meet you there,\n" +
                    "\tBlesses Jesus, hold my hand.\n" +
                    "\n" +

                    "Let me travel in the light divine, that I may see the blessed way,\n" +
                    "Keep me that I may be wholly thine, and sing redemption’s song someday,\n" +
                    "I will be a soldier brave and true, and ever firmly take a stand,\n" +
                    "As I onward go and daily meet the foe, Blesses Jesus, hold my hand.\n" +
                    "\n" +

                    "When I wander through the valley dim, towards the setting of the sun,\n" +
                    "Lead me safely to land of rest, if I a crown of life I won,\n" +
                    "I have put my faith in thee, dear Lord, that I may reach the golden strand,\n" +
                    "There’s no other friend on whom I can depend, Blesses Jesus, hold my hand.\n" ),

            new Drink( "44. BUBBLING IN MY SOUL\n","44. BUBBLING IN MY SOUL\n\n" +
                    "Well, it’s bubblin’ bubblin’bubblin’bubblin’bubblin’ in my soul,\n" +
                    "Hallelujah I’m so glad I’m in the Heavenly fold,\n" +
                    "The Joy that someday will be mine the half has not been told,\n" +
                    "That’s why this Joy is bubblin’bubblin’bubblin’ in my soul.\n" +
                    "\n" +

                    "My cup is running over now since Jesus saved my soul,\n" +
                    "I’ll sing and shout both day and night since Jesus made me whole\n" +
                    "He filled my heart so full of Joy and sweetly came to me,\n" +
                    "Now praise His Holy name I’m saved all through eternity.\n" +
                    "\n" +

                    "Well, it’s bubblin’ bubblin’bubblin’bubblin’bubblin’ in my soul,\n" +
                    "Hallelujah I’m so glad I’m in the Heavenly fold,\n" +
                    "The Joy that someday will be mine the half has not been told,\n" +
                    "That’s why this Joy is bubblin’bubblin’bubblin’ in my soul.\n" ),

            new Drink( "45. I WOULD NOT BE DENIED\n","45. I WOULD NOT BE DENIED\n\n" +
                    "When pangs of death seized on my soul, unto the Lord I cried,\n" +
                    "Till Jesus came and made me whole, I would not be denied.\n" +
                    "\n" +

                    "\tCHORUS: " + "\n" +
                    "\tI would not be denied (denied), I would not be denied (denied)\n" +
                    "\tTill Jesus came and made me whole, I would not be denied.\n" +
                    "\n" +

                    "As Jacob in the days of old, I wrestled with the Lord,\n" +
                    "And instant with a courage bold, I stood upon His word.\n" +
                    "\n" +

                    "Old satan said my Lord was gone, and would not hear my prayer,\n" +
                    "But praise the Lord! The work is done, and Christ the Lord is here." ),

            new Drink( "46. THE UNSEEN HAND\n","46. THE UNSEEN HAND\n\n" +
                    "There is an unseen hand to me, that leads the way where I cannot see,\n" +
                    "While going through this world of war, His hand still leads me as I go.\n" +
                    "\n" +

                    "\tCHORUS: " + "\n" +
                    "\tI’m trusting to, the unseen hand, that leads me through, this weary land,\n" +
                    "\tAnd some sweet day, I’ll reach that strand, still guided by, the unseen hand.\n" +
                    "\n" +

                    "His hand has led through shadows drear, and while it leads I have no fear,\n" +
                    "I know it will lead me to that home, where sin nor sorrow never can come.\n" +
                    "\n" +

                    "I long to see my Saviour’s face, and sing the story saved by grace,\n" +
                    "And there upon that golden strand, I’ll praise Him for His guiding hand.\n" ),

            new Drink( "47. WHERE SHALL I BE\n","47. WHERE SHALL I BE\n\n" +
                    "When Judgment day is drawing nigh, where shall I be?\n" +
                    "When God the work of men shall try, where shall I be?\n" +
                    "When East and West the fire shall roll, where shall I be?\n" +
                    "How will it be with my poor soul, where shall I be?\n" +
                    "\n" +

                    "\tCHORUS: " + "\n" +
                    "\tO where shall I be when the last trumpet sounds?\n" +
                    "\tO where shall I be when it sounds so loud?\n" +
                    "\tWhen it sounds so loud as to wake up the dead,\n" +
                    "\tO where shall I be when it sounds?\n" +
                    "\n" +

                    "When wicked men his wrath shall see, where shall I be?\n" +
                    "And to the rocks and mountains flee, where shall I be?\n" +
                    "When hills and mountains flee away, where shall I be?\n" +
                    "When all the works of men decay, where shall I be?\n" +
                    "\n" +

                    "When heaven and earth as some great scroll, where shall I be?\n" +
                    "Shall from God’s angry presence roll, where shall I be?\n" +
                    "When all the saints redeemed shall stand, where shall I be?\n" +
                    "Forever blessed at God’s right hand, where shall I be?\n" ),

            new Drink( "48. THE ROYAL TELEPHONE\n","48. THE ROYAL TELEPHONE\n\n" +
                    "Central’s never busy, always on the line,\n" +
                    "You may hear from Heaven, almost any time,\n" +
                    "Tis a royal service, free for one and all,\n" +
                    "When you get in trouble, give this royal line a call.\n" +
                    "\n" +

                    "\tCHORUS: " + "\n" +
                    "\tTelephone to glory, O what Joy divine!\n" +
                    "\tI can feel the current moving on the line,\n" +
                    "\tBuilt by God the Father, for His loved and own,\n" +
                    "\tWe may talk to Jesus, thro’ this royal telephone.\n" +
                    "\n" +

                    "There will be no charges, telephone is free,\n" +
                    "It was built for service, just for you and me,\n" +
                    "There will be no waiting, on this royal line\n" +
                    "Telephone to glory always answers just in time.\n" +
                    "\n" +

                    "Fail to get the answer, Satan’s crossed the wire,\n" +
                    "By a strong dilution, or some base desire,\n" +
                    "Take away obstruction, God is on the throne,\n" +
                    "And you’ll get the answer, thro’ this royal telephone.\n" +
                    "\n" +

                    "If your line is grounded, and connection true,\n" +
                    "Has been lost with Jesus, tell you what to do,\n" +
                    "Prayer and faith and promise, mend the broken wire,\n" +
                    "Till your soul is burning with the Pentecostal fire.\n" +
                    "\n" +

                    "Carnal combinations, cannot get control,\n" +
                    "Of this line to glory, anchored in the soul,\n" +
                    "Storm and trials cannot disconnect the line,\n" +
                    "Held in constant keeping by the Father’s hand divine.\n" ),

            new Drink( "49. THE UNCLOUDED DAY\n","49. THE UNCLOUDED DAY\n\n" +
                    "O they tell me of a home far beyond the skies,\n" +
                    "O they tell me of a home far away,\n" +
                    "Oh they tell me of a home where no storms clouds rise,\n" +
                    "O they tell me of the unclouded day.\n" +
                    "\n" +

                    "\tCHORUS: " + "\n" +
                    "\tO the land of cloudless day, O the land of the unclouded sky,\n" +
                    "\tOh they tell me of a home where no storms clouds rise,\n" +
                    "\tO they tell me of an unclouded day.\n" +
                    "\n" +

                    "O they tell me of a home where my friends have gone,\n" +
                    "O they tell me of that land far away,\n" +
                    "Where the tree of life in eternal bloom,\n" +
                    "Sheds its fragrance thro’ the unclouded day.\n" +
                    "\n" +

                    "O they tell me of the king in His beauty there,\n" +
                    "And they tell me that mine eyes shall behold,\n" +
                    "Where He sits on the throne that is whiter than snow,\n" +
                    "In the city that is made of gold.\n" +
                    "\n" +

                    "O they tell me that He smiles on His children there,\n" +
                    "And His smile drive  their sorrow all away,\n" +
                    "And they tell me that no tears ever come again,\n" +
                    "In that lovely land of unclouded day.\n" ),

            new Drink( "50. THE CHURCH IN THE WILDWOOD\n","50. THE CHURCH IN THE WILDWOOD\n\n" +
                    "There’s church in the valley by the wildwood, no lovelier place in the dale,\n" +
                    "No spot is so dear to my childhood, as a little brown church in the vale.\n" +
                    "\n" +

                    "\tCHORUS: " + "\n" +
                    "\t(Oh, come, come, come, come)\n" +
                    "\tCome to the church by the wildwood, Oh, come to the church in the dale,\n" +
                    "\tNo spot is so dear to my childhood, as a little brown church in the vale.\n" +
                    "\n" +

                    "How sweet on a clear Sabbath morning, to list’n to the clear ringing bell,\n" +
                    "Its tones so sweetly are calling, Oh, come to the church in the vale.\n" +
                    "\n" +

                    "There, close by the church in the valley, lies one that I loved so well,\n" +
                    "She sleeps, sweetly sleeps, Neath the willows, disturb not her rest in the vale.\n" +
                    "\n" +

                    "There, close by the side of that loved one, “Neath the tree where the wild flowers bloom,\n" +
                    "When the farewell hymns shall be chanted, I shall rest by her side in the tomb.\n" ),

            new Drink( "51. THE GREAT SPECKLED BIRD\n" ,"51. THE GREAT SPECKLED BIRD\n\n" +
                    "What a beautiful thought I am thinking, concerning the great speckled bird,\n" +
                    "Remember her name is recorded, on the pages of God’s holy word.\n" +
                    "\n" +

                    "Desiring to lower her standard, they watch every move that she makes,\n" +
                    "They long to find fault with her teachings, but really they find no mistakes.\n" +
                    "\n" +

                    "I am glad I have learned of her meekness, I am proud that my name is on her book,\n" +
                    "For I want to be one never fearing, the face of my Saviour’s true look.\n" +
                    "\n" +

                    "When He cometh, descending from Heaven, on the clouds as He writes in His word,\n" +
                    "I’ll be Joyfully carried to meet Him, on the wings of that great speckled bird.\n" +
                    "\n" +

                    "She is spreading her wings for her journey, on the wings of that great speckled bird\n" +
                    "She `ll rise and be gone in a moment, on the wings of that great speckled bird.\n"),

            new Drink( "52. GIVE ME THE ROSES WHILE I LIVE\n","\n" +
                    "52. GIVE ME THE ROSES WHILE I LIVE\n\n" +
                    "Wonderful things of folks are said, when they have passed away,\n" +
                    "Roses adorn their narrow beds, over the sleeping clay.\n" +
                    "\n" +

                    "\tCHORUS: " + "\n" +
                    "\tGive me the roses while I live, trying to cheer me on,\n" +
                    "\tUseless are flowers that you give, after the soul has gone.\n" +
                    "\n" +

                    "Praises are heard not by the dead, roses they cannot see,\n" +
                    "Let us not wait till souls have fled, generous friends to be.\n" +
                    "\n" +

                    "Faults are forgiven when folks lie, cold in their narrow beds,\n" +
                    "Let us forgive them ‘ere they die, now should the words be said.\n" ),

            new Drink( "53. I’LL BE THERE\n","53. I’LL BE THERE\n\n" +
                    "When the time has come for you to travel on to that other shore,\n" +
                    "And if the Lord has called me first and I’ve gone on before,\n" +
                    "As you start your journey homeward, and you climb that golden stair,\n" +
                    "Well, don’t forget to look for me ‘cause, brother I’ll be there.\n" +
                    "\n" +
                    "\n" +

                    "\tCHORUS: " + "\n" +
                    "\tI’ll be there, I’ll be there, I’ll be there when Jesus calls my name,\n" +
                    "\tI’ll be there, I’ll be there, by God’s grace, I know that I’ll be there.\n" +
                    "\n" +

                    "As time is growing later and His coming is at hand,\n" +
                    "I find I’m still here on earth walking through this land,\n" +
                    "Though I still must toil and labour, my life is not the same,\n" +
                    "For all I’m looking forward to is to hear Him calling my name.\n" +
                    "\n" +

                    "I keep on looking upward, towards the Eastern sky,\n" +
                    "And though my body is here below, I’m way up on high,\n" +
                    "I’ve got my invitation to that meeting in the air,\n" +
                    "And one day soon He’ll call my name, then brother, I’ll be there.\n" ),

            new Drink( "54. I WAS STANDING BY MY WINDOW\n","54. I WAS STANDING BY MY WINDOW\n\n" +
                    "I was standing by my window, on a cold and cloudy day,\n" +
                    "When I saw that hearse come rolling, for to carry my mother away.\n" +
                    "\n" +

                    "\tCHORUS: " + "\n" +
                    "\tWill the circle be unbroken, by and by, Lord by and by,\n" +
                    "\tThere’s a better home awaiting, in the sky, Lord in the sky.\n" +
                    "\n" +

                    "Lord, I told that undertaker, undertaker, please drive slow,\n" +
                    "For that lady, you are hauling, Lord, I hate to see her go.\n" +
                    "\n" +

                    "I will follow close behind her, try to hold up and be brave,\n" +
                    "But I could not hide my sorrow, when they laid her in the grave.\n" +
                    "\n" +

                    "When back home, my home was lonesome, since my mother she had gone,\n" +
                    "Found my brothers, sisters crying, what a home so sad and lone.\n" ),

            new Drink( "55. THE CHURCH IN THE DESERT\n" ,"55. THE CHURCH IN THE DESERT\n\n" +
                    "The church in the desert at EL Passo, the devil said, it is not so,\n" +
                    "But he just doesn’t know, the way up is down, so he’s coming with a frown.\n" +
                    "\n" +

                    "\tCHORUS: " + "\n" +
                    "\tI’m a prisoner to Jesus, a slave to the master,\n" +
                    "\tI’m watching each day, for the devil cold casket,\n" +
                    "\tI’m waiting so patient, for sound, for payday will come,\n" +
                    "\tA snow white robe and a crown.\n" +
                    "\n" +

                    "The church in the wildwood, was faithful and kind, they worship the Lord all the time,\n" +
                    "The people were lovely and kind to all, it put them above the fall.\n" +
                    "\n" +

                    "The church in the desert are okay with love, it should be from the Father above,\n" +
                    "The rabbits are shouting on the mountain side, they are going up high.\n"),

            new Drink( "56. LORD, BUILD ME A CABIN IN THE CORNER OF GLORYLAND\n","56. LORD, BUILD ME A CABIN IN THE CORNER OF GLORYLAND\n\n" +
                    "Many years I’ve looking for a place to call home,\n" +
                    "But I’ve failed here to find it so I must travel on,\n" +
                    "Don’t care for fine mansions on earth sinking sand,\n" +
                    "Lord, build be a cabin in a corner of Glory land.\n" +
                    "\n" +

                    "\tCHORUS: " + "\n" +
                    "\tBuild be a cabin in a corner of Glory land.\n" +
                    "\tIn the shade of the tree of life, that it may ever stand,\n" +
                    "\tWhere I can hear the angels sing and shake Jesus’ hand,\n" +
                    "\tLord, build be a cabin in a corner of Glory land.\n" +
                    "\n" +

                    "There’re many dear loved ones who’ve gone the way,\n" +
                    "The great final morning shall I hear them say,\n" +
                    "“Come join in our singing and play in our band”,\n" +
                    "‘Lord, build be a cabin in a corner of Glory land”.\n" +
                    "\n" +

                    "I won’t ask you dear Saviour to live in thy bliss,\n" +
                    "For I feel I’m not worthy to receive all of this,\n" +
                    "I’m praying, dear Saviour, from thy blessed hand,\n" +
                    "For just a little cabin in a corner of Glory land.\n" ),

            new Drink( "57. IF I COULD HERE MY MOTHER PRAY AGAIN","57. IF I COULD HERE MY MOTHER PRAY AGAIN\n\n" +
                    "How sweet and happy seems the days of which I dream,\n" +
                    "When memory recalls them now and then,\n" +
                    "And with what rapture sweet my weary heart would beat,\n" +
                    "If I could hear my mother pray again.\n" +
                    "\n" +

                    "\tCHORUS: " + "\n" +
                    "\tIf I could hear my mother pray again,\n" +
                    "\tIf I could hear her tender voice as then!\n" +
                    "\tSo (glad I’ll be) t’would mean so much to me, (happy I should be)\n" +
                    "\tIf I could hear my mother pray again.\n" +
                    "\n" +

                    "She used to pray that I on Jesus would rely,\n" +
                    "And always walk the shinning gospel way,\n" +
                    "So trusting still His love, I seek that home above,\n" +
                    "Where I shall meet my mother some glad day.\n" +
                    "\n" +

                    "Within the old home place, her patient, shining face,\n" +
                    "Was always spreading comfort, hope and cheer,\n" +
                    "And when she used to sing to her eternal King,\n" +
                    "It was the songs the angels loved to hear.\n" +
                    "\n" +

                    "Her work on earth is done, her life crown has been won,\n" +
                    "And she is now at rest with Him above,\n" +
                    "And some glad morning she, I know will welcome me,\n" +
                    "To that eternal home of peace and love.\n" ),

            new Drink( "58. KEEP ON THE SUNNY SIDE OF LIFE\n","58. KEEP ON THE SUNNY SIDE OF LIFE\n\n" +
                    "There’s a dark and troubled side of life, There’s a bright and a sunny side too,\n" +
                    "Tho’ we meet with the darkness and strife, The sunny side we also may view.\n" +
                    "\n" +

                    "\tCHORUS: " + "\n" +
                    "\tKeep on the sunny side, always on the sunny side,\n" +
                    "\tKeep on the sunny side of life,\n" +
                    "\tIt will help us every day, it will brighten all the way,\n" +
                    "\tIf we keep on the sunny side of life.\n" +
                    "\n" +

                    "Tho’ the storm in its fury break today, crushing hopes that we cherished so dear,\n" +
                    "Storm and cloud will in time pass away, The sun again will shine bright and clear.\n" +
                    "\n" +

                    "Let us greet with a song of hope each day, Tho’ the moments be cloudy or fair,\n" +
                    "Let us trust in our savior always, who keepeth ev’ry one in His care.\n" ),

            new Drink( "59. IN HIM\n","59. IN HIM\n" +
                    "I know that I am nothing to bear the Christian faith,\n" +
                    "In every blunder that I make, I’ve just myself to blame,\n" +
                    "But glory hallelujah, I don’t see that at all,\n" +
                    "And neither does my Saviour, for the blood has cleansed it all.\n" +
                    "\n" +

                    "\tCHORUS: " + "\n" +
                    "\tIn Him, in Him, is the only place for me,\n" +
                    "\tI won’t go back for anything to where I used to be,\n" +
                    "\tThe sun is always shinning, the victory’s been won,\n" +
                    "\tAnd I’m walking in light of the new Jerusalem.\n" +
                    "\n" +

                    "Why do you talk of sorrow for there is none in here,\n" +
                    "In Christ, there’s no unhappiness, in Christ there is no fear,\n" +
                    "It doesn’t really matter, how dark it is outside,\n" +
                    "For in His Shekinah glory, my soul is quick to hide.\n" +
                    "\n" +

                    "It doesn’t really matter, how this old flesh may feel,\n" +
                    "Let every man’s word be a lie, God’s word alone is real,\n" +
                    "Oh, how my heart’s rejoicing, it’s all in Him, not me,\n" +
                    "And the glory is to Him alone, through all eternity.\n" ),

            new Drink( "60. JUST DRIFTING ALONE.\n","60. JUST DRIFTING ALONE.\n\n" +
                    "Just drifting along on a muddy sea of sin,\n" +
                    "Knowing not the fate waiting me,\n" +
                    "My loved ones were all gone and my friends had turned me down,\n" +
                    "I was just a drifter on the sea.\n" +
                    "\n" +

                    "\tCHORUS: " + "\n" +
                    "\tSomewhere above this old sea of sin and shame,\n" +
                    "\tI heard of sweet voice call my name,\n" +
                    "\tI know it was the savior, the one who died for me,\n" +
                    "\tJesus who had taken on my blame.\n" +
                    "\n" +

                    "I know that far up they are drifting just like I,\n" +
                    "Knowing not the one who loved them so,\n" +
                    "But if they’d only listen to Jesus call their name,\n" +
                    "They’ll not be a drifter anymore.\n" ),

            new Drink( "61. IF I WERE YOU I’D MAKE A CHANGE\n" ,"61. IF I WERE YOU I’D MAKE A CHANGE\n\n" +
                    "Peter preached on the day of Pentecost, when three thousand souls they came,\n" +
                    "Men and brothers what must we do? All repent and be baptized in Jesus’ name.\n" +
                    "\n" +

                    "\tCHORUS: " + "\n" +
                    "\tIf I were you I’d make a change, If I were you I’d make a change,\n" +
                    "\tIf I were you I’d make a change, And be baptized in Jesus Name.\n" +
                    "\n" +

                    "If you want to be complete within, if you want some fullness within\n" +
                    "In the Name of Jesus be baptized, if you have to be baptized again.\n" +
                    "\n" +

                    "All fine in service disciples, They were brothers just began\n" +
                    "How then were you baptized? They said we were baptized unto John.\n" +
                    "\n" +

                    "If you read Acts 2and 4, And you refuse to read anymore\n" +
                    "There’s an eye watching you, if you have troubles at the gate about Acts 2:38\n" +
                    "\n" +

                    "If you have to cross Jordan before I do, just tell old folks I made a change,\n" +
                    "And been baptized in Jesus name Tell old folks I made a change,\n" +
                    "And I’ve been baptized in Jesus name.\n"),

            new Drink( "62. THE FAMILY BIBLE\n","62. THE FAMILY BIBLE\n\n" +
                    "There is a family Bible on the table,\n" +
                    "Its pages torn and hard to read,\n" +
                    "But the family Bible on the table,\n" +
                    "Will ever be my blessing remember me.\n" +
                    "\n" +

                    "At the end of day when work was over,\n" +
                    "And when the evening meals would come,\n" +
                    "Dad would read to us from the family Bible,\n" +
                    "And we’d count our many blessings one by one.\n" +
                    "\n" +

                    "I can see us sitting around the table,\n" +
                    "When from the Bible dad would read,\n" +
                    "I can hear my mother start the singing,\n" +
                    "Rock of ages, Rock of ages cleft for me.\n" +
                    "\n" +

                    "This old world of viles is full of trouble,\n" +
                    "This old world would offer no peace,\n" +
                    "If we would find an old Bible on the table,\n" +
                    "And mother singing Rock of ages cleft for me.\n" ),

            new Drink( "63. I CAN’T HELP WHAT OTHERS DO.\n","63. I CAN’T HELP WHAT OTHERS DO.\n\n" +
                    "I can’t help what others do I’m on my way,\n" +
                    "Makes no difference how they struggle what they say,\n" +
                    "I believe God just the same blessed be His Holy Name,\n" +
                    "I can’t help what others do I’m on my way.\n" +
                    "\n" +

                    "\tCHORUS: " + "\n" +
                    "\tI can’t help what others do, I must go on,\n" +
                    "\tTill I reach that after bright eternal home\n" +
                    "\tThat the Lord said He’ll prepare, By His grace I’m going there,\n" +
                    "\tI can’t help what others do, I must go on.\n" +
                    "\n" +

                    "I can’t help what Satan tries to tempt of me,\n" +
                    "For I have the spirit dwelling now in me,\n" +
                    "And the one who dwells in me, He is greater than that’s on here,\n" +
                    "I can’t help what Satan tries to tempt of me.\n" +
                    "\n" +

                    "I can’t help what people say, they can’t hurt me,\n" +
                    "I’m a child of God and I know I’ve been set free,\n" +
                    "Jesus name prevailed for me overall the enemy of me,\n" +
                    "I can’t help what people say, they can’t hurt me.\n" ),

            new Drink( "64. HEAVEN IS FULL OF IT\n","64. HEAVEN IS FULL OF IT\n\n" +
                    "Give me that old time Singing, Give me that old time Praising,\n" +
                    "Give me that old time Worshiping, And it is good enough for me.\n" +
                    "\n" +

                    "\tThe saints and angels sing Heaven is full of it, yes\n" +
                    "\tHeaven is full of it, and it is good enough for me.\n" +
                    "\n" +

                    "It drowned oppressing Egyptians, it gave water to thirsting Israel,\n" +
                    "It gave Deborah her triumph, and it is good enough for me.\n" +
                    "\n" +

                    "\tIt brings joy to the oppressed, it triumph over disappointments\n" +
                    "\tHeaven is full of it, and it is good enough for me.\n" +
                    "\n" +

                    "It fell Jericho’s stormy walls, it scared the enemies, hosts,\n" +
                    "And what more has it wrought in me, and it is good enough for me.\n" +
                    "\n" +

                    "\tIt has expelled formal silent demons, it has wrought a total deliverance,\n" +
                    "\tIt expels fear and doubt, and it is good enough for me.\n" +
                    "\n" +

                    "It was good for Brother David, it conquered old giant Goliath,\n" +
                    "It made the philistines flee, Heaven is full of it. \n" +
                    "\n" +

                    "\tHeaven is full of it yes, Heaven is full of it yes,\n" +
                    "\tHeaven is full of it, and it is good enough for me.\n" +
                    "\n" +

                    "It made the demons flee from Saul, it melted his old self stony heart,\n" +
                    "It brought God’s glory in Solomon’s temple, and it is good enough for me.\n" +
                    "\n" +

                    "\tGive me that old time Singing, Give me that old time Praising,\n" +
                    "\tIt opened prison doors for Paul and Silas, and it is good enough for me.\n" ),

            new Drink( "65. PLEASE BE STIL\n","65. PLEASE BE STILL\n\n" +
                    "Please be still, Please be still, and hear what thus says the Lord,\n" +
                    "Please be still, Please be still, and hear what thus says the Lord,\n" +
                    "He’s calling you sister, He’s calling you brother, so hear what thus says the Lord,\n" +
                    "so hear what thus says the Lord.\n" ),

            new Drink( "66. COME SIT BY ONE ON MY RIGHT\n","66. COME SIT BY ONE ON MY RIGHT\n\n" +
                    "Come and sit by my right oh you bride, come and lay your sweet on the fire,\n" +
                    "The fire of the word from on high, it will take your soul up on high.\n" +
                    "\n" +

                    "\tCHORUS: " + "\n" +
                    "\tCome and sit by the one on my right, Be honest be faithful tonight,\n" +
                    "\tPromise Him you’ll be His friend, And never again be in sin.\n" +
                    "\n" +

                    "We had a great prophet with us, we should never be starchy or fuss\n" +
                    "He told us the truth about sin, So come up on high my friend.\n" +
                    "\n" +

                    "Watch every word and be saved, He hears every word that we say,\n" +
                    "This is a great prophecy my friend, if you take it you will go in.\n" ),

            new Drink( "67. PRESS ON \n","67. PRESS ON \n" +
                    "Until my Saviour’s face I see, until from this old earth I flee,\n" +
                    "Until I am home eternally, press on press on.\n" +
                    "\n" +

                    "\tCHORUS: " + "\n" +
                    "\tPress on press on (and on) All along life’s way press on,\n" +
                    "\tThere’s a home there above that my Saviour in love\n" +
                    "\tPrepared for me press on.\n" +
                    "\n" +

                    "Until I reach that happy shore, Until this earthly life is over,\n" +
                    "Until we’re home to part no more press on, press on.\n" +
                    "\n" +

                    "Until we pass our final test, and in the hands of Jesus rest,\n" +
                    "Come all ye saints from east to west, press on press on,\n" ),

            new Drink( "68. COVERED BY THE BLOOD OF JESUS\n","68. COVERED BY THE BLOOD OF JESUS\n\n" +
                    "Covered by the blood of Jesus, Covered by the blood of Jesus,\n" +
                    "Covered by the blood of Jesus, Until we be raptured.\n" +
                    "\n" +

                    "Guided by the Spirit of Jesus, Guided by the Spirit of Jesus, \n" +
                    "Guided by the Spirit of Jesus, Until we reach in our home.\n" +
                    "\n" +

                    "Walking in the Spirit of Jesus, Walking in the Spirit of Jesus, \n" +
                    "Walking in the Spirit of Jesus, Until we reach in our home.\n" +
                    "\n" +

                    "Living in the Spirit of Jesus, Living in the Spirit of Jesus,\n" +
                    "Living in the Spirit of Jesus, Until we reach our home.\n" +
                    "\n" +

                    "Hearing the great transmitter of Jesus, Hearing the great transmitter of Jesus,\n" +
                    "Hearing the great transmitter of Jesus, Until we be perfected.\n" +
                    "\n" +

                    "Obeying the great calling Jesus, Obeying the great calling Jesus,\n" +
                    "Obeying the great calling Jesus, Until we reach our home.\n" +
                    "\n" +

                    "Be ready first class bride, Be ready first class bride, \n" +
                    "Be ready first class bride, To reach our home.\n" +
                    "\n" +

                    "Soon the bridegroom will be here, Soon the bridegroom will be here,\n" +
                    "Soon the bridegroom will be here, To gather us in our home.\n" ),

            new Drink( "69. I DREAMED ABOUT MAMA LAST NIGHT\n","69. I DREAMED ABOUT MAMA LAST NIGHT\n\n" +
                    "\n" +

                    "\tCHORUS: " + "\n" +
                    "\tMy life is a treasure that I used to know, I dreamed about mama it’s so\n" +
                    "\tShe read me the Bible and brought me to light,\n" +
                    "\tI dreamed about mama last night.\n" +
                    "\n" +

                    "She told me to love Him, and would help me to win,\n" +
                    "If I would turn away from sin, so I let Jesus in for I know He is my friend,\n" +
                    "For He saved my soul within.\n" +
                    "\n" +

                    "This life is no good with Jesus left out, so come to my Jesus you will shout,\n" +
                    "Let the Holy Ghost come in, and be free from your sin,\n" +
                    "And stay near the Gospel and win.\n" ),

            new Drink( "70. MATHEW 24\n","70. MATHEW 24\n\n" +
                    "I believe the time is coming, when the Lord shall come again,\n" +
                    "I believe the end is nearing every door, I believe I got the old Bible,\n" +
                    "From the beginning to the end, shall compare today with Mathew 24.\n" +
                    "\n" +

                    "\tCHORUS: " + "\n" +
                    "\tWe are living, surely living, in the days it speaks about,\n" +
                    "\tAll the things we’re now having every day,\n" +
                    "\tLet’s be ready for His coming, Let us meet Him with a shout\n" +
                    "\tFor He tells us in His word to watch and pray.\n" +
                    "\n" +

                    "While upon the of Olives, His disciple came to Him,\n" +
                    "Staying, tell us when these things are going to be\n" +
                    "Jesus answered, be ye watching, let each one be free from sin,\n" +
                    "So take heed no man shall ever ye deceived.\n" ),

            new Drink( "71. I’M ON THE MOUNTAIN TOP\n","71. I’M ON THE MOUNTAIN TOP\n\n" +
                    "I’ve been down in the valley, Eating on the sully, Sully came from hell,\n" +
                    "He will open up the cell cast you in hell, So why not break the cell of sin.\n" +
                    "\n" +

                    "\tCHORUS: " + "\n" +
                    "\tI’m on the mountain top, I’m on the mountain top, \n" +
                    "\tI’m flying up on high where the eagle fly,\n" +
                    "\tWatching over me, keeping me from all sin\n" +
                    "\tSave my soul from out to in.\n" +
                    "\n" +

                    "I’ve been in the kitchen, Feasting with the chicken,\n" +
                    "Eating with the chicken of this world,\n" +
                    "Now I’m up on high, where I’m eating by and by\n" +
                    "Come on up my friend, you got to leave this world.\n" ),

            new Drink( "72. WILL THE CIRCLE BE UNBROKEN\n","72. WILL THE CIRCLE BE UNBROKEN\n\n" +
                    "\n" +
                    "\tCHORUS: " + "\n" +
                    "\tWill the circle be unbroken, By and by Lord, by and by,\n" +
                    "\tThere’s a better home awaiting, in the sky, Lord, in the sky.\n" +
                    "\n" +

                    "I can hear my Lord sweetly calling, Come on high my precious child,\n" +
                    "Keep your lamp all trimmed and burning, soon we’ll meet up in the sky.\n" +
                    "\n" +

                    "Do not fear I’m with you, I’m with you all the time,\n" +
                    "I’ve whispered the words of comfort, I will never leave you alone.\n" +
                    "\n" +


                    "I know the great calling is God, Heed and obey His call from on high,\n" +
                    "Manifest His perfect will, And you will be caught away on high.\n" +
                    "\n" +

                    "Great calling tame my tongue, And take all self away,\n" +
                    "Let my life prove to those around me, that I am the first class bride.\n" +

                    "Glory, glory, Hallelujah, it will be a glorious day,\n" +
                    "Glory, glory, Hallelujah, we shall meet to part no more.\n" ),

            new Drink( "73. HOW LONG HAS IT BEEN\n","73. HOW LONG HAS IT BEEN\n\n" +
                    "How long has it been since you talked with the Lord, And you told Him your needs and secrets?\n" +
                    "How long since you prayed? How long since you stayed on your knees till the light shone through?\n" +
                    "How long has it been since your mind felt at ease? How long since your heart need no burdens, Can you call Him your friend?\n" +
                    "How long has it been since you knew that He cares for you?\n" +
                    "\n" +

                    "How long has it been since you knelt by your bed and prayed? To the Lord of the Heaven?\n" +
                    "How long since you knew that He would answer you, and would keep you the long night through?\n" +
                    "How long has it been since you walked with the Lord until the day of believing?\n" +
                    "Can you make Him you friend? How long has it been since you knew that He cares for you?\n" ),

            new Drink( "74. THE HOLY CITY\n","74. THE HOLY CITY\n\n" +
                    "There’s a city, holy city, where the streets are paved of gold,\n" +
                    "And its walls are made of jasper, and its beauty cannot be told\n" +
                    "It’s a home of the redeemed ones, who have known God’s saving grace,\n" +
                    "For the happy bride re-union, will be meeting in that place.\n" +
                    "\n" +

                    "\tCHORUS: " + "\n" +
                    "\tJohn saw that city, and the river flowing free (Hallelujah)\n" +
                    "\tFor the tree (of life) there is splendid,\n" +
                    "\tIn the city built for you and me.\n" +
                    "\n" +

                    "In that city holy city, where no tears can dim the eyes,\n" +
                    "There will be no disappointment, there will be no sacrifice,\n" +
                    "All the saints will then be holy, and we’ll live in one accord,\n" +
                    "There’ll be shouting, There’ll be singing, When we meet with the Lord.\n" +
                    "\n" +

                    "Over in that holy city, We will need no sun to shine,\n" +
                    "We will walk down the streets of glory, in that happy rest of love,\n" +
                    "It’s a place of wondrous beauty, where the saints will never war,\n" +
                    "We will sing there hallelujah, in that home of the soul.\n" ),

            new Drink( "75. I RECOMMEND MY LORD TO YOU\n","75. I RECOMMEND MY LORD TO YOU\n\n" +
                    "I recommend my Lord to you, I recommend my Lord to you, \n" +
                    "And if you are in need my brother, I recommend my Lord to you. \n" +
                    "\n" +

                    "If you’re tried in the devil’s prison, and you’ve wanted and tried to be true,\n" +
                    "Then you need a great soldier, I recommend my Lord to you.\n" +
                    "\n" +

                    "Now if you’re tried in sin, and you wish to be set free,\n" +
                    "Why, you need a great soldier, I recommend my Lord to you, \n" +
                    "\n" +

                    "Now if things are cold and weary, and you have no one to go to,\n" +
                    "Just remember the one who loves you, I recommend my Lord to you, \n" +
                    "\n" +

                    "I recommend my Lord to you, I recommend my Lord to you, \n" +
                    "And if you are in need my brother, I recommend my Lord to you. \n" ),

            new Drink( "76. A ROSE AMONG THE THORNS\n","76. A ROSE AMONG THE THORNS\n\n" +
                    "Just strolling through the field of time, there’s many things to see,\n" +
                    "But nature is the greatest sight there could ever be,\n" +
                    "The greatest of them all to me is how the world was formed,\n" +
                    "And why the roses have to live this day and die among the thorns.\n" +
                    "\n" +

                    "\tCHORUS: " + "\n" +
                    "\tOne day among the world of thorns a rose began to grow,\n" +
                    "\tIt was the greatest gift of God this world will ever know,\n" +
                    "\tIt was the will of God to show, that since the world was formed,\n" +
                    "\tThere had to be a rose to live and die among the thorns.\n" +
                    "\n" +

                    "Along the road to Jericho a man was left to die,\n" +
                    "Just like a petal from the roses, two men passed him by\n" +
                    "A neighbor and a friend came by and found his lifeless form,\n" +
                    "With love he took good care of him, the roses among the thorns.\n" +
                    "\n" +

                    "Two thousand years will soon be gone, since God looked down in love\n" +
                    "There in the town of Bethlehem a rose began to bud\n" +
                    "It lived to bloom until one day it was crushed with awful frown\n"  +
                    "And needing love from God above was put to highest ground." ),

            new Drink( "77. WE HAVE A WONDERFUL BOOK\n","77. WE HAVE A WONDERFUL BOOK\n\n" +
                    "We have a short time to live, And the strayed heart is filled\n" +
                    "That the love has given to us, if we go on in sin, and go on in lust,\n" +
                    "What would we expect from Him?\n" +
                    "\n" +

                    "\tCHORUS: " + "\n" +
                    "\tWe have a wonderful Book, in the books to read,\n" +
                    "\tSo why not read and believe, if you need your healing,\n" +
                    "\tJust come believing, And let your faith be still.\n" +
                    "\n" +

                    "In the book of James, it tells us the same, of what I’ve just said to you,\n" +
                    "If we let our faith wave us through, what would we expect God to do.\n" ),

            new Drink( "78. ON THE CROSS OF CALVARY\n","78. ON THE CROSS OF CALVARY\n\n" +
                    "On the cross of Calvary, A blessed Saviour died,\n" +
                    "Gave His life to save the world from loss,\n" +
                    "And He strained in agony, for every sin to hide,\n" +
                    "Shed the blood that stained the old rugged cross.\n" +
                    "\n" +

                    "\tCHORUS: " + "\n" +
                    "\t‘Twas the blood, His precious blood, that stained the old rugged cross,\n" +
                    "\t‘Twas the blood that paid the awful cost, old souls to fall astray,\n" +
                    "\tCome and plunge today, in the blood that stained the old rugged cross.\n" +
                    "\n" +

                    "To the cross, the rugged cross, They nailed His precious hands,\n" +
                    "And in agony He cried and paid the cost,\n" +

                    "There He toiled and split the blood, for every one that’s stained,\n" +
                    "‘Twas the blood that stained the old rugged cross.\n" +
                    "\n" +

                    "What an awful death He died, To pardon you and me. \n" +
                    "All along in agony He tossed and the world would not repent,\n" ),

            new Drink( "79. TO BE LIKE HIM\n","79. TO BE LIKE HIM\n\n" +
                    "From Bethlehem’s manger came forth a stranger, On earth I long to be like Him,\n" +
                    "My faithful Saviour, how rich His favour, on earth I long to be like Him.\n" +
                    "\n" +

                    "\tCHORUS: " + "\n" +
                    "\tTo be like Jesus, to be like Jesus, on earth I long to be like Him,\n" +
                    "\tAll thro’ life’s journey from earth to glory, I only ask to be like Him.\n" +
                    "\n" +

                    "Serene and holy, obedient, lowly, on earth I long to be like Him.\n" +
                    "By grace forgiven, an heir of Heaven, on earth I long to be like Him.\n" ),

            new Drink( "80. ON A HILL CALLED CALVARY \n","80. ON A HILL CALLED CALVARY\n\n" +
                    "On a hill called Calvary Jesus my Lord suffered for me,\n" +
                    "Carried the cross along the way my sins to atone,\n" +
                    "Then they nailed Him to the cross great was the pain and the loss,\n" +
                    "He suffered it all because He loved me.\n" +
                    "\n" +

                    "\tCHORUS: " + "\n" +
                    "\tBecause He loves me my Saviour died, On the cross was crucified,\n" +
                    "\tNo greater love by mortal man has ever been known,\n" +
                    "\tO praise His dear name, He loves me so,\n" +
                    "\tNow I’m His, He’s mine I know, He suffered it all, because He loves me.\n" +
                    "\n" +

                    "Then they carried Him away, placed Him in a lonely grave,\n" +
                    "Surely they thought that this would be, the end of this man,\n" +
                    "But on the third and glorious day, God came and rolled the stone away,\n" +
                    "He rose from the dead, because He loves me.\n" +
                    "\n" +

                    "And He is living yet to day, moving in a mighty way,\n" +
                    "So simple only few will ever see,\n" +
                    "Thro’ the calling in this day, God will catch His bride away,\n" +
                    "He’s waiting now for you and me.\n" +
                    "\n" +

                    "\tBecause He loves me my Saviour died, On the cross was crucified,\n" +
                    "\tNo greater love by mortal man has ever been known,\n" +
                    "\tHe’s calling us now to come on high, Where we’ll live and never die,\n" +
                    "\tHe’s waiting now for you and me.\n" ),

            new Drink( "81. ROBE OF WHITE\n","81. ROBE OF WHITE\n\n" +
                    "The postman often waited, for a sweet face to appear,\n" +
                    "The face that showed her heart was full of joy\n" +
                    "In the pointing joys smiling thru’ her teeth,\n" +
                    "The family brought a message from her boy.\n" +
                    "\n" +

                    "Her coloured palms were trembling, The postman noticed too,\n" +
                    "Tender, sweet and Angels face was white,\n" +
                    "Would this be the letter that she had waited for?\n" +
                    "And would it tell her that he was alright?\n" +
                    "\n" +

                    "I’m sorry said the postman, I’ve got to ask you to sign,\n" +
                    "This letter books that I have brought along\n" +
                    "You see this letter is registered, He slowly bowed his head,\n" +
                    "And then she knew that there was something wrong.\n" +
                    "\n" +

                    "The address on the cover of this envelope of blue,\n" +
                    "Told her that her darling son was dead,\n" +
                    "Well him, his name and number, had always been before,\n" +
                    "His cousin’s name was written there instead.\n" +
                    "\n" +

                    "Dear Lord they have made my darling’s grave down, I know it happens so,\n" +
                    "She prays an humble prayer to God each night, place to him a blooming rose\n" +
                    "So all the world can see, my soldier boy has won a robe of white.\n" ),

            new Drink( "82. WASTED YEARS\n","82. WASTED YEARS\n\n" +
                    "Have you wondered along on a pathway?\n" +
                    "Have you lived without love, the life of peace?\n" +
                    "Have you searched for a greater than many?\n" +
                    "Or is your life filled with long wasted years?\n" +
                    "\n" +

                    "\tCHORUS: " + "\n" +
                    "\tWasted years, Wasted years, oh how foolish,\n" +
                    "\tAs you walk on in darkness and fear,\n" +
                    "\tTurn around, turn around God is calling,\n" +
                    "\tHe is calling you from a life of wasted years.\n" +
                    "\n" +

                    "Search for wisdom and seek understanding,\n" +
                    "There is someone who knows and always hears,\n" +
                    "Give it up, give it up, the Lord will take it,\n" +
                    "You can’t go on with a life of wasted years.\n" ),

            new Drink( "83. DEAD TO SIN\n","83. DEAD TO SIN\n\n" +
                    "Dead to sin and to ev’ry worldly pleasure,\n" +
                    "Let me see Jesus only, Jesus only\n" +
                    "Let me see Jesus only, only He can satisfy,\n" +
                    "Dead to self and to ev’ry unbelief\n" +
                    "Let me see Jesus only, Jesus only\n" +
                    "Let me see Jesus only, only He can satisfy\n" +
                    "\n" +

                    "Dead to ignorance and ev’ry unconcern,\n" +
                    "Dead to cold and every formal spirit,\n" +
                    "Dead to weakness and ev’ry slothfulness,\n" +
                    "Dead to all misunderstandings and doubts,\n" +
                    "Dead to all vain talks and imaginations,\n" +
                    "Dead to unfruitful works and vanity\n" +
                    "Dead to all prayerlessness and defeats.\n" ),

            new Drink( "84. TAKE MY HAND PRECIOUS LORD\n", "84.TAKE MY HAND PRECIOUS LORD\n\n" +
                            "When my way groweth drier, precious Lord linger near,\n" +
                            "When my life is almost gone, hear my cry, hear my call,\n" +
                            "Hold my hand lest I fall, take my hand precious Lord lead me Home.\n" +
                            "\n" +

                            "\tCHORUS: " + "\n" +
                            "\tPrecious Lord take my hand, lead me home, let me stand,\n" +
                            "\tI’m tired, I’m weak, I’m worn, Through the storm, through the night,\n" +
                            "\tLead me on to the light, Take my hand, precious Lord, lead me home.\n" +
                            "\n" +

                            "When the shadows appear and the night draweth near,\n" +
                            "And the day is almost gone, at the river I stand, guide my feet hold my hand\n" +
                            "Take my hand, precious Lord, lead me home.\n" +
                            "\n" +

                            "Nearing life journey’s end, Be my guide be my friend,\n" +
                            "Give me strength, Lord to overcome,\n" +
                            "By thy Grace I’m thy own, go with me to the end,\n" +
                            "Take my hands precious Lord, lead me Home.\n" ),

            new Drink( "85. I’M TUNED IN MY HEAVENLY HOME\n","85. I’M TUNED IN MY HEAVENLY HOME\n\n" +
                    "I’ve been travelling here in this life, with these heartaches, troubles and strife\n" +
                    "Sometimes Satan tries to tell me to turn aside, But I say Satan get thee behind\n" +
                    "No turning in me the old vine, Now I’m tuned in my Heavenly Home, I’ll not turn back now.\n" +
                    "\n" +

                    "\tCHORUS: " + "\n" +
                    "\tAnd I’m tuned in home here my Lord, To meet my heaven’s reward,\n" +
                    "\tI’m not returning this end, I have made my vows\n" +
                    "\tI’ve nothing to go back to, oh praise God heaven’s here,\n" +
                    "\tAnd I’m tuned in my Heavenly Home, I’ll not turn back now.\n" +
                    "\n" +

                    "There is joy in going in this way, it gets sweeter every day\n" +
                    "My dear Lord is lifting me on to realms above,\n" +
                    "He’s my Saviour guiding me, my friend, He’ll be with me unto the end,\n" +
                    "Now I’m tuned in my Heavenly Home, I’ve perfect love.\n" ),

            new Drink( "86. DEEPER, DEEPER IN THE LOVE OF JESUS\n","86. DEEPER, DEEPER IN THE LOVE OF JESUS\n\n" +
                    "Deeper, deeper in the love of Jesus, Daily let me go,\n" +
                    "Higher, higher in the word of wisdom, More of Grace to know.\n" +
                    "\n" +

                    "\tCHORUS: " + "\n" +
                    "\tO deeper yet, I pray, And higher ev’ry day,\n" +
                    "\tAnd wiser, blessed Lord, in Thy precious, Holy word.\n" +
                    "\n" +

                    "Deeper, deeper! Blessed Holy Spirit, Take me deeper still,\n" +
                    "Till my life is wholly lost in Jesus, And His perfect will.\n" +
                    "\n" +

                    "Deeper, deeper! Tho’ it cost hard trials, Deeper let me go!\n" +
                    "Rooted in the Holy love of Jesus, Let me faithful grow.\n" +
                    "\n" +

                    "Deeper, higher ev’ry day in Jesus, Till all conflict past,\n" +
                    "Finds me conqueror, and in His own image, perfected at last.\n" ),

            new Drink( "87. JUST HAVE A LITTLE TALK WITH JESUS\n","87. JUST HAVE A LITTLE TALK WITH JESUS\n\n" +
                    "I once was lost in sin but Jesus took me in,\n" +
                    "And then a little light from heaven filled my soul,\n" +
                    "It bathed my heart in love and wrote my name above,\n" +
                    "And just a little talk with Jesus made me whole.\n" +
                    "\n" +

                    "\tCHORUS: " + "\n" +
                    "\t(Now let us) have a little talk with Jesus, (Let us) tell Him about our troubles,\n" +
                    "\t(He will) Hear our faintest cry, (And He will) Answer by and by,\n" +
                    "\t(Now when you) fell a little prayer wheel turning, (And you know) a little fire is burning,\n" +
                    "\t(You will) find a little talk with Jesus makes it right (makes it right)\n" +
                    "\n" +

                    "Sometimes my path seems drier without a ray of cheer,\n" +
                    "And then a cloud of doubt may hide the light of day,\n" +
                    "The mist of sin may rise and hide the starry skies,\n" +
                    "But just a little talk with Jesus clears the way.\n" +
                    "\n" +

                    "I may have doubts and fears, my eyes be filled with tears,\n" +
                    "But Jesus is a friend, who watches day and night,\n" +
                    "I go to Him in prayer He knows my every care,\n" +
                    "And just a little talk with Jesus makes it right.\n" ),

            new Drink("88. I WILL BE CARRIED AWAY.\n","88. I WILL BE CARRIED AWAY.\n\n" +
                    "Some glad morning when this life is over, I’ll be carried way,\n" +
                    "To a Home on God’s celestial shore, I’ll be carried way.\n" +
                    "\n" +

                    "\tCHORUS: " + "\n" +
                    "\tI’ll be carried way o glory, I’ll be carried way (in the morning)\n" +
                    "\tIf I die hallelujah By and by, I’ll be carried way.\n" +
                    "\n" +

                    "When the shadow of this life has gone, I’ll be carried way,\n" +
                    "Like a bird out of prison bars has flown, I’ll be carried way.\n" +
                    "\n" +

                    "Just a few more weary days, And then, I’ll be carried way,\n" +
                    "To a land where Joys shall never end, I’ll be carried way.\n" ),

            new Drink( "89. TAKE ME HOME.\n","89. TAKE ME HOME.\n" +
                    "Oh, sometimes I grow weary, and I am home sick for a land,\n" +
                    "Where I shall stroll with my Redeemer, Holding to His nail-scarred hand.\n" +
                    "\n" +

                    "\tCHORUS: " + "\n" +
                    "\tTake me home to green pastures, Take me home where hearts don’t break\n" +
                    "\tFor, I have got a longing to see Jesus, Saviour come and take me home.\n" +
                    "\n" +

                    "There will be singing and joys unending, There we will never grow old or die,\n" +
                    "No more sickness no more tear drops, There we will never say good-bye.\n" +
                    "\n" +

                    "I almost hear the chariot coming, from the wheel I felt the rushing wind\n" +
                    "The love of God will take me over, to a land where there is no more sin.\n" ),

            new Drink( "90. IS YOUR  HEART RIGHT WITH GOD\n","90. IS YOUR  HEART RIGHT WITH GOD\n\n" +
                    "When the waters moved upon the earth and everything vanished from this land,\n" +
                    "Old Noah had the faith and his family was saved,\n" +
                    "That was only a small part in God’s master-plan.\n" +
                    "\n" +

                    "\tCHORUS: " + "\n" +
                    "\tIs your heart right with God?\n" +
                    "\tHas He washed your sins away?\n" +
                    "\tOh , brother, don’t wait too late,\n" +
                    "\tIn this world of power, money rules the heart.\n" +
                    "\n" +

                    "But why have the world and lose your soul?\n" +
                    "It’s written He is coming in a twinkling of any eye,\n" +
                    "To carry all His servants to their mansions in the sky.\n" ),

            new Drink( "91. MESSAGE TO MY MOTHER\n","91. MESSAGE TO MY MOTHER\n\n" +
                    "Take this message to my mother, it will build her heart with Joy,\n" +
                    "Tell her that I met my Saviour, God has saved her wondering boy.\n" +
                    "\n" +

                    "Tears and sorrows that I cost her, How I wish I could repay\n" +
                    "But tell her that I will be waiting for her, we’ll meet in heaven some glad day.\n" +
                    "\n" +

                    "How she cried when I left her, I know it filled her heart with pain,\n" +
                    "She said son please don’t leave me, for we may never meet again.\n" ),

            new Drink( "92. SUPPER TIME\n","92. SUPPER TIME\n" +
                    "When I was but a boy in days of child hood, I used to play till evening shadows came,\n" +
                    "Then winding down an old familiar pathway, I heard my mother call at the set of sun.\n" +
                    "\n" +

                    "\tCHORUS: " + "\n" +
                    "\tCome home, come home it’s supper time, The shadows lengthen fast,\n" +
                    "\tCome home, come home it’s supper time, we’re going home at last.\n" +
                    "\n" +

                    "One day beside her bed I was kneeling, And Angels wings were winnowing the air,\n" +
                    "She heard the call for supper time in heaven, and now I know she’s waiting there for me.\n" +
                    "\n" +

                    "In vision now I see her standing yonder, And her familiar voice I hear once more,\n" +
                    "The banquet table’s ready up in heaven, it’s supper time upon the golden shore.\n" ),

            new Drink( "93. DEATH OF MOTHER\n","93. DEATH OF MOTHER\n" +
                    "When I was just a little boy, my mother cared for me,\n" +
                    "But now she’s gone on to her rest, I’ll meet her there at rest.\n" +
                    "\n" +

                    "\tCHORUS: " + "\n" +
                    "\tI’ll never forget the death of mother, Although this is a sad song,\n" +
                    "\tI loved her then and I love her now, And I’ll love her even though she is gone.\n" +
                    "\n" +

                    "My mother was a helpless one, And could not walk a step,\n" +
                    "I nursed her like a little child, And I’d stay there by her side.\n" +
                    "\n" +

                    "One day my mother felt just fine, That made us feel so good,\n" +
                    "That night was the dying night, And it brought back heartaches and cries.\n" +
                    "\n" +

                    "On her neck a cancer grew, And that was the death of her,\n" +
                    "She suffered so before she died, And then she fainted and died.\n" +
                    "\n" +

                    "The blood did run down her neck, And run upon the floor,\n" +
                    "I held my mother in my arms, while Jesus took her in His arms.\n" ),

            new Drink( "94. I AM GOING TO A CITY.\n","94. I AM GOING TO A CITY.\n\n" +
                    "I am going to a city, where the streets of gold are laid,\n" +
                    "Where the tree of life is blooming, And the roses never fade.\n" +
                    "\n" +

                    "\tCHORUS: " + "\n" +
                    "\tHere they bloom but for a season, soon their beauty is decayed,\n" +
                    "\tI am going to a city, where the roses never fade.  \n" +
                    "\n" +

                    "In this world we have our troubles, Satan’s thing we must evade,\n" +
                    "We’ll be free from all temptations, where the roses never fade.\n" +
                    "\n" +

                    "Loved ones gone to be with Jesus, in the roses of white are laid,\n" +
                    "Now are waiting for my coming, where the roses never fade.\n" ),

            new Drink( "95. WRECK ON THE HIGHWAY\n","95. WRECK ON THE HIGHWAY.\n\n" +
                    "Oh who did you say it was brother, who was in the stay by the way?\n" +
                    "When the whisky and blood run together, Did you hear anyone pray?\n" +
                    "\n" +

                    "\tCHORUS: " + "\n" +
                    "\tI didn’t hear nobody pray my brother, I didn’t hear nobody pray,\n" +
                    "\tI heard a crash on the highway, But I didn’t hear nobody pray.\n" +
                    "\n" +

                    "I heard a crash on the highway, I knew what it was from the start,\n" +
                    "I went to the scene of destruction, But the picture was stamped on my heart\n" +
                    "There was whisky and blood run together, T’was mixed with glass where they laid,\n" +
                    "They had laid their hand in destruction, But I didn’t hear nobody pray.\n" +
                    "\n" +

                    "I wish I could change this sad story, That I’m now telling you,\n" +
                    "But there is no way I can change it, for somebody’s life is now through\n" +
                    "Their souls had been called by the Master, They died in a crash by the way,\n" +
                    "I heard the groan of their dying, But I didn’t hear nobody pray.\n" ),

            new Drink( "96. GIVE ME THE FLOWERS WHILE I LIVE\n","96. GIVE ME THE FLOWERS WHILE I LIVE.\n\n" +
                    "Would you give me the flowers while I’m living, and let me enjoy them while I can,\n" +
                    "Please don’t wait till I’m ready to be buried, and then put some lilies on my head.\n" +
                    "\n" +

                    "\tCHORUS: " + "\n" +
                    "\tIn this world today where we’re living,\n" +
                    "\tSome folks they say the words it’s what they can,\n" +
                    "\tBut when we are dead in our coffins.\n" +
                    "\tAnd  then put some lilies on our head\n" +
                    "\n" +

                    "Today’s when we need flowers, I can’t wait while others get long,\n" +
                    "If you can’t give the flowers while I’m living,\n" +
                    "Then leave them growing when I’m dead.\n" ),

            new Drink( "97. WHAT A GLAD REUNION DAY\n","97. WHAT A GLAD REUNION DAY.\n\n" +
                    "Some glad morning we shall see Jesus in the air,\n" +
                    "Coming after you and me our Joys to share,\n" +
                    "What rejoicing there will be when the saints shall rise,\n" +
                    "Heading for the Jubilee yonder in the sky,\n" +
                    "\n" +

                    "\tCHORUS: " + "\n" +
                    "\tOh what singing oh what shouting,\n" +
                    "\tOn that happy morning when we all shall rise,\n" +
                    "\tOh what glory, Hallelujah\n" +
                    "\tWhen we meet our blessed Saviour in the sky.\n" +
                    "\n" +

                    "Since now I almost see all the saints that are dead, rising for that jubilee that is just ahead,\n" +
                    "In the twinkling of an eye change with him to be, over with the saints to rise in that jubilee.\n" +
                    "\n" +

                    "\tSome bright morning, I shall rise away,\n" +
                    "\tHallelujah, what a glad reunion day.\n" +
                    "\n" +

                    "Soon my Lord will come for me, what a glad reunion day,\n" +
                    "Friends and loved ones I shall see, what a glad reunion day.\n" +
                    "\n" +

                    "When I reach the other side, what a glad reunion day,\n" +
                    "Heavens gates will open wide, what a glad reunion day\n" +
                    "\n" +

                    "Then to Jesus let me go, what a glad reunion day,\n" +
                    "Where the healing waters flow, what a glad reunion day.\n" +
                    "\n" +

                    "At the feet of Christ my Lord, what a glad reunion day,\n" +
                    "We shall sing in one accord, what a glad reunion day.\n" ),

            new Drink( "98. THE PRODIGAL SON\n","98. THE PRODIGAL SON.\n\n" +
                    "I’m a prodigal son who’s wasted his life, wandering in sin, out in the night, \n" +
                    "Alone and forsaken so far from home, God in love looked down from above,\n" +
                    "\n" +

                    "\tCHORUS: " + "\n" +
                    "\tAnd I will rise and go to Jesus, in my Father’s house there is mercy for me,\n" +
                    "\tI will arise and go to Jesus, Live upon high I am the Lord’s Bride.\n" +
                    "\n" +

                    "The Lord sent a prophet to call out His Bride, got them in step, then came the night,\n" +
                    "The Bride fell asleep when the Lord took him no more,\n" +
                    "God in His love, looked down from above sent a representative.\n" ),

            new Drink( "99. I JUST STEAL AWAY\n","99. I JUST STEAL AWAY\n" +
                    "Every time I do a deed I shouldn’t do, every time I say a word I shouldn’t say,\n" +
                    "Let me tell you what I do, and it brings a blessing too, I just steal away somewhere and pray.\n" +
                    "\n" +

                    "\tCHORUS: " + "\n" +
                    "\tI just steal away, I just steal away, And I ask my blessed Lord to lead the way,\n" +
                    "\tI just steal away, I just steal away, I just steal away somewhere and pray.\n" +
                    "\n" +

                    "Often times I’m bound to bow my head in shame, at some idle thought or deed along life’s way,\n" +
                    "But I am never ashamed of my Saviour’s precious name, I just steal away somewhere and pray.\n" +
                    "\n" +

                    "Christ the Saviour always hears and answers prayers, and He gives me many blessings every day,\n" +
                    "So when I have tried my best, I’ve failed to pass the test, I just steal away somewhere and pray.\n" ),

            new Drink( "100. I HAVE GOT A MANSION\n","100. I HAVE GOT A MANSION.\n\n" +
                    "I’m satisfied with just a cottage below,\n" +
                    "A little silver and a little gold,\n" +
                    "But in the city, where the ransom will shine,\n" +
                    "I want a gold one that’s silver lined.\n" +
                    "\n" +

                    "\tCHORUS: " + "\n" +
                    "\tI’ve got a mansion just over the hill top,\n" +
                    "\tIn that bright land where we’ll never grow old,\n" +
                    "\tAnd someday yonder, we will never more wander,\n" +
                    "\tBut walk on streets that are pure as gold.\n" +
                    "\n" +

                    "Though often tempted, tormented or tested,\n" +
                    "And like a prophet, my pillow stone,\n" +
                    "And though I find here no permanent dwelling,\n" +
                    "I know He’ll give me a mansion of my own.\n" +
                    "\n" +

                    "Don’t think me poorer or deserted or lonely,\n" +
                    "I’m not discouraged, I’m heaven bound,\n" +
                    "I’m just a pilgrim in search of a city,\n" +
                    "I want a mansion, a harp and a crown.\n" ),

            new Drink("101. TO WHOM SHALL WE GO?\n","101. TO WHOM SHALL WE GO?\n\n" +
                    "They walked no more with the mighty King, when He spoke that day\n" +
                    "Because His sayings were too hard, the seventy went away\n" +
                    "Then He turned His gentle head, to those who remained\n" +
                    "Said to them that were there, will you also go away?\n" +
                    "\n" +

                    "\tCHORUS: " + "\n" +
                    "\tTo whom shall we go-oo. Lord there’s no one that I know\n" +
                    "\tWho can satisfy this longing, it’s within my soul\n" +
                    "\tAnd there’s nothing in this life, in this world of toil and strife,\n" +
                    "\tSo then to whom shall we go, There’s no one I know but you Lord.\n" +
                    "\n" +

                    "The mighty King has spoken again, through this seventh angel’s voice,\n" +
                    "That we might hear the word of God, and by hearing make a choice,\n" +
                    "Will you stand for what is right or will you fall away?\n" +
                    "He speaks today as He did then will you also go away?\n" +
                    "\n" +

                    "The message that the Prophet brought, Revealed God hidden plans,\n" +
                    "That He would send a special call, through an odd and simple man\n" +
                    "He was called to help the bride with the Lord by His side\n" +
                    "To those who hear and obey will be ready for the midnight cry.\n"),

            new Drink( "102. ONCE I WAS A SINNER\n","102. ONCE I WAS A SINNER.\n\n" +
                    "Once I was a sinner, heading to death, I didn’t know the Saviour, who died for me X2\n" +
                    "\n" +

                    "\tCHORUS: " + "\n" +
                    "\tBut now (He lives) within my soul, (He reigns) x2 in my life\n" +
                    "\tHe walks with me, and talks, with me along the narrow way\n" +
                    "\tPraise the Lordx2\n" +
                    "\n" +

                    "Then I met a man, His name is Jesus\n" +
                    "He said I am the way, the truth, and the life x2\n" +
                    "\n" +

                    "Behold the Lamb of God, who takes away all sin\n" +
                    "Behold the Lamb of God, who died on Calvary x2.\n" ),

            new Drink( "103. DO LORD\n","103. DO LORD.\n\n" +
                    "\tCHORUS: " + "\n" +
                    "\tDo Lord, Oh do Lord, Oh do remember me,\n" +
                    "\tDo Lord, Oh do Lord, Oh do remember me,\n" +
                    "\tDo Lord, Oh do Lord, Oh do remember me, way beyond the blue.\n" +
                    "\n" +

                    "I’ve a Home in glory land that out shines the sun,\n" +
                    "I’ve a Home in glory land that out shines the sun,\n" +
                    "I’ve a Home in glory land that out shines the sun, way beyond the blue.\n" +
                    "\n" +

                    "I took Jesus as my Saviour, you take Him too,\n" +
                    "I took Jesus as my Saviour, you take Him too,\n" +
                    "I took Jesus as my Saviour, you take Him too, while He is calling you.\n" ),

            new Drink( "104. NOTHING TO HINDER ME\n","104. NOTHING TO HINDER ME.\n\n" +
                    "One day I heard of a thing, make the Lord your choice\n" +
                    "He’ll take away your every sin and set you free\n" +
                    "So I came to Him that day and He took my sins away,\n" +
                    "Now I don’t want nothing here to hinder me.\n" +
                    "\n" +

                    "\tCHORUS: " + "\n" +
                    "\tI don’t want nothing here to hinder me,\n" +
                    "\tFor someday His smiling face I long to see,\n" +
                    "\tIt makes no difference what’s the cost, though a heavy my cross,\n" +
                    "\tI don’t want nothing here to hinder me.\n" +
                    "\n" +

                    "Many times I’m tossed about many times I do without\n" +
                    "Many times my heart is burdened down with care\n" +
                    "Lord I know will fight me though, that someday He’ll see me through,\n" +
                    "If I’ll let nothing here to hinder me.\n" +
                    "\n" +

                    "Some day when I get home, where I’ll never more shall roam,\n" +
                    "With the Saviour and my Lord I will be,\n" +
                    "When I lay this old cross down and receive a shining crown,\n" +
                    "I’ll be so glad that nothing here to hinder me.\n" +
                    "\n" +

                    "You’ll be so glad that nothing here to hinder you,\n" +
                    "When you hear Him say my child you made it through\n" +
                    "When you lay this old cross down, and receive a shining crown\n" +
                    "You’ll be so glad that nothing here to hinder you.\n" ),

            new Drink( "105. THE LAST MILE OF THE WAY\n","105. THE LAST MILE OF THE WAY.\n\n" +
                    "If I walk in the pathway of duty, if I work till the close of the day\n" +
                    "I shall see the great King in His beauty, when I’ve gone the last mile of the way.\n" +
                    "\n" +

                    "\tCHORUS: " + "\n" +
                    "\tWhen I’m gone the last mile of the way\n" +
                    "\tI will rest at the close of the day\n" +
                    "\tAnd I know that there are Joys that await me\n" +
                    "\tWhen I’m gone the last mile of the way.\n" +
                    "\n" +

                    "If for Christ I proclaim the glad story, if I see for His sheep gone astray,\n" +
                    "I am sure He will show me His glory, when I’m gone the last mile of the way.\n" +
                    "\n" +

                    "Here the dearest of life we must suffer, tears of sorrow are seen every day,\n" +
                    "But no sickness no sighing forever, when I’m gone the last mile of the way.\n" ),

            new Drink( "106. THANK YOU LORD\n","106. THANK YOU LORD.\n\n" +
                    "As the world looks upon us as we travel along,\n" +
                    "They say we have nothing but they are so wrong,\n" +
                    "In my heart I’m rejoicing, how I wish they could see,\n" +
                    "O thank you Lord for your blessings on me.\n" +
                    "\n" +

                    "I have a roof up above me I have good place to sleep\n" +
                    "There’s food on my table and shoes on my feet\n" +
                    "You gave me your love Lord and a fine family,\n" +
                    "O thank you Lord for your blessings on me.\n" +
                    "\n" +

                    "I know I am not worthy and those clothes are not new,\n" +
                    "I don’t have much money but Lord I have you\n" +
                    "To me that’s all that matters, though the world may not see,\n" +
                    "O thank you Lord for your blessings on me." ),

            new Drink( "107. HOW BEAUTIFUL HEAVEN MUST BE.\n","107. HOW BEAUTIFUL HEAVEN MUST BE.\n\n" +
                    "We read of a place that’s called heaven, it’s built for the few and the free,\n" +
                    "The truth is God’s word has given, How beautiful heaven must be.\n" +
                    "\n" +

                    "\tCHORUS: " + "\n" +
                    "\tHow beautiful heaven must be, sweet home of the happy and free,\n" +
                    "\tThe heaven a place for the weary, How beautiful heaven must be.\n" +
                    "\n" +

                    "In heaven no dripping no paining, No wishing for elsewhere to be,\n" +
                    "God life there in heaven has given, How beautiful heaven must be.\n" +
                    "\n" +

                    "The angels so sweetly are singing, Up there by the beautiful sea,\n" +
                    "Sweet cords of the harps are singing, and saying that beautiful rest.\n" ),

            new Drink( "108. SEE YOU IN THE RAPTURE\n","108. SEE YOU IN THE RAPTURE.\n\n" +
                    "If we never meet again, on this earth my precious friend,\n" +
                    "If to God we have been true, and lived the Bible scene,\n" +
                    "Then for us there’ll be a greeting, for there’s going to be a meeting\n" +
                    "I’ll see you in the rapture some sweet day.\n" +
                    "\n" +

                    "\tCHORUS: " + "\n" +
                    "\tI’ll see you in the rapture, see you in the rapture,\n" +
                    "\tI’ll see you in that meeting in the air, there with my blessed Saviour\n" +
                    "\tWe’ll live and reign forever, I’ll see you in the rapture some sweet day.\n" +
                    "\n" +

                    "To my loved ones let me say, there will come a day,\n" +
                    "That the Lord will come again, to catch His bride away,\n" +
                    "So get ready now to meet Him, and with Hallelujah greet Him,\n" +
                    "I’ll see you in the rapture some sweet day.\n" +
                    "\n" +

                    "To my brothers let me say, you must see your day,\n" +
                    "And be filled with God’s love, and get that perfect faith,\n" +
                    "So get ready now to meet Him, and with Hallelujah greet Him,\n" +
                    "I’ll see you in the rapture some sweet day. " ),

            new Drink( "109. KNOW YE NOT\n","109. KNOW YE NOT.\n\n" +
                    "Know ye not, know ye not, ye are the temple? Know ye not, know ye not, ye are the temple?\n" +
                    "Know ye not, know ye not, ye are the temple? Ye are the temple of the Holy Ghost,\n" +
                    "Yes, I am, yes, I am, I am the temple, Yes, I am, yes, I am, I am the temple, \n" +
                    "Yes, I am, yes, I am, I am the temple, I am the temple of the Holy Ghost.\n" +
                    "\n" +

                    "Filled with grace, filled with power, filled with glory,\n" +
                    "Filled with grace, filled with power, filled with glory,\n" +
                    "Filled with grace, filled with power, filled with glory, I am the temple of the Holy Ghost.\n" +
                    "\n" +

                    "Filled with love, filled with faith, filled with praises,\n" +
                    "Filled with love, filled with faith, filled with praises,\n" +
                    "Filled with love, filled with faith, filled with praises,\n" +
                    "Filled with Word, filled with Spirit, filled with perfection.\n" +
                    "\n" +

                    "Filled with obedience, filled with calling, filled with rapture,\n" +
                    "Filled with obedience, filled with calling, filled with rapture,\n" +
                    "Filled with obedience, filled with calling, filled with rapture, I am the temple of the Holy Ghost.\n" +
                    "\n" +

                    "Filled with Word, filled with Spirit, filled with perfection.\n" +
                    "Filled with Word, filled with Spirit, filled with perfection.\n" +
                    "Filled with Word, filled with Spirit, filled with perfection. I am the temple of the Holy Ghost.\n" ),

            new Drink( "110. ALL OVER THE WORLD\n","110. ALL OVER THE WORLD.\n\n" +
                    "All over the world, the spirit is moving,\n" +
                    "All over the world, as the Prophet said it would be,\n" +
                    "All over the world, there’s a mighty revelation,\n" +
                    "Of the glory of the Lord, as the waters cover the sea.\n" +
                    "\n" +

                    "Deep down in my heart, the spirit is moving,\n" +
                    "Deep down in my heart, as the prophet said it would be,\n" +
                    "Deep down in my heart, there’s a mighty revelation,\n" +
                    "Of the glory of the Lord, as the waters cover the sea.\n" ),

            new Drink( "111A. TAKE UP THY CROSS\n","111A. TAKE UP THY CROSS.\n\n" +
                    "I walked one day along a country road, and then a stranger journeyed too,\n" +
                    "Bent low beneath the burden of His load, it was the cross of cause I need.\n" +
                    "\n" +

                    "\tCHORUS: " + "\n" +
                    "\t“Take up thy cross and follow me,” I hear the blessed Saviour call,\n" +
                    "\tHow can I make a lesser sacrifice, when Jesus gave His own.\n" +
                    "\n" +

                    "I cried Lord Jesus thank you for my name, I saw His hand so bruised and torn,\n" +
                    "I stood to kiss away the mark of shame, the shame for me that He had borne.\n" +
                    "\n" +

                    "Oh let me bear thy cross dear Lord I cry, and Lord across for me up here,\n" +
                    "The one forgotten I had cast aside, the one so long that I have up here." ),

            new Drink( "111B. HERE COMES JESUS\n","111B. HERE COMES JESUS.\n\n" +
                    "\tCHORUS: " + "\n" +
                    "\tHere comes Jesus with His grace again,\n" +
                    "\tIt makes me feel so very ill, when I think how I mistreat it\n" +
                    "\tFor every time I think I find I’m at my journey’s end\n" +
                    "\tOr I pulled a boner and should be a goner\n" +
                    "\tThere’s Jesus with His grace again.\n" +
                    "\n" +

                    "Oh, woe is me too blind to see, what satan had in his pocket\n" +
                    "That little thing was a ball and a chain, on me he tried to lock it\n" +
                    "Well, I hate to admit it, but he almost did it, I was up to here in sin,\n" +
                    "He was doing well with me until, you know who walked in.\n" +
                    "\n" +

                    "All down and out, how I pout, I feel so all forsaken,\n" +
                    "Some little sin, I let get in, has got my heart to aching\n" +
                    "Well, satan is lying, there’s no use trying, His blessing you will never win,\n" +
                    "But as before, I answer my door, there’s Jesus with His grace for me.\n" ),

            new Drink( "112. GOD’S CAMEL\n","112. GOD’S CAMEL.\n\n" +
                    "You’ve heard the story of Abraham, the father, sending Eleazer out to seek a bride,\n" +
                    "For his only beloved son of promise, Jesus Christ the son of God it typifies\n" +
                    "Now I’d like to tell you more about the story, when I heard it preached I sat all amazed\n" +
                    "When he told how the servant, Eleazer, sat Rebekah on God’s camel of grace.\n" +
                    "\n" +

                    "Now the camel isn’t a beauty when beholding, He the laugh many boys and girls\n" +
                    "Just the same precious grace of Jesus, is scorned by the mockers of this world\n" +
                    "Now many people know nothing about it, nor understand what it’s designed to do\n" +
                    "But no matter how wild or wide the desert, you can rest assured that it will take you through\n" +
                    "\n" +

                    "Now the camel started quickly on the journey, His feet never sinking in the earth\n" +
                    "Each day he would take a little maiden a little farther \n" +
                    "From her place of birth He carried her by wells of Living water,\n" +
                    "His lumps were his bountiful supply\n" +

                    "And at night when the sand storms were raging, He made shelter for Rebekah at his side\n" +
                    "In many his ways are amazing, He shuts his nose the way we close our eyes\n" +
                    "When faced by the strange winds that’s blowing, He filters out the trash blowing by\n" +
                    "Each step he remembers where he’s going, and day by day he keeps a steady pace\n" +
                    "So I know you’re going to reach your destination, while riding on God camel of grace\n" +
                    "Yes, I know I’m going to reach my destination, for I’m riding on God’s camel of grace" ),

            new Drink( "113. IN JESUS NAME I PRAY\n","113. IN JESUS NAME I PRAY.\n\n" +
                    "Father give me strength to do what I must do\n" +
                    "Father give me courage to say what I must say\n" +
                    "Let your spirit move on, I’ve nothing on my own\n" +
                    "Father stand beside me, I cannot stand alone, in Jesus name I pray.\n" +
                    "\n" +

                    "Father open my eyes to your wonders all around\n" +
                    "Father let me see the good and beauty of this day\n" +
                    "Fill my heart with love for my fellow men\n" +
                    "And if I’m tempted Father, Father stay my hand, in Jesus name I pray.\n" +
                    "\n" +

                    "Father help me through the troubled days that lie ahead\n" +
                    "Let your light shine before me, that I may find the way\n" +
                    "Don’t let me stumble, Father, or fall beneath my load\n" +
                    "Father guide my footsteps and hold me to the road, in Jesus name I pray.\n" +
                    "\n" +

                    "Let not hunger be my guide nor fear be my master\n" +
                    "Father, let not envy be a part of me in any way\n" +
                    "Father, search my soul, take away my fear and doubt\n" +
                    "And any smallness thy find there, Father, cast it out, in Jesus name I pray.\n" ),

            new Drink( "114. JESUS IS YOUR SAVIOUR CHILD\n","114. JESUS IS YOUR SAVIOUR CHILD.\n\n" +
                    "Back home in Mississippi we were taught about the Lord\n" +
                    "His ways were taught on mama’s knee, good life was our reward\n" +
                    "We’d work from sun up till sundown, most each and every day\n" +
                    "When we’d get home hot and hungry and tired, mama taught us how to pray and she’d say\n" +
                    "\n" +

                    "\tCHORUS: " + "\n" +
                    "\tJesus is your Saviour child, don’t  never let Him go\n" +
                    "\tPut your life in His direction, you’ll reap what you sow\n" +
                    "\tPraise His name and praise His glory\n" +
                    "\tIt was for us that He died, He will lead us in to heaven, if we walk by His side.\n" +
                    "\n" +

                    "Now many times my mind goes back, when I am feeling low\n" +
                    "To the precious day at mama’s knee and the time we used to know\n" +
                    "How she taught us from the good book, when we might have gone astray\n" +
                    "And she’d hold us in her loving arms, and teach us all to pray and she’d say,\n" ),

            new Drink( "115. BRUSH ARBOR MEETING\n","115. BRUSH ARBOR MEETING.\n\n" +
                    "\n" +
                    "\tCHORUS: " + "\n" +
                    "\tSome glad morning when this life is over, I’ll fly away\n" +
                    "\tTo a home on God’s celestial shore, I’ll fly away.\n" +
                    "\n" +

                    "Years ago when I was a child in the Oklama hills, we didn’t have a church in which to pray\n" +
                    "So the people got together and they built one on their way, just a simple little shelter built of hay\n" +
                    "Well it wasn’t a church of the Baptist or a church of the Nazarene\n" +
                    "For people from all faith came there to pray.\n" +
                    "\n" +

                    "And it didn’t make any difference what the colour or the kind\n" +
                    "And a lot of folks would sing till break of day\n" +
                    "And they’d call it a brush arbor meeting, you could hear the people singing far away\n" +
                    "Just praising the Lord and shouting victory, I can still hear them singing this today\n" +
                    "There is power, power, wonder working power, in the blood of the Lamb x2\n" +
                    "In the precious blood of the Lamb.\n" +
                    "\n" +

                    "Nowadays the churches are so pretty and so nice,\n" +
                    "And they all have different names upon their doors\n" +
                    "How I wish that we could shout and sing like we used to long ago\n" +
                    "And come together like we did before\n" +
                    "Give me that old tome religion x3 it is good enough for me.\n" ),

            new Drink( "116. UN WORTHY AM I\n","116. UNWORTHY AM I.\n\n" +
                    "That God would send His son, for such a worthless one\n" +
                    "Unworthy am I, unworthy am I, He kindly took my place\n" +
                    "And saved me by his grace, unworthy am I.\n" +
                    "\n" +

                    "\tCHORUS: " + "\n" +
                    "\tUnworthy am I that His son should die,\n" +
                    "\tI’ll ever sing His praise,\n" +
                    "\tOh, the joys that I share, for I know I’ll be up there,\n" +
                    "\tThough unworthy am I.\n" +
                    "\n" +

                    "Defiled and no good, yet he cleansed me with his blood\n" +
                    "Unworthy am I, unworthy am I, change of heart and change of mind,\n" +
                    "Turned around to wear a crown, unworthy am I.\n" +
                    "\n" +

                    "In this land He sent the call, to one and all, to be in His arms\n" +
                    "Safe from all harm, by His life and by His love\n" +
                    "And mercy from above, He’ll take us up on high.\n" ),

            new Drink( "117. ALREADY OVER ON THE OTHER SIDE.\n","117. ALREADY OVER ON THE OTHER SIDE.\n\n" +
                    "Well I took in then old black book, and it thrilled me through and through\n" +
                    "If you’ve been saved and born again, well it’s bound to thrill you too,\n" +
                    "I was reading a long about going home, and I found to my surprise\n" +
                    "Why I’m already there in Jesus, living on the other side.\n" +
                    "\n" +

                    "\tCHORUS: " + "\n" +
                    "\tI’m already over on the other side, waiting for my brand new body\n" +
                    "\tSitting up there in the heavenly square, on the right hand of the Father\n" +
                    "\tWith my citizenship in heaven, I’m living in Christ, you see\n" +
                    "\tYes, I’m already on the other side, waiting for my body to be.\n" +
                    "\n" +

                    "Let the heathen rage, come what may, None can bother me, to this world I’m crucified\n" +
                    "With Christ at Calvary, laid three whole days, there in the grave, with Him I’ve been baptized \n" +
                    "So being then, made dead to sin, I’m living on the other side\n" +
                    "So if you are fretting or thinking of quitting, or fainting by the way.\n" +
                    "\n" +

                    "And you have already passed from death to life, well you just might as well stay\n" +
                    "The battle’s fought the victory’s won, “it’s finished” our Lord cried\n" +
                    "He’s made us more than conquerors, we are living on the other side.\n" ),

            new Drink( "118. SWEETER GETS THE JOURNEY EVERYDAY\n","118. SWEETER GETS THE JOURNEY EVERYDAY.\n\n" +
                    "Sweeter gets the journey every day, serving Jesus really pays, I get happy in this heavenly way\n" +
                    "Cause Sweeter gets the journey every day, I don’t know about you my friend,\n" +
                    "I don’t know where your journey will end, but as for me and all of mine\n" +
                    "We’re gonna make that heavenly climb, up to (up to) that heavenly shore\n" +
                    "We’ll live (we’ll live) forever more, never have a trouble, never have a care\n" +
                    "Everything will just be happiness there.\n" +
                    "\n" +

                    "Trouble and sorrow used to be a lot, I’d sit around and worry about the things I’ve not\n" +
                    "Now I count all the blessings I’ve got, and I don’t worry about the things I’ve not\n" +
                    "Some folks seek and they never find happiness and peace of mind\n" +
                    "But I have peace within my heart, since with the savior I’ve made the start.\n" ),

            new Drink( "119. LIVE, DIE, SINK OR SWIM\n","119. LIVE, DIE, SINK OR SWIM\n" +
                    "Living today, when so many have fell away, from this calling sent from God\n" +
                    "It brings these words in my heart, and they never will depart\n" +
                    "It’s live, die, sink or swim, I’m gonna follow God.\n" +
                    "\n" +

                    "\tCHORUS: " + "\n" +
                    "\tLive, die, sink or swim, I’m gonna follow God.\n" +
                    "\tI’ll stay in the calling, people think is odd\n" +
                    "\tI’ll keep pressing on until the war is won\n" +
                    "\tLive, die, sink or swim, I’m gonna follow God.\n" ),

            new Drink( "120. “THIRTY PIECES OF SILVER”\n","120. “THIRTY PIECES OF SILVER”\n\n" +
                    "Tis a sad but true story, from the Bible it came,\n" +
                    "And it tells us how Judas sold the savior in shame\n" +
                    "He planned with the council of the high priest that day\n" +
                    "Thirty pieces of silver was the price they would pay.\n" +
                    "\n" +

                    "\tCHORUS: " + "\n" +
                    "\tThirty pieces of silver, thirty shekels of shame,\n" +
                    "\tWas the price paid for Jesus, on the cross He was slain\n" +
                    "\tBetrayed and forsaken, unloved and unclaimed\n" +
                    "\tIn anger they pierced Him, but He died not in vain.\n" +
                    "\n" +

                    "T’was there on the hill side, the multitude came\n" +
                    "And found our dear Saviour, then took Him away\n" +
                    "They smote and they mocked Him,\n" +
                    "Thorns were crowned around His head,\n" +
                    "And His raiment of purple showed the blood stain of red.\n" +
                    "\n" +

                    "Far off in the mountain, with His face toward the sun,\n" +
                    "Judas begged for mercy, for what he had done,\n" +
                    "He gave back the silver, for his heart filled with strife,\n" +
                    "Then there in the mountain, he took his own life.\n" +
                    "Thirty pieces of silver, thirty shekels of shame,\n" +
                    "Was the price paid for Jesus, on the cross He was slain\n" ),

            new Drink( "121. YOU CAN LAY DOWN YOUR HEAVY LOAD WHEN YOU GET HOME\n","121. YOU CAN LAY DOWN YOUR HEAVY LOAD WHEN YOU GET HOME.\n\n" +
                    "When I’m tossed on life’s sea, and the waves cover me\n" +
                    "And the storm clouds won’t let the sunshine through\n" +
                    "Then a voice seems to say, there will be a brighter day\n" +
                    "Don’t allow the storms to hide sweet heaven’s view\n" +
                    "\n" +

                    "\t\tCause………………..\n" + "\n" +

                    "\tCHORUS: " + "\n" +
                    "\tYou’ve got one more valley, one more hill, may be one more trial, one more tear\n" +
                    "\tOne more curve in life’s road, may be one more mile to go\n" +
                    "\tYou can lay down your heavy load when you get home.\n" +
                    "\n" +

                    "Don’t let satan see your tears, learn to smile through your fears\n" +
                    "Hold your head up high and give the world a smile\n" +
                    "You must be faithful all the way, it’ll be worth it all someday\n" +
                    "Cause it’s all gonna be over in a while.\n" + "\n" +

                    "\t\tBut…………………\n" ),

            new Drink( "122. AFTER ALL OF THIS WHAT THEN \n","122. AFTER ALL OF THIS WHAT THEN.\n\n" +
                    "We have stood here in this valley, you have shown me all this land\n" +
                    "You say you own that mountain, to the smallest grain and sand\n" +
                    "Your claim is on this river, this soul so rich and rare\n" +
                    "But what about that blue sky, do you have your name up there?\n" +
                    "\n" +

                    "I’m so glad to say I know you, and I’m happy that you know me\n" +
                    "But do you know the Giver, who gave all this to thee, it’s not wrong to own this valley\n" +
                    "To have wealth is not a sin, but if your days are numbered, after all this what then?\n" +
                    "\n" +

                    "No, please don’t think I’m jealous, or I envy your success\n" +
                    "For heaven as my witness, I wish for you the best, this could be my final meeting\n" +
                    "With you my dearest friend, so I’ve got to know the answer\n" +
                    "After all of this what then, yes, I’ve got to know the answer, after all of this what then.\n" ),

            new Drink( "123. MAY BE SO SALVATION\n","123. MAY BE SO SALVATION.\n\n" +
                    "Well we meet a lot of people and we ask them where they’re going\n" +
                    "And you’d be surprised to know how many’s not knowing eternity is long and Hell is too hot\n" +
                    "To walk around wondering if you’ve got it or not, well you can have it, I don’t want it\n" +
                    "This may be so salvation.\n" +
                    "\n" +

                    "\tCHORUS: " + "\n" +
                    "\tWell, I hope so, may be so, I’m working on it trying to be\n" +
                    "\tAnd I think I have got it, but I guess I have to wait and see\n" +
                    "\tI hope to be if someday I endure, but you see right now, I’m not so sure\n" +
                    "\tYou can have it, I don’t want it, this may be so salvation.\n" +
                    "\n" +

                    "Well, I wouldn’t give a nickel for something that I couldn’t depend on, I would buy a ticket that I \n" +
                    "Could ride in on, should the pilot say, “well we might not make it” if the plane gets rough\n" +
                    "Then I can’t take it, and anytime I just might forsake it, like a may be so salvation.\n" +
                    "\n" +

                    "If people would admit it, this is really what they’re saying, “we can make it on our good works and a lot of praying” but listen, let me tell you now for what it’s worth, salvation is not a deal\n" +
                    "It’s a brand new birth, before one sees it, you got to have it first, this eternal salvation.\n" ),

            new Drink( "124. HOLD ON\n","124. HOLD ON.\n\n" +
                    "As you travel the last mile of the rough and rugged way\n" +
                    "Keep your eye upon the Saviour each and every day,\n" +
                    "He’ll never let you go, unless you want Him to\n" +
                    "By His nail scared hand He will see you through.\n" +
                    "\n" +

                    "\tCHORUS: " + "\n" +
                    "\tHold on, dear Lord, Hold on, for I am so weak and so worn\n" +
                    "\tGuide me safely over to that peaceful shore, Hold on, dear Lord, Hold on.\n" +
                    "\n" +

                    "The Saviour chose the rough and rugged way\n" +
                    "He gave His life to heal and to save\n" +
                    "In Him was no reason, that He should die\n" +
                    "Yet He did, so He could hold on.\n" +
                    "\n" +

                    "His servant for this day walks the rough and rugged way,\n" +
                    "He watches o’er His Bride day and night\n" +
                    "He prays for me and you in all that we do\n" +
                    "For He knows without God, we can’t hold on,\n" ),

            new Drink( "125. ONE WAY FLIGHT\n","125. ONE WAY FLIGHT.\n\n" +
                    "There’s a slow moving train, up to glory \n" +
                    "Chugging up that mountain, headed for home \n" +
                    "If you want to see Jesus, then get in that train \n" +
                    "And don’t you get out anymore \n" +
                    "\n" +

                    "\tCHORUS: " + "\n" +
                    "\tThere’s a one way flight going up to glory\n" +
                    "\tLanding on the center line in heaven above \n" +
                    "\tIf you want to make that flight, then have your ticket ready \n" +
                    "\tThe ticket is Agape Love.\n" +
                    "\n" +

                    "There’s a fast growing bride tree growing up to glory \n" +
                    "Climbing every limb never going wrong\n" +
                    "Every limb, higher, higher growing up to glory \n" +
                    "Won’t you be glad when we make it home.\n" +
                    "\n" +

                    "There is a calling in this land leading us to glory,\n" +
                    "Line up with every word, and you’ll never go wrong, \n" +
                    "It will take the first class bride, up on the mountain top\n" +
                    "To be with Jesus Christ, never more to roam.\n" ),

            new Drink( "126. THE FAMILY REUNION\n","126. THE FAMILY REUNION.\n\n" +
                    "\n" +
                    "\tCHORUS: " + "\n" +
                    "\tLet’s all go home to the family reunion, with mother and daddy so sweet\t\n" +
                    "\tLet’s all go home to the family reunion, this might be the last time we’ll   meet.\n" +
                    "\n" +

                    "Now mother is sick, she’s tired and weary she can’t go another mile\n" +
                    "She loves her children and she wants them near her, once more just to see their smile.\n" +
                    "\n" +

                    "What good will the roses do daddy up yonder, so why not give them today\n" +
                    "While he is still living and loving his children, to daddy its better this way.\n" ),

            new Drink( "127. THROUGH TRIALS AND TESTS\n","127. THROUGH TRIALS AND TESTS.\n\n" +
                    "Through trails and tests you’ve always been there whether I realize it or not\n" +
                    "And through the test that you have made me go higher, by putting me on the spot\n" +
                    "Applying the pressure where it needed to be, revealing not blind spots that I may see \n" +
                    "You helped me just when I needed you most.\n" +
                    "\n" +

                    "\tCHORUS: " + "\n" +
                    "\tJust when I needed you most, you sent out your helping hand \n" +
                    "\tThro’ this final calling that’s sent from God, it fit perfectly your plan\n" +
                    "\tYou helped me just when I needed you most \n" +
                    "\n" +

                    "Thro’ ups and downs you’ve always been around, bring patience within my heart\n" +
                    "You’re on my right side, you’ll always be my guide.\n" +
                    "You lifted my soul from a mire pit and now in heavenly place I sit\n" +
                    "You helped me just when I needed you needed you most.\n" +
                    "\n" +

                    "No more ups and downs its steady go, yet, changing to match the Holy Spirit flow\n" +
                    "He moves in the ways that the world don’t know, it’s simple, humble, meek and low\n" +
                    "God sent the Great Calling today to lead us into that Heavenly way,\n" +
                    "By this Guitar I will go on high to meet the Lord in the sky\n" +
                    "You helped me just when I needed you most.\n" ),

            new Drink( "128. MY JESUS, MY ALL IN ALL\n","128. MY JESUS, MY ALL IN ALL.\n\n" +
                    "You are the daddy who gently led me, you are the mother who cared and fed me \n" +
                    "You are the sister whose shoulder I could cry on, You are the brother who I rely on.\n" +
                    "\n" +

                    "\tCHORUS: " + "\n" +
                    "\tYou are a friend till the end, my guiding light,\n" +
                    "\tMy strength for the day and my rest in the night\n" +
                    "\tYou are my Jesus, you are my all in all.\n" +
                    "\n" +

                    "You are the sun shine when skies are grey, you are my comfort at the end of the way.\n" +
                    "You are the rain upon a dry, thirsty land, guiding me by your unseen hand\n" +
                    "\n" +

                    "You are this calling in this end time, no other place is there hope that I can find \n" +
                    "You are the fountain of the living water flowing freely, you are my Jesus, you are my all in all.\n" ),

            new Drink( "129. THE CRASH ON HIGH WAY\n","129. THE CRASH ON HIGH WAY.\n\n" +
                    "\n" +
                    "\tCHORUS: " + "\n" +
                    "\tI didn’t hear nobody pray my brother, I didn’t hear nobody pray,\n" +
                    "\tI heard a crash on the highway, But I didn’t hear nobody pray.\n" +
                    "\n" +

                    "I heard a crash on the highway, I knew what it was from the start,\n" +
                    "I went to the scene of destruction, and the picture was stamped on my heart\n" +
                    "There was whisky and blood run together, it was mixed with glass where they laid,\n" +
                    "Death had laid her hand in destruction, But I didn’t hear nobody pray.\n" +
                    "\n" +

                    "I wish I could change this sad story, That I’m now telling you, But there is no way I can change it, \n" +
                    "For somebody’s life is now through, Their souls had been called by their Master,\n" +
                    "They died in a crash by the way, I heard the groan of their dying, But I didn’t hear nobody pray.\n" ),

            new Drink( "130. POPLAR LOG HOUSE\n","130. POPLAR LOG HOUSE.\n\n" +
                    "Now kind friends I want to tell you of our little country home\n" +
                    "It was made of poplar logs upon a hill \n" +
                    "Now my daddy died and left us when we all were very young\n" +
                    "But my mother kept us settle on the hill.\n" +
                    "\n" +

                    "When the day’s work on the farm was done, she would gather us around,\n" +
                    "She would have us get down on our little knees\n" +
                    "She would pray for God to keep us from the night until next d ay.\n" +
                    "In our little poplar log house on the hill.\n" +
                    "\n" +

                    "Now my daddy was good man which you all would like to be\n" +
                    "When I get to Heaven, there his face I’ll see\n" +
                    "When I get through with my singing I will bid this world adieu \n" +
                    "In our little poplar log house on the hill.\n" +
                    "\n" +

                    "H m m m m m m m m m m m m m m m m m m m m m m m m m m m m m m m m m\n" +
                    "m m m m m m m m m m m m m m m m m m m m m m m m m m m  x2\n" ),

            new Drink( "131.  HELP ME UNDERSTAND\n","131.  HELP ME UNDERSTAND.\n\n" +
                    "\n" +
                    "\tCHORUS: " + "\n" +
                    "\tA little girl prayed at the close of the day cause her daddy had gone far away\n" +
                    "\tOn her little face was a look of despair , I stood there and listen and I heard this prayer\n" +
                    "\tMy Mom said “daddy has brought us shame”  \n" +
                    "\tAnd I’m never no more to mention his name\n" +
                    "\tLord, take me and lead me and hold to my hand, Oh Heavenly father, help me    understand " +
                    "\t(talking)\n" +
                    "\n" +

                    "You know friends, I wonder how many homes are broken tonight \n" +
                    "And just how many tears and shed by some little word of anger,\n" +
                    "That never should have been said \n" +
                    "I’d like to tell a story of a family I once knew,\n" +
                    "We’ll call them Mary and William and their little daughter, Sue.\n" +
                    "\n" +

                    "Now Mary was just a plain mother and Bill,\n" +
                    "Well was just a usual dad. And they had their little family quarrels,\n" +
                    "Like everybody else, but neither really got mad.\n" +
                    "But one day something happened, it was nothing of course,\n" +
                    "But one word lead to another and the last word led to divorce \n" +
                    "\n" +

                    "Now here were grown up people who failed to use common sense \n" +
                    "They strengthened their own pride at little Sue’s expense\n" +
                    "You know she didn’t ask to be brought into this world, to drift from pillar to post,\n" +
                    "But a divorce never stops to consider the ones it hurts the most \n" +
                    "There’d be a lot more honest loving in this wicked old world today,\n" +
                    "If just a few parted parents could hear little Sue say.  \n" ),

            new Drink( "132. THE LORD WILL MAKE AWAY\n","132. THE LORD WILL MAKE AWAY.\n\n" +
                    "Like a ship that’s tossed and driven, scattered by an angry sea,\n" +
                    "When the storms of life are ragging, and its fury on me,\n" +
                    "I wondered just what I done to make this race so hard to run,\n" +
                    "And then I tell my soul take courage, for the Lord will make a way somehow.\n" +
                    "\n" +

                    "\tCHORUS: " + "\n" +
                    "\tOh, the Lord will make away somehow, when beneath the cross I bow,\n" +
                    "\tHe will take away each sorrow, won’t you let Him have your burden now\n" +
                    "\tWhen the load become so heavy, the weight is shown upon my brow\n" +
                    "\tThere is a sweet relief in knowing that the Lord will make a way somehow.\n" +
                    "\n" +

                    "I try to do my best in service, I try to do the best I can\n" +
                    "But when I choose to do the right thing, there’s evil on every hand\n" +
                    "I look up and wonder why, all good fortunes pass me by\n" +
                    "But then I tell my soul take courage, for the Lord will make a way somehow.\n" +
                    "\n" +

                    "Often there’s misunderstanding, out of all the good that I do,\n" +
                    "I got friends for consolation, and I find them complaining too,\n" +
                    "So many nights I toss in pain, wondering what the day will bring,\n" +
                    "But then I say to my soul take courage, for the Lord will make a way somehow.\n" ),

            new Drink( "133. DAY OF WRATH\n","133. DAY OF WRATH.\n\n" +
                    "Blow ye the trumpet in Zion, the Lord is coming to earth again\n" +
                    "In the Holy hill sounding the warning, to all those who ever God may send.\n" +
                    "\n" +

                    "\tCHORUS: " + "\n" +
                    "\tTell your children and your children’s children, of the second coming of our King,\n" +
                    "\tHe’ll stand upon the Mount of Olives, salvation to a dying world to bring.\n" +
                    "\n" +

                    "Joel prophesied in all his wisdom, that if we fail to walk the righteous path\n" +
                    "It’ll be too late to beg for mercy, at the dawning of the day of wrath.\n" ),

            new Drink( "134. THIS WORLD HAS TURNED ME DOWN.\n","134. THIS WORLD HAS TURNED ME DOWN.\n\n" +
                    "This world has turned me down, I wondered all alone, hang my head and cry\n" +
                    "I have no friend nor home, the sunset trial I’m travelling, and I’m near the end I know\n" +
                    "For this world has turned me down and I’m ready Lord to go.\n" +
                    "\n" +

                    "\tCHORUS: " + "\n" +
                    "\tOh Lord look down on me, have mercy on my soul\n" +
                    "\tThis world has turned me down, I’m hungry and I’m cold\n" +
                    "\tMy feet are getting dreary and I’m feeling mighty low\n" +
                    "\tFor this world has turned me down and I’m ready Lord to go.\n" +
                    "\n" +

                    "I stopped at the rich man’s gate, I gaze at his mansion fine, his shelter from the cold\n" +
                    "He sits and drinks his wine, my treasures are in heaven for I’ve nothing here below\n" +
                    "For this world has turned me down and I’m ready Lord to go.\n" +
                    "\n" +

                    "So come a little closer, ye snow white angel band\n" +
                    "And bear me on your wings up to that blessed land\n" +
                    "Swing wide the gates of heaven for I’m near the end I know\n" +
                    "For this world has turned me down and I’m ready Lord to go.\n" ),

            new Drink( "135. THE ANGEL OF DEATH\n","135. THE ANGEL OF DEATH.\n\n" +
                    "In the great book of John you’re warned of the day, when you’ll be laid beneath the cold day\n" +
                    "The angel of death will come from the sky, and claim your poor soul, when the time comes to die\n" +
                    "\n" +

                    "\tCHORUS: " + "\n" +
                    "\tWhen the angel of death comes down after you\n" +
                    "\tCan you smile and say that you have been true?\n" +
                    "\tCan you truthfully say with your dying breath?\n" +
                    "\tThat you’re ready to meet the angel of death?\n" +
                    "\n" +

                    "When the lights all grow dim and the dark shadow creep\n" +
                    "And then your loved ones are gathered to weep\n" +
                    "Can you face them and say, with your dying breath, that you’re ready to meet the angel of death?\n" ),

            new Drink( "136. ANNIVERSARY SONG\n" +
                    "(Odell and Emma Federick)-(Married-1944)\n","136. ANNIVERSARY SONG.\n\n" +
                    "(Odell and Emma Federick)-(Married-1944)\n" +
                    "Odell Federick and Emma his wife together they lived an example of life,\n" +
                    "Modest in things of the world they possess, but rich because God is so faithful to bless.\n" +
                    "\n" +

                    "\tCHORUS: " + "\n" +
                    "\tLoving and tender kind hearted are they\n" +
                    "\tPraising the Lord for whatever comes their way\n" +
                    "\tThese two like Mother and Daddy to me,\n" +
                    "\tAre so full of God, God is all that I see.\n" +
                    "\n" +

                    "Storing up treasures that thieves cannot steal, but pouring out love that people can feel\n" +
                    "Like Paul the Apostle, God strength is made known,\n" +
                    "In these who are perfectly weak on their own.\n" +
                    "\n" +

                    "God called his man and with him his wife, who for ……..years have lived such a life\n" +
                    "That people all over the world can believe, there’s a place up on high, that we can receive.\n" +
                    "On this special day that marks…….years, my heart is so thankful my eyes filled with tears\n" +
                    "For, God has a man and a woman to give, as a perfect example of how we must live.\n"),

            new Drink( "137. WAY UP ON THE MOUNTAIN\n","137. WAY UP ON THE MOUNTAIN.\n\n" +
                    "\n" +
                    "\tCHORUS: " + "\n" +
                    "\tI was down in the valley, way down in the valley\n" +
                    "\tWhen the Saviour heard my feeble cry\n" +
                    "\tNow I’m back up on the mountain, way up on the mountain\n" +
                    "\tDrinking from the fountain that never will run dry.\n" +
                    "\n" +

                    "There was darkness all around me, when my Saviour found me\n" +
                    "Way down in the valley of despair, when I told Him all my troubles\n" +
                    "My joys then doubled, I’m way up on the mountain, rejoicing in His care.\n" +
                    "\n" +

                    "If you don’t watch old satan, he’ll get you in the valley\n" +
                    "And hide you from the Saviour’s guiding light, but he will stay behind you,\n" +
                    "And will never find you, way up on the mountain, if you fight the good fight.\n" ),

            new Drink( "138. WHERE WILL I SHELTER MY SHEEP TONIGHT\n","138. WHERE WILL I SHELTER MY SHEEP TONIGHT.\n\n" +
                    "\n" +
                    "\tCHORUS: " + "\n" +
                    "\tWhere will I shelter my sheep tonight? Where is that peaceful land?\n" +
                    "\tWhere will I shelter my sheep tonight? Where the beasts won’t steal all my \tlambs\n" +
                    "\n" +

                    "My soul is weak and thirsty too, as I cross the burning sand,\n" +
                    "Where will I shelter my sheep tonight? Where is that peaceful land?\n" +
                    "\n" +

                    "We’ve travelled far, shepherd, dog and I, weary, sin sick and sore\n" +
                    "Where will I shelter my sheep tonight? I’ll shelter my sheep at God’s door.\n" ),

            new Drink( "139. THREE DEAD FISHERMEN\n","139. THREE DEAD FISHERMEN.\n\n" +
                    "Three dead fishermen were fishing in the sea, along came the man from Galilee\n" +
                    "They left their nets and they left their knives, to follow Him and He gave them life.\n" +
                    "To follow Him and He gave them life.\n" +
                    "\n" +

                    "These three men, Peter, James and John, two of whom were Zebedee’s sons\n" +
                    "You’d never heard about these three men, had they kept a fishing from the boat they were in\n" +
                    "Had they kept a fishing from the boat they were in\n" +
                    "\n" +

                    "A lot more fishermen better than they, caught more fish but forgotten today\n" +
                    "With their hands on the rod and their eyes on the tide, didn’t see the Saviour when He passed by.\n" +
                    "Didn’t see the Saviour when He passed by.\n" +
                    "\n" +

                    "Yes, these three men, Peter, James and John, two of whom were Zebedee’s sons\n" +
                    "Had they kept a fishing from the boat they were in, today they would just be three dead men.\n" +
                    "Today they would just be three dead men.\n" +
                    "\n" +

                    "If you be here and hear my song, searching for a life that will keep a living on\n" +
                    "Leave your nets like the three fishermen, follow this man from Galilee.\n" +
                    "Follow this man from Galilee.\n" ),

            new Drink( "140. BE CAREFUL OF STONES THAT YOU THROW\n","140. BE CAREFUL OF STONES THAT YOU THROW.\n\n" +
                    "\n" +
                    "\tCHORUS: " + "\n" +
                    "\tA tongue can accuse and carry bad news, the seeds of distrust it will sow\n" +
                    "\tBut unless you’ve no mistake in your life, be careful of the stones that you throw.\n" +
                    "\n" +

                    "A neighbor was passing by my garden on time, she stopped and I knew right of way\n" +
                    "That it was gossip, not flowers, she had on her mind, and this is what I heard my neighbor say\n" +
                    "“That girl down the street should be run from our midst, she drinks and she talks quite a lot”\n" +
                    "She knows not to speak to my child or to me, my neighbor then smiled and I thought.\n" +
                    "\n" +

                    "A car speeded by and a screaming of brakes, a sound that makes my blood chill,\n" +
                    "For my neighbour’s one child had been pulled, from the path and saved by a girl lying still\n" +
                    "The child was unhurt and my neighbor cried out, “oh, who was that brave girl so sweet”\n" +
                    "I covered the crushed broken body and said “That bad girl who lives down the street”\n" ),

            new Drink( "141. HE’S LEADING ME HOME\n","141. HE’S LEADING ME HOME.\n\n" +
                    "Have you ever known the touch of the Saviour’s hand?\n" +
                    "He’s leading me home, He’s leading me home,\n" +
                    "Guiding me by His unseen hand, thru’ trials I don’t understand\n" +
                    "He’s leading me home, He’s leading me home.\n" +
                    "\n" +

                    "\tCHORUS: " + "\n" +
                    "\tHe’s leading me home to that happy land above\n" +
                    "\tHe’s leading me home to perfect agape love\n" +
                    "\tHe’s leading me home up upon high, by His grace, He’s leading me home.\n" +
                    "\n" +

                    "As I journey thro’ this life, thro’ peace and the strife,\n" +
                    "He’s leading me home, He’s leading me home,\n" +
                    "Thro’ the good and the bad, the happy and the sad\n" +
                    "He’s leading me home, He’s leading me home.\n" +
                    "\n" +

                    "God sent the calling to the land, thro’ an odd simple man\n" +
                    "By this guitar, He’ll lead us home\n" +
                    "By this standard, He’ll deliver His bride,\n" +
                    "And make her ready for the midnight cry\n" +
                    "And carry her home, and carry her home.\n" ),

            new Drink( "142. BE GRATEFUL\n","142. BE GRATEFUL.\n\n" +
                    "A blind man can’t see flowers growing in a garden, a crippled man can’t walk to places where he wants to go, a man that can’t talk, things he will never say\n" +
                    "And a man that can’t hear, words he will never know.\n" +
                    "\n" +

                    "\tCHORUS: " + "\n" +
                    "\tSo if you can see, and if you can walk, if you can hear and if you can talk\n" +
                    "\tThen be grateful, be grateful for what you’ve got.\n" +
                    "\tCause to some folks these things would mean a lot.\n" +
                    "\n" +

                    "I once heard a man say, “All he wanted out of life was money”\n" +
                    "To be the richest man, have wealth and fame untold\n" +
                    "But he could see and he could walk, he could hear and he could talk\n" +
                    "And to some folks this would mean more than gold.\n" ),

            new Drink( "143. MOST RICHLY BLESSED\n","143. MOST RICHLY BLESSED.\n\n" +
                    "I asked for strength that I might achieve,\n" +
                    "I was given weaknesses that I might learn humbly to obey\n" +
                    "I asked for health that I might do great things\n" +
                    "I was given infirmity that I night have the praise of men\n" +
                    "I was given poverty that I might be wise\n" +
                    "I asked for power that I might have praise of men\n" +
                    "I was made weak that I might feel the need of God\n" +
                    "I asked for all things that I might enjoy life, I was given life that I might enjoy all things\n" +
                    "I got nothing that I asked for, but everything I’d hoped for\n" +
                    "And almost despised myself, I among men, am most richly blessed.  \n" ),

            new Drink( "144. KIND SHEPHARD\n","144. KIND SHEPHARD.\n\n" +
                    "The shepherd looked down, from His pasture above\n" +
                    "He saw a little sheep, unclaimed and unloved\n" +
                    "He could have left him to die alone, but the Shepherd called his name\n" +
                    "And he followed Him home.\n" +
                    "\n" +

                    "\tCHORUS: " + "\n" +
                    "\tKind Shepherd, feed him in pastures so green\n" +
                    "\tLet him drink the water from the clear crystal stream\n" +
                    "\tLet him roam through the fields, where the soul is free\n" +
                    "\tKind Shepherd, feed him in pastures so green\n" +
                    "\n" +

                    "He sought for peace in a far distant land, He strove for the touch of a kind friendly hand\n" +
                    "But then he met Jesus and somehow he knew, that his soul had found peace\n" +
                    "And his searching was through.\n" ),

            new Drink( "145. SWING WIDE THE GATES\n","145. SWING WIDE THE GATES.\n\n" +
                    "Heaven gates I now can see, as they open wide for me, swing wide the gates, I’m coming home\n" +
                    "Angels sing a welcome song, and I know it can’t be long, swing wide the gates, I’m coming home.\n" +
                    "\n" +

                    "\tCHORUS: " + "\n" +
                    "\tSwing wide the gates, I’m coming home, swing wide the gates, I’m one of His own\n" +
                    "\tI’ve fought a good fight, I’ve kept the faith, the amazing grace has won the race,\n" +
                    "\tSwing wide the gates, I’m coming home.\n" +
                    "\n" +

                    "What a day that will be, when I cross the mystic sea, swing wide the gates, I’m coming home\n" +
                    "All is peace and Joy up there, in a land of beauty rare, swing wide the gates, I’m coming home.\n" ),

            new Drink( "146. DO YOU WONDER WHY I SING\n","146. DO YOU WONDER WHY I SING.\n\n" +
                    "Do you wonder why I sing my desire is to give Christ every thing\n" +
                    "He died on the cross for me and that’s why I love Him so.\n" +
                    "\n" +

                    "Earthly things will pass away, they cannot satisfy my soul the vacuum is left for the Lord\n" +
                    "That thirst of the living word.\n" +
                    "\n" +

                    "There are a lot of things in this world and cannot fill the vacuum\n" +
                    "It was prepared for the Lord to fill it up, and nothing else.\n" +
                    "\n" +

                    "As I remember how the woman at the well had thirst in her heart, until she went to look for water\n" +
                    "When she met Him Jesus Christ there the vacuum was filled.\n" ),

            new Drink( "147. GET OUT OF HOG PEN\n","147. GET OUT OF HOG PEN.\n\n" +
                    "There was a very young man in the Bible, no difference than me and you\n" +
                    "He took this awful sinful world, to do what he wanted to\n" +
                    "He was doing fine in the Father’s house, never no need to go\n" +
                    "But he had some money that he wanted to spend, and someone oats that he wanted to sow.\n" +
                    "\n" +

                    "\tCHORUS: " + "\n" +
                    "\tCome on, getup, get out of that hog pen, you know it’s not the place to be\n" +
                    "\tFor there’s a robe and a ring and a mansion, and a Father who’s waiting for thee\n" +
                    "\tWhy don’t you quit eating that garbage, and leave that mess behind\n" +
                    "\tDon’t you get tired of sleeping in the mud, and wallowing with them swine?\n" +
                    "\n" +

                    "So gathering all of his belongings, he told his daddy “goodbye”\n" +
                    "Why, he had the fair-weather friends that his money could buy\n" +
                    "Soon wasted all of his substance, He dropped like a falling pig\n" +
                    "And his very best meal was corn on the cob, and his closest friend was a pig.\n" ),

            new Drink( "148. HEAVEN’S VERY BEST\n","148. HEAVEN’S VERY BEST.\n\n" +
                    "God did not choose the pearly gates, or heaven’s streets of gold, to send to earth to pay the\n" +
                    "Price, for my eternal soul, he did not send an angel, or any of the rest\n" +
                    "But He gave His only son, Heaven’s very best.\n" +
                    "\n" +

                    "\tCHORUS: " + "\n" +
                    "\tThere never was a water that could wash my sins away\n" +
                    "\tOr anything I might have done to save and keep me saved\n" +
                    "\tIt was to be a perfect work of God and nothing less, so He gave His only son\n" +
                    "\n" +

                    "Heaven’s very best it’s good to know without a doubt, He\\s everything to me.\n" +
                    "More precious though, we are to Him, just look at Calvary, oh what great assurance\n" +
                    "Peace and happiness, to know that we have been redeemed, with Heaven’s very best.\n" +
                    "\n" +

                    "Salvation’s not a state of mind, or any of that sort, nor is it reformation, it’s Jesus in your heart,\n" +
                    "Christ must dwell within you, God’s own righteousness\n" +
                    "Yes, you must be born again, of Heaven’s very best." ),

            new Drink( "149. THE SUN’S COMING UP\n","149. THE SUN’S COMING UP.\n\n" +
                    "Once again I faced satan this morning, and battled him all the day long,\n" +
                    "But in my weakness, God sent reinforcement, and at sun down I sung victory songs.\n" +
                    "\n" +

                    "\tCHORUS: " + "\n" +
                    "\tAnd the sun’s coming up in the morning, every tear will be gone from my eyes\n" +
                    "\tThis old clay’s gonna give way to glory, and like an eagle I’ll take to the sky.\n" +
                    "\t\n" +

                    "In this world filled with doubts and confusion, it’s so hard when you don’t understand,\n" +
                    "Oh, but I’ll stand on a solid foundation, and I’ll hold to an unchanging hand.\n" ),

            new Drink( "150. DID YOU EVER LOOK UP TO THE SKY\n","150. DID YOU EVER LOOK UP TO THE SKY.\n\n" +
                    "Did you ever look up to the sky, and behold the beauty there\n" +
                    "Not many people put their sight on high, nor can see God anywhere \n" +
                    "But God’s seed shall praise Him for their breadth, and they know He dwells within\n" +
                    "And through sinless days they stay the face of death, for they see Him everywhere.\n" +
                    "\n" +

                    "Did you ever sit down on the ground, and humble yourself there\n" +
                    "Not many people want to sit so long, nor can see that God is there\n" +
                    "But God’s seed shall praise Him for His love, and they love every man\n" +
                    "And through cloudy days they shake the devil’s ground, for they know God is everywhere\n" ),

            new Drink( "151. HE IS RISEN, HE IS ALIVE\n","151. HE IS RISEN, HE IS ALIVE.\n\n" +
                    "As I wondered all alone, nowhere to call my home\n" +
                    "As I wondered all about, my life filled with fear and doubt\n" +
                    "Then I heard the Saviour say, my child I am the way\n" +
                    "For I am risen I’m alive today.\n" +
                    "\n" +

                    "\tCHORUS: " + "\n" +
                    "\tHe is risen, He’s a live, He’s living now in me\n" +
                    "\tHe is risen, He’s a live, from sin I’ve been set free,\n" +
                    "\tOh, praise His Holy name, I’ll never be the same,\n" +
                    "\tHe is risen, He’s alive in me.\n" +
                    "\n" +

                    "Thro’ temptations, trials or strife, He is with me day and night\n" +
                    "By His mercy and His love, He’ll always guide me right\n" +
                    "Nevermore am I alone, He with His blood my sin atone,\n" +
                    "For He is risen, He’s a live, I am His own.\n" +
                    "\n" +

                    "Thro’ the Calling in this day, He is showing His bride the way,\n" +
                    "To that blessed promised land, to a home not built by a man,\n" +
                    "He is calling us up on high, where we’ll never say goodbye,\n" +
                    "And forever sing praise to Him.\n" ),

            new Drink( "152.  ONE DAY I WAS LOST IN SIN\n","152.  ONE DAY I WAS LOST IN SIN.\n\n" +
                    "One day I was lost in sin all along,\n" +
                    "Jesus came along to take me home\n" +
                    "And he showed me I could be free,\n" +
                    "But the devil came by and said it could not be\n" +
                    "\n" +

                    "\tCHORUS: " + "\n" +
                    "\tSo there I was between the two,\n" +
                    "\tIt would really deceive that I was confused \n" +
                    "\tAnd I looked back I wasn’t bad,\n" +
                    "\tBut that was one way the old devil could make us sad.\n" +
                    "\n" +

                    "So look up my friend or the devil will win.\n" +
                    "Our soul to hell before we can win\n" +
                    "Look out for sin and leave it alone\n" +
                    "Jesus will come and take us home.\n" +
                    "\n" +

                    "If the devil could make us believe,\n" +
                    "That we were alright we would be deceived\n" +
                    "So look-out for the devil he’s a snicky guy\n" +
                    "He will take your soul to hell when you die\n" ),

            new Drink( "153. HE HAS CALLED ME BY HIS NAME\n", "153. HE HAS CALLED ME BY MY NAME.\n\n" +
                    "I am singing and rejoicing every passing day, \n" +
                    "For I have a consolation strong and secure\n" +
                    "For the feeling pains at time are sweetly pass away\n" +
                    "All the promises of God remain secure.\n" +
                    "\n" +

                    "\tCHORUS: " + "\n" +
                    "\tHe has called me by my His and I am His\n" +
                    "\tWhat a consolation to my heart this is\n" +
                    "\tAnd the flood shall not off flow to defile me as I go,\n" +
                    "\tHe has called me by my name and I am His.\n" +
                    "\n" +

                    "I belong to the one whose might can never measured be\n" +
                    "He is able to deliver from all harm\n" +
                    "I am a heir of life eternal for eternity,\n" +
                    "And I am leaning on the everlasting arm\n" +
                    "\n" +

                    "And when I am passing through this world he will be my guide\n" +
                    "And the river shall not over-flood my soul\n" +
                    "In the burning ferry furnace He is by my side\n" +
                    "He will lead me up triumphantly to my goal.\n"),

            new Drink( "154. LET THE DEATH ANGEL PASS\n","154. LET THE DEATH ANGEL PASS.\n\n" +
                    "The Lord spoke to Moses, and told him what to say\n" +
                    "To the children of Israel in Goshen that day\n" +
                    "Slay the lamb take the blood, smite the post of the door\n" +
                    "For I’ll pass through Egypt this night, and smite all the first born\n" +
                    "\n" +

                    "\tCHORUS: " + "\n" +
                    "\tLet the death angel pass, God’s bride safe at last\n" +
                    "\tIn the token He gave, that we could be safe,\n" +
                    "\tOh, hallelujah and glory to God, the blood’s been applied,\n" +
                    "\tGod’s spirit abides, let the death angel pass.\n" +
                    "\n" +

                    "The sweet Holy Spirit, is the token today\n" +
                    "And those who are under it, God said would be saved\n" +
                    "Outside of this token, the lost will be found\n" +
                    "If you want your loved ones in, you better get them in now.\n" ),

            new Drink( "155. BE YE VIGILANT\n","\n" +
                    "155. BE YE VIGILANT.\n\n" +
                    "Unto you all who have received this message, unto you all who have accepted Brother Branham,\n" +
                    "Unto you all who have received this Calling, unto you all who have accepted Brother Federick\n" +
                    "\n" +

                    "\tCHORUS: " + "\n" +
                    "\tBe ye vigilant for the Lord will come in the morning\n" +
                    "\tHe’ll come in the morning, He’ll carry us home.\n" +
                    "\tTo stay with the Father above, He’ll not tarry, He’ll not tarry.\n" +
                    "\n" +

                    "Be ye strong unto the end, for the battle is almost over\n" +
                    "And the Lord will come and carry us home, stay firm to the message you have heard\n" +
                    "\n" +

                    "Stay true to this great calling, pray for the Servant of God Brother Federick\n" +
                    "God will bless you and keep you in this calling, for this calling is all what you need.\n" ),

            new Drink( "156. BECAUSE HE LIVES \n","156. BECAUSE HE LIVES.\n\n" +
                    "God sent His son, they call Him Jesus, He came to love, heal and forgive\n" +
                    "He bled and died, to buy my pardon, an empty tomb is there to prove my Saviour lives.\n" +
                    "\n" +

                    "\tCHORUS: " + "\n" +
                    "\tBecause He lives, I can face tomorrow, Because He lives, all fear is gone,\n" +
                    "\tBecause I know, He holds the future, and life is worthy a living simply because He lives.\n" +
                    "\n" +

                    "How sweet to hold, our new born baby, and feel the pride and joy He gives\n" +
                    "But greater still, this firm assurance, this child can face uncertain days because He lives.\n" +
                    "\n" +

                    "And then one day, I’ll cross the river, and fight life’s final war with pain\n" +
                    "And then as death gives way to victory, I’ll see the gates of glory land and I know He lives.\n" ),

            new Drink( "157. MY COAT OF MANY COLOURS\n","157. MY COAT OF MANY COLOURS.\n\n" +
                    "Back through the years I go wondering, once again, back to the seasons of my youth\n" +
                    "I recall a box of rags someone gave us, and help my mama put those rags to use\n" +
                    "They were rags of many colours, every piece was small. I didn’t have a coat indeed was way down\n" +
                    "In the cold, mama sew the rags together, sowed every piece with love\n" +
                    "She made my coat of many colours that I was so proud of.\n" +
                    "\n" +

                    "\tCHORUS: " + "\n" +
                    "\tAnd she so, she told the story, from the Bible she had read\n" +
                    "\tAbout the coat of many colours, just before them risk she said\n" +
                    "\tThrough halves these clothes to bring you through love and happiness\n" +
                    "\tAnd I just couldn’t wait to wear it, mama blessed it with the king.\n" +
                    "\n" +

                    "My coat of many colours that my mama made for me, made from only rags, but I wore it so proudly,\n" +
                    "although we had no money, I was rich as I could be, in my coat of many colours  my mama made for me.\n" +
                    "So with patches on my bleaches, holes in my shoes, my coat of many colours, I hurried \n" +
                    "up to school, just to find the others laughing and making fun of me,\n" +
                    "In my coat of many colours my mother made for me.\n" +
                    "\n" +

                    "Oh I couldn’t understand it I felt that I was rich, and I told them of the love my mama \n" +
                    "sowed them every stitch, I told them of the story mama told me while she sowed, and \n" +
                    "now my coat of many colours worthy more than all my clothes.\n" +
                    "\n" +

                    "But I didn’t understand it and I tried to make them see, the world is only poor only if they\n " +
                    "chose to be, oh I know we had no money I was rich as I could be in my coat of many colours\n " +
                    "my mama made for me.\n" ),

            new Drink( "158. COME FOLLOW ME\n","158. COME FOLLOW ME.\n\n" +
                    "Wasted days, wasted months, wasted years of time, walking aimlessly\n" +
                    "Searching endlessly, only trying to have a good time, never realizing that the road I was\n " +
                    "on was that broad road many would find then in love one day I heard the Saviour say, \n" +
                    "“son I want you to one of mine”\n" +
                    "\n" +

                    "\tCHORUS: " + "\n" +
                    "\tCome follow me, leave your life of sin and sorrow\n" +
                    "\tCome follow me, that is all I require of thee\n" +
                    "\tCome follow me, as I climb that hill called Golgotha\n" +
                    "\t“Come follow me” saith the Lord.\n" +
                    "\n" +

                    "Many years I spent with a good intent, saying Jesus was really mine\n" +
                    "With my head held high, telling all who passed by, of the Saviour they needed to find\n" +
                    "Thinking all I had done, and the victories I’d won, was the way that my life should be\n" +
                    "Till I heard Him say, son works are fine.\n" +
                    "\n" +

                    "\tBut that doesn’t make you one of mine\n" +
                    "\tCome follow me, leave your life of toils and trails\n" +
                    "\tCome follow me, that is all I require of thee\n" +
                    "\tCome follow me, as I climb that hill called Golgotha\n" +
                    "\t“Come follow me” saith the Lord.\n" +
                    "\n" +

                    "When I realized how He looked at my life, I said “Lord what wilt thou have me do”\n" +
                    "I believed all I heard, from your Holy word, and I followed the best that I knew\n" +
                    "Though I did all that I could, I never understood what He was really requiring of me\n" +
                    "Till I heard His cry, “son you’ve got to die”, or you’ll never be one of mine.\n" +
                    "\n" +

                    "\tCome follow me lift your cross and simply follow me \n" +
                    "\tCome follow me, that is all I require of thee\n" +
                    "\tCome follow me, as I climb that hill called Golgotha\n" +
                    "\t“Come follow me” saith the Lord.\n" +
                    "\n" +

                    "Come follow me, there’s a life for all who follow, Come follow me, step by step to eternity\n" +
                    "Come follow me, climb the hill and have your Golgotha, Come follow me, saith the Lord.\n" ),

            new Drink( "159. TADLUS WAGON\n","159. TADLUS WAGON.\n\n" +
                    "Once I heard a tadlus wagon, which behind me I did pull, as fast as I could empty it\n" +
                    "Some prince would fill it full, and I got so busy, there was little else to do\n" +
                    "But still I admit the saints would see, I’m going through with Jesus, I’m going through.\n" +
                    "Well I was going through, and tattling as I went, but going through like that you know isn’t worth a cent, I talk about my neighbor, they give me titles to do\n" +
                    "And then they go to church and sing, and His blood washes whiter than snow\n" +
                    "I sometimes testifies and prays, some could cease to doubt, and others have no confidence\n" +
                    "When certain part is said, if someone heals some little luck, on some good reason told\n" +
                    "He rules his wagon up and sings, when we all see Jesus, we will sing and shout the victory.\n" +
                    "\n" +


                    "We back our wagons back, and get another load, and just as soon as we could go, \n" +
                    "we would start on this road, and when we met a passer-by, we would stop and spread them too,\n" +
                    "and some people pulled out sing, makes me love everybody x3, it’s good enough for me.\n" +
                    "All the things that we should do is smash those wagons now, and each one bridle his own tongue,\n" +
                    "stop these things somehow, and stop this awful tattling, let’s bring it to an end \n" +
                    "and we can meet the saints,and then sing, in the sweet by and by, we shall meet on that beautiful shore.\n" ),

            new Drink( "160. SWEET BY AND BY\n","160. SWEET BY AND BY.\n\n" +
                    "I’ll have faith, help me to have faith in you Lord, when the things of this world humble down,\n" +
                    "Let me see your presence in me, and know you Lord are always around\n" +
                    "Sometimes the load I can’t carry, but with you I can be made strong.\n" +
                    "\n" +

                    "\tCHORUS: " + "\n" +
                    "\tLord I know without you I’m nothing, longing for home,\n" +
                    "\tI’ll have faith in you Lord when I’m weary, I’ll have faith in you Lord, when I’m sad\n" +
                    "\tI’ll just cling to the Rock of Ages, I’ll have faith and for you firmly I stand.\n" ),

            new Drink( "161. PINE LOG CABIN\n","161. PINE LOG CABIN.\n\n" +
                    "There is a little pine log cabin, waiting down the well known valley\n" +
                    "There’s an open door opened when my life’s o’er I’m going back home\n" +
                    "There’s a mother daily praying, waiting for my homeward straying\n" +
                    "To the little pine log Cabin at the end of lane.\n" +
                    "\n" +

                    "\tCHORUS: " + "\n" +
                    "\tI long to see the children playing, by the weeping without straying\n" +
                    "\tIf my mother is lovely while I’m helping so sweet (so sweetly)\n" +
                    "\tI’m hurrying to the journey just to be again returning\n" +
                    "\tTo the little pine log Cabin at the end of lane.\n" +
                    "\n" +

                    "Often when alone I still dream of the days as I go…………………\n" +
                    "With my daddy and mother and my little brothers happy and good\n" +
                    "I can see the shadow falling and I hear the voice that’s calling\n" +
                    "From the little pine log Cabin at the end of lane.\n" +
                    "\n" +

                    "There is a little red light shining, there is a little………………wondering\n" +
                    "Down the little valley to the little cabin, peaceful and still\n" +
                    "……………………..vines are growing and the lights should be going\n" +
                    "To the little pine log Cabin at the end of lane.\n" ),

            new Drink( "162. SPEAK TO THE ROCK\n","162. SPEAK TO THE ROCK.\n\n" +
                    "Moses and the children when they came to the sea\n" +
                    "He spoke to the rock and the red sea was parted\n" +
                    "He spoke to the rock and came to the well, he came to the well that will never run dry\n" +
                    "\n" +

                    "\tCHORUS: " + "\n" +
                    "\tSpeak to the rock my brother and come to the well\n" +
                    "\tSpeak to the rock my sister and come to the well\n" +
                    "\tSpeak to the rock and come to the well, come to the well that will never run dry.\n" +
                    "\n" +

                    "Daniel the Prophet when he spoke to the rock, he spoke to the rock and the lions retreated\n" +
                    "He spoke to the rock and came to the well, he came to the well that will never run dry\n" +
                    "\n" +

                    "Shadrack and Meshack and Abednego too,\n" +
                    "They spoke to the rock and the fire could not burn them\n" +
                    "They spoke to the rock and came to the well, they came to the well that will never run dry\n" +
                    "\n" +
                    "Be known you’re my children and speak to the rock, speak to the rock and the troubles will vanish\n" +
                    "Spoke to the rock and came to the well, you’ll come to the well that will never run dry\n" ),

            new Drink( "163. SORRY I NEVER KNEW YOU\n","163. SORRY I NEVER KNEW YOU.\n\n" +
                    "At night as I laid sleeping a dream came to me, I dreamed about the end of time about eternity\n" +
                    "I saw a million sinners fall on their knees to pray\n" +
                    "The Lord sadly shook His head and I heard Him say,\n" +
                    "\n" +

                    "\tCHORUS: " + "\n" +
                    "\tSorry, I never knew you, depart from me forever more,\n" +
                    "\tSorry, I never knew you, go serve the one that you served down before.\n" +
                    "\n" +

                    "I thought the time had fully come that I must stand the trial,\n" +
                    "I told the Lord that I had been a Christian all the while,\n" +
                    "But through this book He took a look then sadly shook His head,\n" +
                    "Then placed me over His left and this I heard Him say,\n" +
                    "\n" +

                    "\tSorry, I never knew you, I found no record of you there,\n" +
                    "\tSorry, I never knew you, go serve the one that you served down before.\n" +
                    "\n" +

                    "There were my wife and children, I heard their loving voice,\n" +
                    "They must have been so happy oh how they did rejoice,\n" +
                    "There was a wire around them, their voices were glowing\n" +
                    "My little girl looked and passed me and this is what she said.\n" ),

            new Drink( "164. LAY YOUR BURDENS\n","164. LAY YOUR BURDENS.\n\n" +
                    "Lay your burdens at the feet of Jesus, let Him bear your heavy load\n" +
                    "He will lead you through the lonesome valley, as you travel on life’s road.\n" +
                    "\n" +

                    "\tCHORUS: " + "\n" +
                    "\tLay (your burdens at the Saviour’s feet) your burdens at the feet of Jesus,\n" +
                    "\tLay (your burdens at the His feet)  \n" +
                    "\tLay (your burdens at the Saviour’s feet) your burdens at the feet of Jesus,\n" +
                    "\tLay (your burdens at the His feet)  \n" +
                    "\n" +

                    "Trust His promises and doubt Him never, He’s a sure and precious friend\n" +
                    "Let His will be, gladly praise Him ever, lay your burdens at His feet.\n" ),

            new Drink( "165. JESUS IS WHISPERING", "165. JESUS IS WHISPERING.\n\n" +
                    "Life is a gift that we all must lay down, whether we be rich or poor,\n" +
                    "And Jesus is willing to give us a crown, and fill us with love that is pure.\n" +
                    "\n" +

                    "\tCHORUS: " + "\n" +
                    "\tJesus is whispering whispering now, why would you wait, why would you \t\t\twait,\n" +
                    "\tJesus is whispering whispering now, listen to His voice don’t turn Him away.\n" +
                    "\n" +

                    "When life seems so hard and seem just like too late, with trials and troubles to face\n" +
                    "Just ask God to come for He’s willing and will, let gladness and love take its place.\n" +
                    "\n" +

                    "Willing to bow in the presence of God, striving to win a reward,\n" +
                    "Wondering home on this path that I try, willing to work for the Lord.\n"),

            new Drink( "166. WAIT A LITTLE LONGER PLEASE JESUS\n","166. WAIT A LITTLE LONGER PLEASE JESUS.\n\n" +
                    "If the labour is so hard, the work is hard and tiring,\n" +
                    "And the weary heart is yearning for a rest\n" +
                    "And I’m finally getting anxious to be in that happy land,\n" +
                    "Where we’ll receive such peace and happiness.\n" +
                    "\n" +

                    "\tCHORUS: " + "\n" +
                    "\tWait a little longer please Jesus, there are so many still wandering now in sin,\n" +
                    "\tJust a little longer please Jesus, a few more days to get our loved ones in.\n" +
                    "\n" +

                    "You may look in to the sky, and the tears may fill our eyes\n" +
                    "For our burdened hearts grow heavy every day,\n" +
                    "But if you cry oh Lord just come, come and take your children home\n" +
                    "And then you look around and you can say.\n" +
                    "\n" +

                    "\tJust a little longer please Jesus, there are so many still wandering now in sin,\n" +
                    "\tJust a little longer please Jesus, a few more days to get our loved ones in.\n" ),

            new Drink( "167. RELAX\n","167. RELAX.\n\n" +
                    "I’ve been the sort to worry, I’ve been the sort to fret,\n" +
                    "And often have I said why I am not delivered yet, the answer’s very clear,\n" +
                    "And the way is very free, the reason I’m so bad is that I lead too much to me.\n" +
                    "\n" +

                    "\tCHORUS: " + "\n" +
                    "\tRelax, relax, and lay back in the arms of Jesus,                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        \n" +
                    "\tHe will take you safely through no matter what should come,\n" +
                    "\tRelax, relax, and lay back in the arms of Jesus,                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        \n" +
                    "\tHe will take you safely through to your eternal home.\n" +
                    "\n" +

                    "So many live in bondage, so many live in fear, they won’t cry out in faith\n" +
                    "For they think the Lord won’t hear, they try to work their way to the heavenly home above\n" +
                    "But they will never make it the only way is love.\n" +
                    "\n" +

                    "So heed my brother sister, those words you’ve heard today and lay back in Christ Jesus\n" +
                    "He’s God provided way, He’s so good to His people, so good to everyone,\n" +
                    "To please Him in my goal and hear Him say “well done”\n" ),

            new Drink( "168. MY JESUS I LOVE THEE\n","168. MY JESUS I LOVE THEE.\n\n" +
                    "My Jesus I love thee, I know thou art mine, for thee all the pleasure of sin I resign\n" +
                    "My gracious redeemer, my Jesus art thou, if ever I loved thee, my Jesus ‘tis now.\n" +
                    "\n" +

                    "I love thee because thou hast first loved me, and purchased my pardon on Calvary’s tree\n" +
                    "I love thee for wearing the thorns on thy brow, if ever I loved thee, my Jesus ‘tis now.\n" +
                    "\n" +

                    "In mansions of glory and endless delight, I’ll ever adore thee in heaven so bright\n" +
                    "I’ll sing with the glittering crown on my brow, if ever I loved thee, my Jesus ‘tis now.\n" ),

            new Drink( "169. HEAVENS CAME DOWN\n","169. HEAVENS CAME DOWN.\n\n" +
                    "Oh what a wonderful, wonderful day, day I will never forget\n" +
                    "After I had wondered in darkness away, Jesus my Saviour I met,\n" +
                    "Oh what a tender compassionate friend, He met the needs of my heart\n" +
                    "Shadows dispelling, with joy I am telling, He made all my darkness depart.\n" +
                    "\n" +

                    "\tCHORUS: " + "\n" +
                    "\tHeavens came down and glory filled my soul,\n" +
                    "\tWhen at the cross my Saviour made me whole\n" +
                    "\tMy sins were washed away and my night was turned to day\n" +
                    "\tHeavens came down and glory filled my soul,\n" +
                    "\n" +

                    "Born of the spirit with life from above, into God family divine.\n" +
                    "Justified fully through Calvary’s blood, oh what a standing is mine\n" +
                    "And the transaction so quickly was made. When as a sinner I came.\n" +
                    "Took of the offer of grace He did proffer, He save me oh praise dear name.\n" +
                    "\n" +

                    "Now I’ve a hope that will surely endure, after the passing of time\n" +
                    "I have a future in heaven for sure, up in the mansion sublime\n" +
                    "And it’s because of that wonderful day, when at the cross I believed\n" +
                    "Riches eternal, and blessings supernatural from His precious blood I received.\n" ),

            new Drink( "170. THERE IS NO MOUNTAIN\n","170. THERE IS NO MOUNTAIN.\n\n" +
                    "I’ve been on the mountains, and the valley so low,\n" +
                    "And when it seemed that never had a place to go\n" +
                    "Then I found Jesus and He’s mine and there is no mountain that we can’t climb.\n" +
                    "\n" +

                    "\tCHORUS: " + "\n" +
                    "\tThere is no mountain that we can’t climb, when I say we, I mean Jesus and \t\t\tme\n" +
                    "\tWhen you have Jesus and He is thine, there is no mountain that you can’t climb.\n" ),


            new Drink( "171. PURPLE ROBE\n","171. PURPLE ROBE.\n\n" +
                    "There’s a story so unkind, in the Holy book we find, it tells us how Jesus stood alone one day\n" +
                    "False accused and then condemned yet they found no fault in Him,\n" +
                    "The man who wore the scarlet purple robe.\n" +
                    "\n" +

                    "\tCHORUS: " + "\n" +
                    "\tPurple robe my Saviour wore, oh the shame for me He bore\n" +
                    "\tAs He stood alone forsaken on that day, there they placed upon His head\n" +
                    "\tPiercing thorns the blood stained red, His raiment was a scarlet purple robe.\n" +
                    "\n" +

                    "In the common judgment hall He was mocked and scorned by all\n" +
                    "As tears of sorrow fell upon His cheeks\n" +
                    "Soldiers of the wicked band, smote Him with their evil hands\n" +
                    "The man who wore the scarlet purple robe.\n" +

                    "Words of truth were spoken that day from the lips of Pilate came\n" +
                    "“in this man I find no reason He should die” but the multitude then cried “let Him now be crucified” \n" +
                    "The man who wore the scarlet purple robe.\n" ),

            new Drink( "172. KEEP ON WALKING\n","172. KEEP ON WALKING.\n\n" +
                    "Are you weary in well doing walking on the road to new Jerusalem\n" +
                    "Are you hoping and praying, looking any moment for the Lord to come\n" +
                    "And do you see a lot of pleasant looking places,  where you might lay down and take a rest\n" +
                    "If you do take a look at all the faces there, the sadness will tell you that it’s best.\n" +
                    "\n" +

                    "\tCHORUS: " + "\n" +
                    "\tKeep on walking you don’t know how far you have come\n" +
                    "\tKeep on walking for all you know it may be done\n" +
                    "\tAnd the Father might be standing up right now\n" +
                    "\tTo give the call and end it all, so keep on walking.\n" +
                    "\n" +

                    "Well if you need a feeling to keep on the road you have started travelling on\n" +
                    "You’re gonna have some trouble learning that it’s faith that keep you moving on\n" +
                    "Cause in the Lord you start to walk from sitting, but sometimes you have to take a stand\n" +
                    "And standing’s not another word for quitting, it’s taking a tighter hold on His hands.\n" ),

            new Drink( "173. I TOUCHED THE HEM OF HIS GARMENT \n","173. I TOUCHED THE HEM OF HIS GARMENT.\n\n" +
                    "Once I was sinking so low in sin’s clay, I felt so depressed in my soul\n" +
                    "But Jesus was passing along the way, seeking those to be made whole.\n" +
                    "\n" +

                    "\tCHORUS: " + "\n" +
                    "\tI touched the hem of His garment, and joy He brought to my soul\n" +
                    "\tI touched the hem of His garment, and I was made happy and whole.\n" +
                    "\n" +

                    "He made the lame walk and the deaf ear to hear, He caused the blind man to see\n" +
                    "And He’s still passing this way every day, the same He’ll do for you.\n" +
                    "\n" +

                    "Now if you are sin sick and of travelling life’s road, you have no peace in your soul\n" +
                    "Or if you’re carrying too heavy a load, your burdens to Him you can roll.\n" ),

            new Drink( "174. LITTLE WHITE CHURCH\n","174. LITTLE WHITE CHURCH.\n\n" +
                    "There’s a little white church in the valley, that sends in my memory each day\n" +
                    "And it seems I can hear the bells ringing, though I am in many miles away\n" +
                    "And many times on Sunday morning, an old country church gathered there\n" +
                    "They would all kneel down by the alter, as they lifted up their voices and prayed.\n" +
                    "\n" +

                    "\tCHORUS: " + "\n" +
                    "\tOh the church in the valley, little white church is the place that I love so well\n" +
                    "\tNow I’m sad and lonely, yes I’m sad and lonely, for that little white church in the dale.\n" +
                    "\n" +

                    "They would sing the old songs, Rock of ages, Oh Christ let me hide myself in thee\n" +
                    "And I know some of them are now waiting, just over the dark and stormy sea\n" +
                    "I know their troubles are all ended, and happy forever they shall be\n" +
                    "They are waiting, watching up yonder, for the coming home of you and me.\n" ),

            new Drink( "175. IT’S JUST LIKE HIS GREAT LOVE\n","175. IT’S JUST LIKE HIS GREAT LOVE.\n\n" +
                    "A friend I have named Jesus, whose love is strong and true,\n" +
                    "And never fails however it’s tried no matter what I do,\n" +
                    "I’ve sinned against this love of His but when I knelt to pray\n" +
                    "Confessing all my guilt to Him, the sin clouds rolled away.\n" +
                    "\n" +

                    "\tCHORUS: " + "\n" +
                    "\tIt’s just like Jesus to roll the clouds away\n" +
                    "\tIt’s just like Jesus to keep me day by day\n" +
                    "\tIt’s just like Jesus all the way, it’s just like His great love.\n" +
                    "\n" +

                    "Sometimes the clouds of trouble be dim the sky above\n" +
                    "I cannot see my Saviour’s face, I doubt His wondrous love\n" +
                    "But He from Heavens Mercy seat, beholding my despair\n" +
                    "In pity bursts the clouds between, and shows me He is there.\n" +
                    "\n" +

                    "When sorrow clouds over take me, and break upon my head,\n" +
                    "When life seems worse that useless and I were better dead\n" +
                    "I take my grieves to Jesus then, nor do I do in vain peace\n" +
                    "He gives that cheers like sunshine after rain.\n" +
                    "\n" +

                    "Oh I could sing forever of Jesus love above\n" +
                    "Of all His care and tenderness for this poor life of mine\n" +
                    " His love is in and overall and winds and waves obey\n" +
                    "When Jesus whispers peace be still and rolls the cloudy away.\n" ),

            new Drink( "176. I SAW HEAVEN IN VISION LAST NIGHT\n","176. I SAW HEAVEN IN VISION LAST NIGHT.\n\n" +
                    "Last night as I was reading my Bible I saw the mansion in that city so bright\n" +
                    "And I saw my loved ones gone on before me I saw heaven in a vision last night.\n" +
                    "\n" +

                    "\tCHORUS: " + "\n" +
                    "\tI was carried away in the spirit, to the city where Christ is the light\n" +
                    "\tThen I fell at the feet of my Saviour, I saw heaven in a vision last night.\n" +
                    "\n" +

                    "Then I walked down the streets of the city, singing praises to the one on the throne\n" +
                    "And I saw my dear old mother and my daddy, as they showed me their heavenly  home.\n" ),

            new Drink( "177. THE WAY GOD WORKS IS ALWAYS THE SAME\n","177. THE WAY GOD WORKS IS ALWAYS THE SAME.\n\n" +
                    "\n" +
                    "\tCHORUS: " + "\n" +
                    "\tThe way God works is always the same, praise His blessed Holy name\n" +
                    "\tHe hides it from the wise and reveals it to the babes\n" +
                    "\tGod works in mysterious ways, His wonders to perform\n" +
                    "\tHis elect recognize the day and pass above the storm.\n" +
                    "\n" +

                    "If God were to pass in the day you live would you shun it because it was odd\n" +
                    "Would you like to dine on the Lord’s elect and be found fighting with God\n" +
                    "Or would you believe and be quick to receive every word that the Lord might say\n" +
                    "Or would you reject it as most have done because it came an unusual way?\n" +
                    "\n" +

                    "God chose to work and to hide Himself in an humble simple way\n" +
                    "It’ll not be that many that see of the people living in that day\n" +
                    "They are blinded by their carnal minds their thinking\n" +
                    "Just can’t understand how could God be so odd to use just one little man.\n" +
                    "\n" +

                    "From Noah to Moses, Jeremiah to John, the majority has never received\n" +
                    "They’re pleased to doubt, and then miss out while a little group always believed\n" +
                    "Could it be that the history, has circled back, again\n" +
                    "Could it be that what we see is not the first time that it has been.\n" ),

            new Drink( "178. I WANT US TO BE TOGETHER IN HEAVEN\n","178. I WANT US TO BE TOGETHER IN HEAVEN.\n\n" +
                    "You may have a fancy car, a brand new house that shines by far\n" +
                    "You may live to be a hundred years old\n" +
                    "And though you give a farming grain, it will end in the grave\n" +
                    "But I want us to be together in heaven.\n" +
                    "\n" +

                    "\tCHORUS: " + "\n" +
                    "\tI want us, to be together in heaven, I want to walk, down the streets of pure gold\n" +
                    "\tI want to run through the fields of sweet roses\n" +
                    "\tSee the mansions, smell the flowers, hear the singing, it’s all ours\n" +
                    "\tSee river gentle flowing, feel the gentle breezes blowing\n" +
                    "\tI want us to be together in heaven.\n" +
                    "\n" +

                    "You may be a millionaire wearing clothes beyond compare\n" +
                    "You may have the best that money can buy\n" +
                    "But if the blood is not applied, then in hell you’ll lift your eyes\n" +
                    "But I want us to be together in heaven.\n" ),

            new Drink( "179. THERE IS A RIVER CALLED JORDAN\n","179. THERE IS A RIVER CALLED JORDAN.\n\n" +
                    "There is a river somewhere called Jordan and they say\n" +
                    "That it’s true and it’s worth and they say that\n" +
                    "The king and the beggar there they sat side by side.\n" +
                    "\n" +

                    "\tCHORUS: " + "\n" +
                    "\tAt the crossing of the Jordan,\n" +
                    "\tWhy should I be afraid yet there is someone there who loves me\n" +
                    "\tTo guide me across the river to endless joys above.\n" +
                    "\n" +

                    "Though the river is dark and stormy, it will pass like the dream in the night\n" +
                    "And my soul will be carried away to meet you, in the regions of finest delight.\n" ),

            new Drink( "180. THE TOUCH OF THE MASTER’S HAND\n","180. THE TOUCH OF THE MASTER’S HAND.\n\n" +
                    "It was battered and scattered and the auctioneer scarcely thought it worth his while\n" +
                    "To waste much time with his old violin, he held it up with a smile, “what is my bid good folks” \n" +
                    "he cried, “who will start the bidding for me” a dollar, one dollar, now two,\n" +
                    "Who’ll make it three dollars once, three dollars twice, and going for three, but no.\n" +
                    "From the room far back an old gray hired man came forward and picked the bow,\n" +
                    "Then wiping the dust from the old violin, he tightened up all the loose strings,\n" +
                    "And played a melody so pure and sweet like the caroling angels sing\n" +
                    "The music ceased and the auctioneer in a voice that was quiet and low said now what’s your bid \n" +
                    "for the old violin, he held it up with the bow. A thousand dollars twice and going and gone said\n " +
                    "he, then the people cheered, but some of them cried, “we just don’t quite understand”\n" +
                    "What changed its worth, swift came the reply, the touch of the master’s hand and many a man \n" +
                    "with his life out of tune, battered and scorned by sin, his auction cheap to the thoughtless crown,\n " +
                    "just like the old violin. A mess of pottage, a drink or two, a trip and he travels on,\n" +
                    "He’s going once, he’s going twice, he’s going and he’s almost gone. Then the master comes and \n" +
                    "the foolish crowd never can quite understand the worth of a soul, and the change that’s brought by\n " +
                    "the master’s hand.\n" ),

            new Drink( "181. HE IS RISEN\n","181. HE IS RISEN.\n\n" +
                    "It happened one day long ago our Lord was crucified, the rocks did rent\n" +
                    "The sun got dark as he bowed His head and died,\n" +
                    "They took Him down from off the tree, laid Him in the tomb so we could see,\n" +
                    "The price was paid for all humanity, with a heart of grief some to see the sepulture that day\n" +
                    "But the angel of the Lord had come and rolled the stone away he said to the woman “do not fear”\n" +
                    "The one ye seek He is not here, but come and see the place where He laid.\n" +
                    "\n" +

                    "\tCHORUS: " + "\n" +
                    "\tHe is risen, He is risen He’s not in the tomb any more\n" +
                    "\tHe is risen, He is risen He has opened the door\n" +
                    "\tNow that can’t bother me for my soul has been set free\n" +
                    "\tAnd I’m alive in Him throughout eternity.\n" +
                    "\n" +

                    "Like the tongue of fire the spirit fell on the ones he came to save\n" +
                    "And the power of God was mighty through the Pentecostal age\n" +
                    "As time went on the light got dim there was just a few that followed him\n" +
                    "But He said that he would be revealed again as he promised in His word\n" +
                    "When the time came to restore.\n" +
                    "\n" +

                    "The voice of God was turned again through Malachi chapter four\n" +
                    "He stirred the people’s hearts again and brought us face to face with same\n" +
                    "Now it shines the light on the way that leads us in we settled back when the prophet left \n" +
                    "And thought it was alright, fell fast asleep and dreamed we were walking in the light\n" +
                    "Six floors up asleep in the bed, a studless wall against our head, just one wrong move and brother\n" +
                    "we’d be dead, so to wake the bride the Lord has sent us one special call, the final chance to get\n" +
                    "In step before the judgment falls, but it’s not in man’s theology, so most who hear cannot receive\n" +
                    "Yet God has His elect who believe.\n" +
                    "\n" +

                    "He placed His spirit here for all who’ll live by every word and promised faith and agape love by \n" +
                    "believing what we’ve heard, it’s something others might not see it’s within the heart of you and me.\n" +
                    "The power to lead our lives in victory so when the devil come to tempt you in the darkest hour \n" +
                    "And tells you you can’t carry on you haven’t got the power, resist the things that he would tell \n" +
                    "and point him to that loyal stage and the empty tomb where the stone was rolled away.\n" ),

            new Drink( "182. BAPTIZED IN TO THE BODY\n", "182. BAPTIZED IN TO THE BODY.\n\n" +
                    "Have you been baptized in to the body, baptized with the Holy Ghost?\n" +
                    "There is but one way to enter in it, just as they did on Pentecost.\n" +
                    "\n" +

                    "\tCHORUS: " + "\n" +
                    "\tAre you in the church triumphant, are you in the Saviour’s bride?\n" +
                    "\tCome and be baptized in to the body, and forever more abide.\n" +
                    "\n" +

                    "There is but one church, bride or body, and in to it we’re all baptized,\n" +
                    "By the one, true promised Holy Spirit, though by the world we’re all despised.\n" +
                    "\n" +

                    "Every creed has claimed to be the body, but the “plumb line” proved untrue\n" +
                    "All their dreams,  for God has so determined, to bring this son’s true bride to view.\n" +
                    "\n" +

                    "Many thought that they were in the body, till the Holy Ghost had come,\n" +
                    "When the word of God was opened to them, they entered in and yet there’s room.\n" +
                    "\n" +

                    "Those who died before the Holy Spirit, came upon us from on high,\n" +
                    "May by faith with saints of old departed, arise to meet Him in the sky.\n" +
                    "\n" +

                    "When the bridegroom comes will you be ready, and your vessel all filled and bright,\n" +
                    "You will be among the foolish virgins, if you do not walk in the light.\n"),

            new Drink( "183. HE IS COMING\n","183. HE IS COMING.\n\n" +
                    "The bride of the Lord, be ready now for Jesus is coming\n" +
                    "Make all things right my brother, my sister for Jesus is coming.\n" +
                    "\n" +

                    "\tCHORUS: " + "\n" +
                    "\tHe is coming x2, Dear Lord Jesus\n" +
                    "\tHe is coming.\n" +
                    "\n" +

                    "In day and bright shining morning, we shall see Him in the air,\n" +
                    "Every day every night, put a smile in the Lord face.\n" +
                    "\n" +

                    "He is coming for you and me, my brother my sister dear Jesus He’s coming again,\n" +
                    "In the twinkling of an eye He’ll change you and me, we shall live with Him never to part.\n" ),

            new Drink( "184. FROM THE DURST OF THE EARTH\n","184. FROM THE DURST OF THE EARTH.\n\n" +
                    "From the durst of the earth, my God created man, His breath made man a living soul,\n" +
                    "For God so loved the world He gave His only son, and that is why I love Him so.\n" +
                    "\n" +

                    "\tCHORUS: " + "\n" +
                    "\tFor I was made in His likeness created in His image, for I was born to serve the Lord,\n" +
                    "\tOh I cannot deny Him, I will always want to serve Him,\n" +
                    "\tFor I was born to serve the Lord.\n" +
                    "\n" +

                    "My hands were made to help my neighbours, my eyes were made to read God’s word,\n" +
                    "My feet were made to walk in His footsteps, my body is the temple of the Lord.\n" ),

            new Drink( "185. AGAPE LOVE\n","185. AGAPE LOVE.\n\n" +
                    "The king of kings laid aside His glory, and came to die on Calvary,\n" +
                    "Think He be so meek and lovely, and stooped to look for a soul like me.\n" +
                    "\n" +

                    "\tCHORUS: " + "\n" +
                    "\tAgape love, Agape love, Agape love held Him to the tree,\n" +
                    "\tAgape love, Agape love, we can’t explain agape love.\n" +
                    "\n" +

                    "When I was down in the valley low, He reached way down reached for my soul\n" +
                    "He lifted me to the mountain high, and built a home for me in the sky.\n" +
                    "\n" +

                    "You have faith to move a mountain, and you could know all the mysteries,\n" +
                    "Without His love yet we are nothing, the greatest gift is charity.\n" ),

            new Drink( "186. SOMETHING GOT A HOLD OF ME.\n","186. SOMETHING GOT A HOLD OF ME.\n\n" +
                    " Oh when I first came to the people who claim, the old time religion is real,\n" +
                    "Said I’ll go down take a look at the crowd, just to remind as I see.\n" +
                    "\n" +

                    "\tCHORUS: " + "\n" +
                    "\tSomething got a hold of me, yes Something got a hold of me,\n" +
                    "\tI went there to fight, but oh that night, God surely got a hold of me.\n" +
                    "\n" +

                    "I walked up the steps and looked in the door, the devil said don’t you go in,\n" +
                    "Said it won’t hurt me, I’ll just step inside, and set as far back as I can.\n" +
                    "\n" +

                    "Preacher just then his sermon began, and he looked right straight at me,\n" +
                    "Told everyone just how evil I was, seem not to think much of me.\n" +
                    "\n" +

                    "Just at the end someone started to shout, he said that he knew he was saved,\n" +
                    " I plainly could not see there’s a reason to doubt, salvation to him was okey.\n" +
                    "\n" +

                    "Said when I went that I could not stay long, that I must be home by nine,\n" +
                    "Fell on my knees and the fire came down, so later I was feeling so fine.\n" ),

            new Drink( "187. SINGING SINGING THEN PRAISING\n","187. SINGING SINGING THEN PRAISING.\n\n" +
                    "When the bird up the mountain are singing, making sweet melodies,\n" +
                    "A touch of his greatness surround me, with their beauty I see.\n" +
                    "\n" +

                    "\tCHORUS: " + "\n" +
                    "\tSinging singing then praising, hear the echoes ring,\n" +
                    "\tPerhaps there’s something up yonder, when we can hear them sing.\n" +
                    "\n" +

                    "While walking along through the meadows, listening to them sing,\n" +
                    "My life is filled with his praises, how I wish I could see.\n" +
                    "\n" +

                    "While the birds we’ll watch them yonder, early in the spring,\n" +
                    "Sweet sounds of their melody ringing, teaching me how to sing.\n" ),

            new Drink( "188. IN MY FATHER’S HOUSE ARE MANY MANSIONS\n","188. IN MY FATHER’S HOUSE ARE MANY MANSIONS.\n\n" +
                    "In my Father’s house are many mansions, if it were not true He would have told me so,\n" +
                    "He has gone away to live in that bright city, He’s preparing me a mansion there I know.\n" +
                    "\n" +

                    "\tCHORUS: " + "\n" +
                    "\tDo not shun the Saviour’s love from up in Glory,\n" +
                    "\tOr you won’t be there to sing the gospel story,\n" +
                    "\tIn my Father’s house are many mansions,\n" +
                    "\tIf you’re true then to this land you’ll surely go.\n" +
                    "\n" +

                    "Jesus died upon the cross to bear my sorrow, freely died that souls like you might have new life,\n" +
                    "But I know there soon will come a bright tomorrow, \n" +
                    "When the world will all be free from sin and strife,\n" +
                    "\n" +

                    "When your friends have turned you down and left you lonely,\n" +
                    "In this world you’re all alone and oh so blue,\n" +
                    "Turn your thoughts away from sin to Jesus only, a new life and friendship sweet He’ll give to you.\n" ),

            new Drink( "189. UNDER THE BLOOD\n","189. UNDER THE BLOOD.\n\n" +
                    "Lord keep my soul from day to day, under the blood under the blood,\n" +
                    "Take doubt and fear and sin away, under the precious blood.\n" +
                    "\n" +

                    "\tCHORUS: " + "\n" +
                    "\tUnder the blood, the precious blood, under the cleansing healing flood,\n" +
                    "\tKeep me, Saviour from day to day, under the precious blood.\n" +
                    "\n" +

                    "The sinner’s refuge here alone, under the blood, under the blood,\n" +
                    "Here Jesus makes Salvation known, under the precious blood.\n" +
                    "\n" +

                    "Lord with thy self my spirit fill, under the blood under the blood,\n" +
                    "And work in me to do thy will, under the precious blood\n" +
                    "\n" +

                    "Sweet peace abides within the heart, under the blood under the blood,\n" +
                    "And gifts divine their joy impart, under the precious blood.\n" +
                    "\n" +

                    "The Holy Spirit hour by hour, under the blood under the blood,\n" +
                    "Exerts His sanctifying power, under the precious blood.\n" ),

            new Drink( "190. VICTORY AHEAD\n","190. VICTORY AHEAD.\n\n" +
                    "When the hosts of Israel led by God, round the walls of Jericho softly trod,\n" +
                    "Trusting in the Lord they felt the conqueror’s tread, by faith they saw the victory ahead.\n" +
                    "\n" +

                    "\tCHORUS: " + "\n" +
                    "\tVictory ahead victory ahead, thro’ the blood of Jesus victory ahead,\n" +
                    "\tTrusting in the Lord, I hear the conqueror’s tread, by faith I see the victory ahead.\n" +
                    "\n" +

                    "David with the shepherd’s sling and five stones, met the giant on the field all alone,\n" +
                    "Trusting in the Lord he knew what God had said, by faith he saw the victory ahead.\n" +
                    "\n" +

                    "Daniel prayed unto the Lord thrice each day, then unto the lion’s den led the way,\n" +
                    "Trusting in the Lord he did not fear or dread, by faith he saw the victory ahead.\n" +
                    "\n" +

                    "Often with the carnal mind I was tried, asking for deliverance oft I cried\n" +
                    "Trusting in the Lord I reckoned I was dead, by faith I saw the victory ahead.\n" +
                    "\n" +
                    "When like those who’ve gone before to the Lord, by death’s river cold and dark I shall stand,\n" ),

            new Drink( "191. ASHAMMED TO OWN MY BLESSED SAVIOUR\n","191. ASHAMMED TO OWN MY BLESSED SAVIOUR.\n\n" +
                    "Upon the lonely tree of Calvary, my blessed savior died for me,\n" +
                    "Then do you think that I disowned him, when His own blood did set me free.\n" +
                    "\n" +

                    "\tCHORUS: " + "\n" +
                    "\tAshamed to own my blessed Saviour, ashamed of Him who died for you,\n" +
                    "\tSomeday I know that you’ll be sorry, for He’ll be ashamed of you.\n" +
                    "\n" +

                    "Oh brother how can you deny Him, ashamed to own God’s gift of love,\n" +
                    "Our only promise of tomorrow, our precious Saviour from above.\n" +
                    "\n" +

                    "Oh Lord above don’t count now upon me, for I’m not worthy now to pray,\n" +
                    "Please cleanse me now and make me holy, so you can own me every day.\n" ),

            new Drink( "192. THE UNSEARCHABLE\n","192. THE UNSEARCHABLE.\n\n" +
                    "Oh the unsearchable riches of Christ, how  can I ever behold\n" +
                    "Riches exhaustless of mercy and grace, precious more precious than gold.\n" +
                    "\n" +

                    "\tCHORUS: " + "\n" +
                    "\tPrecious more precious wealth, can never be told\n" +
                    "\tOh the unsearchable riches of Christ, precious more precious than gold.\n" +
                    "\n" +

                    "Oh the unsearchable riches of Christ, freely so freely gave those\n" +
                    "Hunger and thirsty for His word, and whosoever believes.\n" ),

            new Drink( "193. LET THE HOLY GHOST COME IN\n","193. LET THE HOLY GHOST COME IN.\n\n" +
                    "Would you be redeemed from every inbred sin, have the Holy Spirit constantly within\n" +
                    "Make the consecration trust in God and then, let the Holy Ghost come in.\n" +
                    "\n" +

                    "\tCHORUS: " + "\n" +
                    "\tLet the Holy Ghost come in x3 Make the consecration trust in God and then,\n" +
                    "\tLet the Holy Ghost come in.\n" +
                    "\n" +

                    "Would you have the spirit in your heart to cheer, would you be relieved from every doubt and fear?\n" +
                    "Make the consecration trust in God and then, let the Holy Ghost come in.\n" ),

            new Drink( "194. MY WONDERFUL LORD\n","194. MY WONDERFUL LORD.\n\n" +
                    "I have a deep peace that I never had known, and a joy this world could never afford\n" +
                    "Since I yielded control of my body and soul, to my wonderful, wonderful Lord.\n" +
                    "\n" +

                    "\tCHORUS: " + "\n" +
                    "\tMy wonderful Lord, my wonderful Lord, by angels and seraphs in heaven adore\n" +
                    "\tI bow at thy shrine, my Saviour divine, my wonderful, wonderful Lord.\n" +
                    "\n" +

                    "I desire that my life shall be ordered by thee, that my will be in perfect accord\n" +
                    "With thine own sovereign will thy desire to fulfill, my wonderful, wonderful Lord.\n" +
                    "\n" +

                    "All the talents I have I laid at thy feet, thy approval shall be my reward,\n" +
                    "Be my store great or small, I surrender it all, to my wonderful, wonderful Lord.\n" +
                    "\n" +
                    "Thou art fairer to me than the fairest of earth, thy omnipotent life giving word,\n" +
                    "O thou ancient of days, thou art worthy all praise, my wonderful, wonderful Lord.\n" ),

            new Drink( "195. NO NO NO NO I’LL NEVER DIE\n","195. NO NO NO NO I’LL NEVER DIE.\n\n" +
                    "I know if I leave I will go home and weary by and by, and visions will fade away from my age\n " +
                    "enough, oh yes this old body may lay down and die, No no no no I’ll never die.\n" +
                    "\n" +

                    "\tCHORUS: " + "\n" +
                    "\tNo no no no I’ll never die, longing to see my home on high\n" +
                    "\tJesus said I go away, a mansion to prepare\n" +
                    "\tDon’t say I’m dead when you gather around, to lay my body in the ground\n" +
                    "\tcause, no no no no I’ll never die.\n" +
                    "\n" +

                    "There you may watch me as I travel to places here and there, And see my steps go slower at every \n" +
                    "weary miles, then you may pitty this old man whose falling really means stronger every day.\n" ),

            new Drink( "196. I CROSSED THE RIVER FROM HERE\n","196. I CROSSED THE RIVER FROM HERE.\n\n" +
                    "Someday I’ll go to that far off shore, I’ll cross the river from here\n" +
                    "I’ll live in sunshine forever more, I’ll cross the river from here.\n" +
                    "\n" +

                    "\tCHORUS: " + "\n" +
                    "\tI’ll cross the river from here I’ll go, I’ll cross the river from here.\n" +
                    "\tI’ll stand beside Him someday I know, I’ll cross the river from here.\n" +
                    "\n" +

                    "My home will be in that mansion fair, I’ll cross the river from here.\n" +
                    "To reach that gate I must climb the stair, I’ll cross the river from here.\n" +
                    "\n" +

                    "I’ll leave my treasures up there behind, I’ll cross the river from here.\n" +
                    "I know His treasures up there are mine, I’ll cross the river from here.\n" ),

            new Drink( "197. SHOUTING IN THE AIR\n","197. SHOUTING IN THE AIR.\n\n" +
                    "\n" +
                    "\tCHORUS: " + "\n" +
                    "\tThere’ll be shouting, shouting, shouting,\n" +
                    "\tIn the air (Hallelujah), there’ll be shouting, shouting, shouting in the air,\n" +
                    "\tAfter all the saints have risen from the cold and silent prison\n" +
                    "\tThere’ll be shouting, shouting, shouting in the air.\n" +
                    "\n" +

                    "What a happy time is coming when we reach our home in heaven\n" +
                    "And our burdens which we bear, we’ll bear no more,\n" +
                    "When the angels sound their trumpets calling us to go to our mansion\n" +
                    "There’ll be shouting on the everlasting shore.\n" +
                    "\n" +

                    "\tThere’ll be shouting on the hills of Glory,\n" +
                    "\tShouting (on the hills) yes, shouting on the hills\n" +
                    "\tWhen we reach that land of which we hear the story\n" +
                    "\tThere’ll be shouting on the hills of God.\n" +
                    "\n" +

                    "When the saints begin to gather round the throne of that great city,\n" +
                    "And the angels for a song of praise shall pause\n" +
                    "Harps of gold there will be ringing saints from all the ages singing\n" +
                    "Such a meeting like we never saw before.\n" ),

            new Drink( "198. THERE’S A CITY HOLY CITY\n","198. THERE’S A CITY HOLY CITY.\n\n" +
                    "There’s  the street are paved of gold, and it’s walls are made of Jasper\n" +
                    "And its beauty can’t be told, it’s a home of the redeemed ones who have known God’s saving grace, for the happy bride reunion will be meeting in that place.\n" +
                    "\n" +

                    "\tCHORUS: " + "\n" +
                    "\tJohn saw that city, and the river flowing free (Hallelujah)\n" +
                    "\tFor the tree (of life) there is splendid, in the city built for you and me.\n" +
                    "\n" +

                    "In that city holy city no tears can dim the eye, there will be no disappointment,\n" +
                    "There will  be no sacrifice, all the saints will then be holy, and we’ll live in one accord. \n" +
                    "There’ll be shouting, there’ll be singing, when we meet with the Lord.\n" +
                    "\n" +

                    "Over in that holy city, we will need no sun to shine, we will walk the streets of Glory in that happy rest of souls, it’s a place of wondrous beauty where the saints will never war\n" +
                    "We will sing there Hallelujah, in that home of the soul.\n" ),

            new Drink( "199. COMING UP THE ROAD\n","199. COMING UP THE ROAD.\n\n" +
                    "When David danced before the Lord was coming up the road\n" +
                    "His wife despised him in her heart the ark was coming up the road.\n" +
                    "\n" +

                    "\tCHORUS: " + "\n" +
                    "\tIt’s coming hallelujah, the ark is coming up the road,\n" +
                    "\tIt’s coming hallelujah, the ark is coming up the road.\n" +
                    "\n" +

                    "I believe without a doubt, the ark is coming up the road.\n" +
                    "God’s children have a right to shout, the ark is coming up the hill.\n" +
                    "\n" +

                    "Singing on, pray on we’re gaining ground, the ark is coming up the road\n" +
                    "The power of God is coming down, the ark is coming up the road.\n" ),

            new Drink( "200. JESUS CAN TAKE THE PLACE OF MANY FRIENDS\n","200. JESUS CAN TAKE THE PLACE OF MANY FRIENDS.\n\n" +
                    "I am waiting for my Lord to come descending down, from the sky\n" +
                    "For I know that He’s coming back very soon I’ll be happy for that day all my sorrow will be gone,\n" +
                    "Jesus Christ can take the place of many friends.\n" +
                    "\n" +

                    "Oh my Jesus and great thou art, never ever let me go in this world or in shame,\n" +
                    "Of the sin and I’ll praise you in my life with belongings, that you give living and shouting to you.\n" ),

            new Drink( "201. FOR THE LORD TO BE WITH ME\n","201. FOR THE LORD TO BE WITH ME.\n\n" +
                    "Remember what promise to the first class bride of Jesus\n" +
                    "My heart was affected for the living word of Jesus.\n" +
                    "\n" +

                    "\tCHORUS: " + "\n" +
                    "\tFor the Lord to be with me, imagine what I felt,\n" +
                    "\tMy heart fill the love of Jesus in this, living word of Jesus.\n" +
                    "\n" +

                    "If you brothers and sisters you let you let this Lord in your heart,\n" +
                    "You will feel the love of Jesus is His Lord of promise.\n" ),

            new Drink( "202. GLORY HALLELUJAH\n","202. GLORY HALLELUJAH.\n\n" +
                    "I was praying somebody touched me x3 I know it was the hand of the Lord.\n" +
                    "\n" +

                    "\tCHORUS: " + "\n" +
                    "\tGlory glory glory, somebody touched me x2, I know it was the hand of the Lord,\n" +
                    "\tWhen didn’t the calling somebody revealed to me x3, I know it was the revelation of God. \n" +
                    "\n" +

                    "When I crossed the bridge the log was broken x3, I know it was the Lord Jesus Christ.\n" +
                    "\n" +

                    "When I was in sin somebody delivered me x3, I know it was the deliverance hand of the God.\n" +
                    "\n" +

                    "Since He delivered me, no more sin in me x3, for Him the great calling has forgiven me,\n" +
                    "\n" +

                    "\tGlory glory glory am forgiven, Glory glory glory the pardon is signed for me,\n" +
                    "\tGlory glory glory I will receive it, and it’s there for you that pardon you receive \n" +
                    "\tfrom God.\n" ),

            new Drink( "203.WASTING TIME\n","203.WASTING TIME.\n\n" +
                    "\tCHORUS: " + "\n" +
                    "\tYou are wasting time, refusing the great calling\n" +
                    "\tDeath will humiliate you, to useless gray scopes.\n" +
                    "\n" +

                    "If this day my brother you come off this world\n" +
                    "Where will you go to make your own decision, it might be the last chance.\n" +
                    "\n" +

                    "My precious brothers and precious sisters, come up upon high\n" +
                    "Where the calling is living, come up and live with Him.\n" +
                    "\n" +

                    "Don’t waste no more time, make use of that time you have,\n" +
                    "Please the Lord that moment.\n" ),

            new Drink( "204. DEAR FRIEND AM  LEAVING NOW\n","204. DEAR FRIEND AM  LEAVING NOW.\n\n" +
                    "Dear friend am leaving now, and the train is waiting now, to take this and my soul over there to the land of paradise where there’s no surprise, no sorrow no worries at all.\n" +
                    "\n" +

                    "\tCHORUS: " + "\n" +
                    "\tIt’s okey x2, if the time comes, it’s okey my dear it’s okey, to the land of paradise where there’s no surprise, no sorrows, no worries at all.\n" +
                    "\n" +

                    "Dear friends stand with the faith and you will overcome, all the temptation that will come forth\n" +
                    "Just rely on God to the end of it and the joy of God will be in your heart after you win.\n" +
                    "\n" +

                    "If no more time to meet this world of sin, let the meeting be in heaven, as a paradise that’s \n" +
                    "prepared, for the ones that will be ready for His coming, and we shall meet there by and by.\n" ),

            new Drink( "205. TILL I REACH MY HOME","205. TILL I REACH MY HOME.\n\n" +
                    "Them that need safety place, run to the Lord quickly\n" +
                    "He will hide you from this satan, and give you victory.\n" +
                    "\n" +

                    "\tCHORUS: " + "\n" +
                    "\tLord I till reach my home, until I reach my home\n" +
                    "\tI don’t expect to give my journey over until I reach my home.\n" +
                    "\n" +

                    "Now I don’t mind that old satan with his temptation care\n" +
                    "He wants to steal my soul away and bring my journey end.\n" +
                    "\n" +

                    "No security in other places, just make your right decision,\n" +
                    "To accept the Lord in your heart.\n" ),

            new Drink( "206. LET US TRAVEL ON\n","206. LET US TRAVEL ON.\n\n" +
                    "There’s a home high up in heaven where the saints forever dwell, and the road of life is ended\n" +
                    "And I’ll bid this world farewell.\n" +
                    "\n" +

                    "\tCHORUS: " + "\n" +
                    "\tThere’s no weary ones in heaven only gladness will be known\n" +
                    "\tSinner come accept the Saviour, let us travel, travel on.\n" +
                    "\n" +

                    "I have given my heart to Jesus, turn away from sin and shame,\n" +
                    "In that book of life in heaven, God has written down our name.\n" +
                    "\n" +

                    "When this weary live is over, and the saints are marching on. \n" +
                    "Will your soul be free from sorrow or will be yee all alone.\n" ),

            new Drink( "207. REACH OUT, TOUCH THE LORD\n","207. REACH OUT, TOUCH THE LORD.\n\n" +
                    "Reach out and touch the Lord as He passes by,\n " +
                    "you’ll find He’s not too busy to hear your hearts’ cry, \n" +
                    "He’s passing by this moment, your needs to supply,\n" +
                    "Reach out and touch the Lord as He goes by.\n" ),

            new Drink( "208. IF JESUS SHOULD COME\n","208. IF JESUS SHOULD COME.\n\n" +
                    "If Jesus should come x2, I would welcome the call from on high, there is nothing to hold me\n" +
                    "No money or home, I would leave without saying goodbye.\n" +
                    "\n" +

                    "\tCHORUS: " + "\n" +
                    "\tI am longing to go x2, if the trumpet should sound from the mansion on high\n" +
                    "\tI’d leave without saying goodbye.\n" +
                    "\n" +

                    "My garment are spotless, I’ve washed my robes white and the blood flowing over my soul\n" +
                    "The way seem so clear, though it’s dark as the night, for the saints keep their eyes on the goal.\n" ),

            new Drink( "209. FILL MY CUP\n","209. FILL MY CUP.\n\n" +
                    "Like the woman at the well I was seeking, for things that could not satisfy\n" +
                    "But then I heard my Saviour speaking, draw from the well, that never shall dry.\n" +
                    "\n" +

                    "\tCHORUS: " + "\n" +
                    "\tFill my cup Lord, I lift it up Lord, come and quench this thirsting of my soul\n" +
                    "\tBread of heaven feed me till I want no more, fill my cup, fill it up and make me whole.\n" +
                    "\n" +

                    "There are millions in this world who are seeking, for pleasures worldly things afford,\n" +
                    "But none can match the wondrous treasures that I have found in Jesus Christ my Lord.\n" +
                    "\n" +

                    "So my brothers if the things this world gave you, leave longing that won’t pass away,\n" +
                    "My precious Lord will come and save you if you will kneel to Him and humbly pray.\n" ),

            new Drink( "210. I WAS BORN TO SERVE THE LORD. \n","210. I WAS BORN TO SERVE THE LORD.\n \n" +
                    "From the durst of the earth, my God created man, His breath made man a living soul,\n" +
                    "For God so loved the world He gave His only son, and that is why I love Him so.\n" +
                    "\n" +

                    "\tCHORUS: " + "\n" +
                    "\tFor I was made in His likeness created in His image, for I was born to serve the Lord,\n" +
                    "\tOh I cannot deny Him, I will always want to serve Him,\n" +
                    "\tFor I was born to serve the Lord.\n" +
                    "\n" +

                    "My hands were made to help my neighbours, my eyes were made to read God’s word,\n" +
                    "My feet were made to walk in His footsteps, my body is the temple of the Lord.\n" ),

            new Drink( "211. BEHOLD WHAT MANNER OF MAN IS HE\n","211. BEHOLD WHAT MANNER OF MAN IS HE.\n\n" +
                    "To be sang in 2 groups. Group 1 sings chorus, Group 2 text.\n" + "\n" +
                    "\tCHORUS: " + "\n" +
                    "\tBehold what manner of man is He\t\t\t\t                                 \t-Group 1\n" +
                    "\tThat came from heaven down\t\t\t\t\t-Group 2    \n" +
                    "\n" +

                    "1. He gave for us His precious blood that we could be redeemed\t\t-Group 2\n" +
                    "   Behold what manner of man is He!                                                   \t-Group 1\n" +
                    "\n" +

                    "2. Surely He is God in flesh that came and redeemed us\t\t\t -Group 2\n" +
                    "   Behold what manner of man is He!                                                    \t -Group 1\n" +
                    "\n" +

                    "3. He is our all in all that gave His all for us\t\t\t\t\t -Group 2\n" +
                    "   Behold what manner of man is He!                                 \t\t\t  -Group 1\n" +
                    "\n" +

                    "4. When He suffered here on earth they gave Him a thorn crown\t\t  -Group 2\n" +
                    "   Behold what manner of man is He!                                                    \t             -Group 1\n" +
                    "\n" +

                    "5. He gave us His precious blood on the cross to make us kings and parents  -Group 2\n" +
                    "   Behold what manner of man is He!                                                               -Group 1\n" +
                    "\n" +

                    "6. He rose from the dead again and conquered death and hell\t\t    \t  -Group 2\n" +
                    "   Behold what manner of man is He!                                                                -Group 1\n" ),


            new Drink( "212. HALLELUYAH","212. HALLELUYAH.\n\n" +
                    "1. Oh come let us rejoice and come before the King X3\n" +
                    "    Halleluyah Amen.\n" +
                    "\n" +

                    "2. Let the fire fall, let the fire fall\n" +
                    "   Agapao fire fall, let the fire fall\n" +
                    "   Agapao fire fall.\n" +
                    "\n" +

                    "3. HalleluyahHalleluyahHalleluyah Amen\n" +
                    "   HalleluyahHalleluyah praise His Holy name.\n" ),

            new Drink( "213. THE TIGER HAS BEEN KILLED\n","213. THE TIGER HAS BEEN KILLED.\n\n" +
                    "The devil has been running to catch the first class bride\n" +
                    "\n" +

                    "\tCHORUS: " + "\n" +
                    "\tWith discussing interpreting to make a strange voice but the word is now her guide the Lord’s own face.\n" +
                    "\n" +

                    "The tiger has been killed by brother Fredrick,\n" +
                    "The tiger has been killed by brother Fredrick,\n" +
                    "The tiger has been killed by brother Fredrick,\n" +
                    "The old devil spirit that hunted for the bride,\n" +
                    "The tiger has been killed by God’s servant.\n" +
                    "\n" +

                    "My brother and my sister do take only first hand,\n" +
                    "We have only one shepherd,\n" +
                    "One David in the land, the watchman in the night,\n" +
                    "For God’s first class bride to listen to His voice,\n" +
                    "For God always is right.\n" +
                    "\n" +

                    "The bride she knows her bridegroom,   \n" +
                    "She is seeking for His face,\n" +
                    "And gone is all the dark gloom, by God rapture grace,\n" +
                    "She knows His voice so sweetly by God’s servant for this day,\n" +
                    "Don’t add don’t twist the word and then you will not fall.\n" +
                    "\n" +

                    "The sloofoot he is boasting and his big brag,\n" +
                    "Who can stand before me? Who can with me fight?\n" +
                    "But God He has His David, who defeats him day and night,\n" +
                    "With discernment word and music,\n" +
                    "The tiger is now killed.\n" ),

            new Drink( "214. OH COME LET US REJOICE\n","214. OH COME LET US REJOICE.\n\n" +
                    "1. Oh come let us rejoice and come before the King X3\n" +
                    "   Halleluyah Amen.\n" +
                    "\n" +

                    "2. Let the fire fall, let the fire fall love fall x2\n" +
                    "\n" +

                    "3. HalleluyahHalleluyahHalleluyah Amen\n" +
                    "   HalleluyahHalleluyah praise His Holy name.\n" ),

            new Drink( "215. THE TITANIC\n","215. THE TITANIC.\n\n" +
                    "It was on a Monday morning, about 1 O’clock,\n" +
                    "When the great titanic began to reel and rock,\n" +
                    "People began to scream and crying,\n" +
                    "“oh Lord we are bound to die”\n" +
                    "It was sad when the great ship went down.\n" +
                    "\n" +

                    "\tCHORUS:\n" +
                    "\tIt was sad when the great ship went down,\n" +
                    "\tIt was sad when the great ship went down\n" +
                    "\tHusbands and their wives, little children lost their lives.\n" +
                    "\tIt was sad when the great ship went down.\n" +
                    "\n" +

                    "When they built that great ship, they said what they would do.\n" +
                    "They said that they could build a ship that water could not go through,\n" +
                    "God with power in His hands showed the world it could stand,\n" +
                    "It was sad when the great ship went down.\n" +
                    "\n" +

                    "When the great ship left England, she was making for the shore.\n" +
                    "When the rich declared they could not ride with the poor,\n" +
                    "So, they put the poor below and they were the first to go,\n" +
                    "It was sad when the great ship went down.\n" ),

            new Drink( "216. I WILL BE CARRIED AWAY(LUO).\n" +
                    "       (RWOT BITANGA MALO).\n","216. I WILL BE CARRIED AWAY(LUO).\n" +
                    "           (RWOT BITANGA MALO)\n\n" +
                    "\n" +
                    "Ka kwo man me Lobo dong bitum,\n" +
                    "Rwot bitinga  malo.\n" +
                    "Ipaco me deyo bote i polo,\n" +
                    "Rwot bitinga malo.\n" +
                    "\n" +

                    "CHORUS:\n" +
                    "\tRwot bitinga malo i deyo,\n" +
                    "\tRwot bitanga malo (ki odiko)\n" +
                    "\tKa kwo man me lobo dong bitum,\n" +
                    "\tRwot bitanga malo.\n" +
                    "\n" +

                    "Ka ceng me kwo mera man bipoto\n" +
                    "Rwot bitanga malo,\n" +
                    "Calo-winyo ma otuk ki ot kol mere,\n" +
                    "Rwot bitinga malo.\n" +
                    "\n" +

                    "Odong kare manok me canena ci,\n" +
                    "Rwot bitanga malo.\n" +
                    "I lobo me kuc ma pe bigik,\n" +
                    "Rwot bitanga malo.\n" ),

            new Drink( "217. STAND UP FOR JESUS\n","217. STAND UP FOR JESUS.\n\n" +
                    "Stand up, stand up for Jesus, Ye, sol-dier of the cross, lift high His royal banner, it must not suffer loss.\n" +
                    "From vic-tory unto vic-tory, His army shall He lead, till ev-ery foe is van-quished, and Christ is Lord in-deed.\n" +
                    "\n" +

                    "Stand up, stand up for Jesus, the trm-pet call ob-ey, forth to the mighty conflict, in this His\n" +
                    "glo-rious day.\n" +
                    "“Yee that are men now serve Him ag-ainst un-numbered foes, let courage rise with danger, and strength to strength oppose.\n" +
                    "\n" +

                    "Stand up, stand up for Jesus, stand in His strength alone, the arms of flesh will fail you, Yee dare not trust your own,\n" +
                    "Put on the gos-pel ar-mour, each peace put on with prayer, when duty calls or dan-ger, be never wanting there.\n" +
                    "\n" +

                    "Stand up, stand up for Jesus, the strife will not be long, this day the noise of bat-tle, the next the vic-tory songs,\n" +
                    "To him that over-cometh, a crown of life shall be, he with the King of glory shall reign e-ternally.\n" ),

            new Drink( "218. THE LAST TRAIN TO HEAVEN","218. THE LAST TRAIN TO HEAVEN.\n\n" +
                    "You might think it’s foolish,\n" +
                    "Saying what I’ve said,\n" +
                    "But I just want to tell you,\n" +
                    "I’m not out of my head,\n" +
                    "The minutes are so precious,\n" +
                    "There’s such a precious few,\n" +
                    "And I just want to testify,\n" +
                    "The love God has for you.\n" +
                    "\n" +

                    "   CHORUS:\n" +
                    "   So I’m taking the last train to Heaven,\n" +
                    "   I hope you’ll climb aboard before the whistle blows,\n" +
                    "   Taking the last train to Heaven\n" +
                    "   Please don’t turn your back and say,\n" +
                    "   “That’s the way it goes”\n" +
                    "\n" +

                    "Now you might think it’s silly believing what I do,\n" +
                    "This is not a story that never will come true,\n" +
                    "The words are so simple, so simple, but true,\n" +
                    "And they just want to testify, the love God has for you.\n" +
                    "\n" +

                    "Now you might think it’s funny, that we’re the way we are,\n" +
                    "Oh, to get the point across, we’ve gone a bit too far,\n" +
                    "The minutes are so precious, and it’s such a precious few,\n" +
                    "That we just want to testify, the love God has for you.\n" ),

            new Drink( "219. LONELY MOUND OF CLAY\n","219. LONELY MOUND OF CLAY.\n\n" +
                    "Beside a new-made grave, heart broken\n" +
                    "My love for her won’t let me go away,\n" +
                    "And leave her there to sleep forever,\n" +
                    "All alone, beneath that lonely mound of clay.\n" +
                    "\n" +

                    "   CHORUS:\n" +
                    "   Oh, Lord, why did you take her from me?\n" +
                    "   Why didn’t you take me away?\n" +
                    "   So I could have been there beside her,\n" +
                    "   All alone beneath that lonely mould of clay.\n" +
                    "\n" +

                    "Many times I’ve looked towards Heaven,\n" +
                    "And prayed she wouldn’t be taken away,\n" +
                    "But a sinner’s prayer was never answered,\n" +
                    "So she’s sleeping now beneath the clay.\n" +
                    "\n" +

                    "I’ll stay here beside you, little darling,\n" +
                    "And I promise I’ll never go away,\n" +
                    "Until my life here is over,\n" +
                    "Then I’ll be with you beneath the clay." ),

            new Drink( "220. IT’S BEGINNING TO RAIN\n","220. IT’S BEGINNING TO RAIN.\n\n" +
                    "It’s beginning to rain, rain, rain,\n" +
                    "Hear the voice of the Father,\n" +
                    "Saying, “whosoever will,\n" +
                    "Come and drink from the water,\n" +
                    "I will pour out my spirit on,\n" +
                    "My sons and my daughters”\n" +
                    "If you’re thirsty and dry,\n" +
                    "Lift your hands to the sky,\n" +
                    "It’s beginning to rain.\n" +
                    "\n" +

                    "(Again)\n" +
                    "It’s beginning to rain,\n" +
                    "Let the spirit direct you,\n" +
                    "To peace to love,\n" +
                    "Where no hatred can stand,\n" +
                    "And the joy of Christ\n" +
                    "Refreshens your soul,\n" +
                    "It’s beginning to rain.\n" +
                    "\n" +

                    "(Again)\n" +
                    "It’s beginning to rain, rain, rain,\n" +
                    "Hear the voice of the Father,\n" +
                    "Saying, “whosoever will,\n" +
                    "Come and drink from the water,\n" +
                    "I will pour out my spirit on,\n" +
                    "My sons and my daughters”\n" +
                    "If you’re thirsty and dry,\n" +
                    "Lift your hands to the sky,\n" +
                    "It’s beginning to rain.\n" ),

            new Drink( "221. LOVING VOICES CALLING ME","LOVING VOICES CALLING ME.\n\n" +
                    "Softly through the shades of evening,\n" +
                    "Whispering so tenderly,\n" +
                    "I can hear the ascents calling,\n" +
                    "Loving voices calling me.\n" +
                    "\n" +

                    "   CHORUS:\n" +
                    "   Calling me from lands eternal,\n" +
                    "   Though their forms no more I see,\n" +
                    "   I shall one day gladly answer,\n" +
                    "   Loving voices calling me.\n" +
                    "\n" +

                    "When my lie work shall be ended,\n" +
                    "And by this my soul is free,\n" +
                    "I will answer at the river,\n" +
                    "Loving voices calling me.\n" +
                    "\n" +

                    "When I leave this world of sorrow,\n" +
                    "Enter great eternity,\n" +
                    "Through the misty shades I’ll follow,\n" +
                    "Loving voices calling me.\n" ),

            new Drink( "222. I DON’T KNOW ABOUT TOMORROW\n", "222. I DON’T KNOW ABOUT TOMORROW.\n\n" +
                    "I don’t know about tomorrow,\n" +
                    "I just live from day to day,\n" +
                    "I don’t borrow from its sunshine,\n" +
                    "For its skies may turn to gray,\n" +
                    "I don’t worry for the future,\n" +
                    "For I know what Jesus said,\n" +
                    "And today I’ll walk beside Him,\n" +
                    "For He knows what is ahead.\n" +
                    "\n" +

                    "   CHORUS\n" +
                    "   Many things about tomorrow,\n" +
                    "   I don’t try to understand,\n" +
                    "   But I know who holds tomorrow,\n" +
                    "   And I know who holds my hand.\n" +
                    "\n" +

                    "Every step is getting brighter,\n" +
                    "As the golden stairs I climb,\n" +
                    "Every burden’s getting lighter,\n" +
                    "Every cloud is silver- lined,\n" +
                    "There the sun is always shinning,\n" +
                    "There no tear will dim the eye,\n" +
                    "At the ending of the rainbow,\n" +
                    "Where the mountains touch the sky.\n" +
                    "\n" +

                    "I don’t know about tomorrow,\n" +
                    "It may bring me poverty,\n" +
                    "But the one who feeds the sparrow,\n" +
                    "Is the one who stands by me,\n" +
                    "And the path that be my portion,\n" +
                    "May be through the flame or flood,\n" +
                    "But His presence goes before me,\n" +
                    "And I’m covered with His blood.\n"),

            new Drink( "223. ON THE SEA OF GALILEE\n","223. ON THE SEA OF GALILEE.\n\n" +
                    "Am I a soldier of the cross,\n" +
                    "A follower of the Lamb,\n" +
                    "And shall I fear to own His cause,\n" +
                    "Or blush to speak His name?\n" +
                    "\n" +

                    "   CHORUS:\n" +
                    "   On the sea (the sea) of Galilee (of Galilee)\n" +
                    "   My Jesus is walking on the sea,\n" +
                    "   On the sea (the sea) of Galilee (of Galilee)\n" +
                    "   My Jesus is walking on the sea.\n" +
                    "\n" +

                    "Must I be carried to the skies,\n" +
                    "On flowery beds of ease,\n" +
                    "While others fought to win the prize,\n" +
                    "And said through bloody seas?\n" +
                    "\n" +

                    "There shall I bathe my weary soul\n" +
                    "In seas of heavenly rest,\n" +
                    "And not a wave of trouble roll,\n" +
                    "Across my peaceful breast.\n" ),

            new Drink( "224. GOSPEL TRAIN\n","224. GOSPEL TRAIN.\n\n" +
                    "There’s a train that’s headed for the land of glory,\n" +
                    "And you’ll want to catch it when it comes your way,\n" +
                    "It is powered by the mighty gospel story,\n" +
                    "And will take you to a land of brighter day.\n" +
                    "\n" +

                    "   CHORUS:\n" +
                    "   Oh, hear the whistle blowing,\n" +
                    "   As you’re over Jordan’s shore\n" +
                    "   To the Promised Land we’re going,\n" +
                    "   Jump on board and don’t be late,\n" +
                    "   We’re headed for the pearly gates,\n" +
                    "   We’ll ride that gospel train forever more.\n" +
                    "\n" +

                    "You will need a ticket and a reservation\n" +
                    "Come get in the train and follow His command,\n" +
                    "You will surely reach your final destination,\n" +
                    "When you trust and put your life in Jesus hand.\n" +
                    "\n" +

                    "There’s a map that tells the route the train is taking,\n" +
                    "And you’ll want to keep it with you as you ride,\n" +
                    "It will steer you in the choices you are making,\n" +
                    "If you’ll read and let the good book be your guide.\n" ),

            new Drink( "225. DEATH OF MOTHER\n","225. DEATH OF MOTHER.\n\n" +
                    "When I was just a little boy,\n" +
                    "My mother cared for me,\n" +
                    "But now she’s gone on to her rest,\n" +
                    "I’ll meet her there at rest.\n" +
                    "\n" +

                    "   CHORUS\n" +
                    "   I’ll never forget the death of mother,\n" +
                    "   Although this is a sad song,\n" +
                    "   I loved her then and I love her now,\n" +
                    "   And I love her even though she’s gone.\n" +
                    "\n" +

                    "My mother was a helpless one,\n" +
                    "And could not walk a step,\n" +
                    "I nursed her like a little child,\n" +
                    "And I stayed there as a child.\n" +
                    "\n" +

                    "One day my mother felt just fine,\n" +
                    "That made us feel so good,\n" +
                    "That night was her dying night,\n" +
                    "And it brought back heartaches and prayers.\n" +
                    "\n" +

                    "On her neck a cancer grew,\n" +
                    "And that was the death of her,\n" +
                    "She suffered so before she died,\n" +
                    "And then she fainted and died.\n" +
                    "\n" +

                    "The blood did run down her neck,\n" +
                    "And run upon the floor,\n" +
                    "I held my mother in my arms,\n" +
                    "While Jesus took her in His arms.\n" ),

            new Drink( "226. MOTHERLESS CHILDREN\n","226. MOTHERLESS CHILDREN.\n\n" +
                    "Motherless children face a hard time in this world,\n" +
                    "Motherless children face a hard time in this world,\n" +
                    "They are driven out in the cold, got nowhere to go,\n" +
                    "Motherless children face a hard time when the mother is dead.\n" +
                    "\n" +

                    "   CHORUS:\n" +
                    "   Orphan children face a hard time in this world,\n" +
                    "   Orphan children face a hard time in this world,\n" +
                    "   Sister does the best she can, but she really don’t understand,\n" +
                    "   Orphan children face a hard time when the mother is dead.\n" +
                    "\n" +

                    "Brother won’t treat you like mother will, when the mother is dead,\n" +
                    "Brother won’t treat you like mother will, when the mother is dead,\n" +
                    "You may ask for a piece of bread, but you may be told to go to bed,\n" +
                    "Motherless children face a hard time when the mother is dead.\n" +
                    "\n" +

                    "Friends won’t treat you like mother will, when the mother is dead,\n" +
                    "Friends won’t treat you like mother will, when the mother is dead,\n" +
                    "They will tell you what to do but they’ll turn their back on you,\n" +
                    "Motherless children face a hard time when the mother is dead.\n" ),

            new Drink( "227. OLD FOLKS HOME\n","227.OLD FOLKS HOME.\n\n" +
                    "When Mom and Dad start growing old,\n" +
                    "Our setting sun is near,\n" +
                    "They find that they’re forsaken,\n" +
                    "By the ones they hold so dear,\n" +
                    "They gave their children the best they had,\n" +
                    "And now they’re left alone,\n" +
                    "To live a life of loneliness,\n" +
                    "In an old folks home.\n" +
                    "\n" +

                    "The time when help is needed most,\n" +
                    "Their children turn them down,\n" +
                    "They seem to cause unhappiness,\n" +
                    "Whenever they’re around,\n" +
                    "They did not seem to mind at all,\n" +
                    "You were their very own,\n" +
                    "To live a life of loneliness,\n" +
                    "In an old folks home.\n" +
                    "\n" +

                    "They did without so many things,\n" +
                    "They loved and cared for you,\n" +
                    "When you were sick, they stayed awake,\n" +
                    "And watched the whole night through,\n" +
                    "They did not seem to mind at all,\n" +
                    "For you were their very own,\n" +
                    "But now you gave them loneliness,\n" +
                    "In an old folks home.\n" +
                    "\n" +

                    "I know they’d like to share your home,\n" +
                    "And live the way you do,\n" +
                    "To have someone to care for them,\n" +
                    "The way they cared for you,\n" +
                    "With broken hearts they pray at night,\n" +
                    "For God to call them home,\n" +
                    "Where there will be no loneliness,\n" +
                    "In an old folks home.\n" ),

            new Drink( "228. I HEARD MY MOTHER PRAYING FOR ME\n","228. I HEARD MY MOTHER PRAYING FOR ME.\n\n" +
                    "Last night as I lay down to sleep,\n" +
                    "I heard someone begin to weep,\n" +
                    "Then I got up just to see,\n" +
                    "I heard my mother praying for me.\n" +
                    "\n" +

                    "She was kneeling by her bed,\n" +
                    "And tears of pain were being shed,\n" +
                    "She said, “Dear God, please hear my plea”\n" +
                    "I heard my mother praying for me.\n" +
                    "\n" +

                    "I got my Bible and sat down,\n" +
                    "And in the Holy Book I found,\n" +
                    "The way to end this misery,\n" +
                    "Thank God my mother praying for me.\n" +
                    "\n" +

                    "I read it in into the night,\n" +
                    "And began to see the light,\n" +
                    "And now at last my soul is free,\n" +
                    "Thank God my mother praying for me.\n" ),

            new Drink( "229. JESUS SAVIOR PILOT ME\n","229. JESUS SAVIOR PILOT ME.\n\n" +
                    "Jesus, Saviour, pilot me,\n" +
                    "Over life’s tempest sea,\n" +
                    "Unknown waves before me roll,\n" +
                    "Hiding rocks and treacherous shoal,\n" +
                    "Chart and compass come from Thee,\n" +
                    "Jesus, Saviour, pilot me.\n" +
                    "\n" +

                    "As a mother still her child,\n" +
                    "Thou canst hush the oceans wild,\n" +
                    "Boisterous waves obey they will,\n" +
                    "When Thou sayest to them, “Be still”\n" +
                    "Wondrous sovereign of the sea,\n" +
                    "Jesus, Saviour, pilot me.\n" +
                    "\n" +

                    "When at last I reach the shore,\n" +
                    "And the fearful breakers roar,\n" +
                    "Twixt me and the peaceful rest,\n" +
                    "Then while leaning on thy breast,\n" +
                    "May I hear thee say unto me,\n" +
                    "“Fear not I will pilot thee”\n" ),

            new Drink( "230. MOTHER PRAYS LOUD IN HER SLEEP\n","MOTHER PRAYS LOUD IN HER SLEEP.\n\n" +
                    "   CHORUS:\n" +
                    "   My Mother prays so loud in her sleep,\n" +
                    "   She wakes all the neighbors with her sweet dreams,\n" +
                    "   But no one complains, their hearts feel at ease,\n" +
                    "   When they hear mother praying so loud, loud, loud,\n" +
                    "   When they hear mother praying so loud in her sleep.\n" +
                    "\n" +

                    "I come home at night and the first thing I hear,\n" +
                    "Is the sweet tender voice, ringing so clear,\n" +
                    "She’s thanking the Good Lord for all He has done,\n" +
                    "And praying that God will save everyone.\n" +
                    "\n" +

                    "When mother is praying so loud in her sleep,\n" +
                    "Upon her face there’s a smile so sweet,\n" +
                    "There’s a picture I wish that the whole world could see,\n" +
                    "When mother is praying so loud in her sleep.\n" ),

            new Drink( "231. CONSIDER THE LILIES\n","231. CONSIDER THE LILIES.\n\n" +
                    "Consider the lilies they don’t toil nor spin,\n" +
                    "And there’s not a king with more splendor than them,\n" +
                    "Consider the sparrow, they don’t plant nor sew,\n" +
                    "But they’re fed by the Master who watches them grow.\n" +
                    "\n" +

                    "   CHORUS\n" +
                    "   And we have a Heavenly Father above,\n" +
                    "   With eyes full of mercy and a heart full of love,\n" +
                    "   And He really cares when your head is bowed down,\n" +
                    "   Consider the lilies and then you will know.\n" +
                    "\n" +

                    "May I introduce you to this friend of mine?\n" +
                    "Who hangs out the stars, tells the sun when to shine,\n" +
                    "Kisses the flowers each morning with dew,\n" +
                    "He’s not too busy to care about you.\n" ),

            new Drink( "232. WHEN HE PUT A LITTLE SUNSHINE IN\n ","232. WHEN HE PUT A LITTLE SUNSHINE IN.\n\n" +
                    "All the world is brighter and cheery,\n" +
                    "And I’m singing every day,\n" +
                    "In the place of burdens dreary,\n" +
                    "I’ll sing of joyfully,\n" +
                    "For He put a ray of gladness,\n" +
                    "Where sorrow once had been,\n" +
                    "Since Jesus took my heart all to pieces\n" +
                    "And He put a little sunshine in.\n" +
                    "\n" +

                    "   CHORUS\n" +
                    "   When Jesus took my heart all to pieces\n" +
                    "   And He put a little sunshine in\n" +
                    "   He put a little joy and gladness,\n" +
                    "   Where sadness once had been,\n" +
                    "   He gave a little love and glory,\n" +
                    "   And He took away the doubt and sin,\n" +
                    "   When Jesus took my heart all to pieces\n" +
                    "   And He put a little sunshine in\n" +
                    "\n" +

                    "All the clouds have silver linings,\n" +
                    "Not a shadow is in sight,\n" +
                    "Not a tough of sad repining,\n" +
                    "The way is always bright,\n" +
                    "I was lost in sin and darkness,\n" +
                    "But the way is bright again,\n" +
                    "Since Jesus took my heart all to pieces\n" +
                    "And He put a little sunshine in.\n" +
                    "\n" +

                    "So  I press along rejoicing,\n" +
                    "In the blessed narrow road,\n" +
                    "And I know that my redeemer,\n" +
                    "Will bear my heavy load,\n" +
                    "I’m singing Hallelujah,\n" +
                    "For my soul is free from sin,\n" +
                    "Since Jesus took  my heart all to pieces\n" +
                    "And put a little sunshine in.\n" ),

            new Drink( "233. MY LAST MOVING DAY","233. MY LAST MOVING DAY.\n\n" +
                    "I’ve been travelling for Jesus so much of my time,\n" +
                    "I’ve travelled on land and on sea,\n" +
                    "But I’m counting on taking a trip to the sky,\n" +
                    "That will be the last moving for me.\n" +
                    "\n" +

                    "   CHORUS\n" +
                    "   When I move to the sky up in Heaven on high,\n" +
                    "   What a wonderful trip that will be,\n" +
                    "   I’m already to go washed in Calvary’s white snow,\n" +
                    "   That will be the last moving for me.\n" +
                    "\n" +

                    "Here I’m bothered with packing each time that I move,\n" +
                    "And I carry a load in each hand,\n" +
                    "But I’ll no need one thing that I’ve used in this world,\n" +
                    "When I’ve moved to that Heavenly land.\n" +
                    "\n" +

                    "Everything that I need will be furnished up there,\n" +
                    "Not even my song book bring,\n" +
                    "And the precious old Bible has showed me the way,\n" +
                    "I’ll not need when I stand by the King.\n" +
                    "\n" )


    };
    //each drink has a name, description and imageResourceId
    public Drink(String name, String description){
        this.name = name;
        this.description=description;
       // this.imageResourceId=imageResourceId;

        }


    public String getName() {
        return name;
    }

    public String getDescription() {
        return description;
    }

//    public int getImageResourceId() {
//        return imageResourceId;
//    }
    public String toString(){
        return this.name;
    }
}
